#!/usr/bin/env python3
"""build_index.py — final validation gate of repo-docs-init (deterministic).

Validates the whole docs tree and, when clean, emits the two machine entry
points and stamps provenance:

  docs/docs-index.json   source file -> doc page + module page;
                         module -> page + deps; capability -> modules
  docs/llms.txt          LLM navigation: what the system does (capabilities),
                         what each module does (one line), where answers live

Error classes:
  E1  a source file has no page, or no row in its module index
  E2  TODO markers remain, or a working draft still exists in docs/_drafts/
  E3  an internal relative link points at a missing page
  E5  a module index page is missing

Provenance (last_synced_commit / last_synced_at) is stamped ONLY on a clean
run, so a failing validation never mutates the tree. Non-zero exit if any
error remains.

Usage:
    python build_index.py --repo /path/to/repo [--allow-todos]
"""
import argparse
import json
import posixpath
import re
import subprocess
import sys
from datetime import date
from pathlib import Path

SKIP_NAMES = {"_PLAN.md"}
SKIP_DIRS = {"_site", "_drafts", "node_modules"}
TODO_MARK = "TODO:PROSE"


def module_page_rel(m: str) -> str:
    return "files/index.md" if m == "." else f"files/{m}/index.md"


def file_page_rel(rel: str) -> str:
    return f"files/{rel}.md"


def rel_link(from_page: str, to_page: str) -> str:
    return posixpath.relpath(to_page, posixpath.dirname(from_page) or ".")


def git_head(repo: Path) -> str:
    try:
        return subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                              cwd=repo, capture_output=True, text=True,
                              check=True).stdout.strip()
    except Exception:
        return "UNSTAMPED"


def all_doc_pages(docs: Path):
    for p in sorted(docs.rglob("*.md")):
        if p.name in SKIP_NAMES:
            continue
        if any(part in SKIP_DIRS for part in p.relative_to(docs).parts):
            continue
        yield p


def strip_noise(text: str) -> str:
    text = re.sub(r"```.*?```", "", text, flags=re.S)
    return re.sub(r"<!--.*?-->", "", text, flags=re.S)


def first_line_of_purpose(text: str) -> str:
    m = re.search(r"^## Purpose\s*\n+(.+)$", text, re.M)
    if not m:
        m = re.search(r"^# .+\n+(.+)$", text, re.M)
    if not m:
        return ""
    line = m.group(1).strip()
    if line.startswith("<!--"):
        return ""
    sm = re.match(r"(.+?[.!?])(\s|$)", line)
    s = sm.group(1) if sm else line
    return (s[:247] + "…") if len(s) > 250 else s


CAP_SECTION_RE = re.compile(
    r"^## Capability → Module Map\s*$(.*?)(?=^## |\Z)", re.M | re.S)
CAP_ROW_RE = re.compile(
    r"^\|\s*(?!Capability\b|[-: ]+\|)([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]*?)\s*\|",
    re.M)
MOD_LINK_RE = re.compile(r"\[[^\]]*\]\(files/((?:[^)#]*?/)?)index\.md\)")


def parse_capabilities(func_text: str) -> list[dict]:
    sec = CAP_SECTION_RE.search(func_text)
    if not sec:
        return []
    caps = []
    for m in CAP_ROW_RE.finditer(sec.group(1)):
        name, mods_cell, entry = (g.strip() for g in m.groups())
        mods = [link.group(1).rstrip("/") or "."
                for link in MOD_LINK_RE.finditer(mods_cell)]
        if name and mods:
            caps.append({"capability": name, "modules": mods,
                         "entry_point": entry.strip("`")})
    return caps


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--map", default=None)
    ap.add_argument("--allow-todos", action="store_true",
                    help="Downgrade E2 marker errors to warnings.")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    docs = repo / "docs"
    map_path = Path(args.map) if args.map else docs / "repo-map.json"
    rmap = json.loads(map_path.read_text(encoding="utf-8"))
    commit = git_head(repo)
    errors: list[str] = []
    warnings: list[str] = []

    # ---- E1/E5: strict 1:1 completeness ------------------------------------
    for m, info in rmap["modules"].items():
        idx = docs / module_page_rel(m)
        if not idx.exists():
            errors.append(f"E5 missing module index: docs/{module_page_rel(m)}")
            continue
        idx_text = idx.read_text(encoding="utf-8")
        for rel in info["files"]:
            if not (docs / file_page_rel(rel)).exists():
                errors.append(f"E1 missing file page: docs/{file_page_rel(rel)}")
            link = rel_link(module_page_rel(m), file_page_rel(rel))
            if f"]({link})" not in idx_text:
                errors.append(f"E1 {module_page_rel(m)}: Files table has no "
                              f"row for {rel}")

    # ---- E2: leftover drafts ------------------------------------------------
    drafts = docs / "_drafts"
    if drafts.exists():
        for d in sorted(drafts.glob("*.md")):
            msg = (f"E2 working draft still exists: docs/_drafts/{d.name} — "
                   "run `plan.py split` for its module")
            (warnings if args.allow_todos else errors).append(msg)

    # ---- E2/E3: every page in the tree --------------------------------------
    for p in all_doc_pages(docs):
        rel_name = p.relative_to(docs).as_posix()
        text = p.read_text(encoding="utf-8")
        n = text.count(TODO_MARK)
        if n:
            msg = f"E2 {rel_name}: {n} TODO marker(s) remain"
            (warnings if args.allow_todos else errors).append(msg)
        for link in re.findall(r"\]\((?!https?://|mailto:|#)([^)#\s]+\.md)",
                               strip_noise(text)):
            target = (p.parent / link).resolve()
            if not target.exists():
                errors.append(f"E3 {rel_name}: broken link -> {link}")

    # ---- capabilities --------------------------------------------------------
    func_p = docs / "functionality.md"
    caps = parse_capabilities(func_p.read_text(encoding="utf-8")) if func_p.exists() else []

    # ---- emit index + llms.txt, stamp provenance (clean runs only) ----------
    if not errors:
        base = (rmap.get("site_base_url") or "").rstrip("/")
        url = lambda rel: f"{base}/{rel}" if base else rel

        index = {
            "generated_from_commit": commit,
            "site_base_url": rmap.get("site_base_url", ""),
            "files": {rel: {"page": file_page_rel(rel),
                            "module": meta.get("module", "."),
                            "module_page": module_page_rel(meta.get("module", "."))}
                      for rel, meta in rmap["files"].items()},
            "modules": {m: {"page": module_page_rel(m),
                            "depends_on": info["depends_on"],
                            "files": info["files"]}
                        for m, info in rmap["modules"].items()},
            "capabilities": caps,
        }
        (docs / "docs-index.json").write_text(json.dumps(index, indent=2),
                                              encoding="utf-8")

        lines = [f"# {rmap['repo_name']}", "",
                 "> Generated repository documentation. Every source file has",
                 "> exactly one page: docs/files/<repo_path>.md. Every module",
                 "> has an overview page: docs/files/<module>/index.md. Read",
                 "> Capabilities for what the system does, Modules for how it",
                 "> is organized, docs-index.json for file-level lookup.", "",
                 "## Start here", "",
                 f"- [Overview]({url('overview.md')}): what the system is — modules and key flows",
                 f"- [Functionality]({url('functionality.md')}): every capability — what, why, entry points",
                 f"- [Architecture]({url('architecture.md')}): cross-cutting decisions, module dependency diagram",
                 f"- [File index]({url('docs-index.json')}): machine map, source file -> doc page", "",
                 "## Capabilities (what this repo provides)", ""]
        if caps:
            for c in caps:
                mods = ", ".join("(root)" if x == "." else x for x in c["modules"])
                entry = f" — entry: `{c['entry_point']}`" if c["entry_point"] else ""
                lines.append(f"- {c['capability']} — implemented in: {mods}{entry}")
        else:
            lines.append("- (capability table not written yet — see functionality.md)")
        lines += ["", "## Modules (how the code is organized)", ""]
        for m in rmap["module_order"]:
            p = docs / module_page_rel(m)
            desc = first_line_of_purpose(p.read_text(encoding="utf-8")) if p.exists() else ""
            label = "(root)" if m == "." else m
            lines.append(f"- [{label}]({url(module_page_rel(m))}): {desc}")
        (docs / "llms.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

        stamped = 0
        for p in all_doc_pages(docs):
            text = p.read_text(encoding="utf-8")
            new = re.sub(r"^last_synced_commit: .*$",
                         f"last_synced_commit: {commit}", text, count=1, flags=re.M)
            new = re.sub(r"^last_synced_at: .*$",
                         f"last_synced_at: {date.today().isoformat()}",
                         new, count=1, flags=re.M)
            if new != text:
                p.write_text(new, encoding="utf-8")
                stamped += 1
        print(f"docs-index.json: {len(index['files'])} files, "
              f"{len(index['modules'])} modules, {len(caps)} capabilities")
        print(f"llms.txt: written | provenance stamped on {stamped} page(s): {commit}")

    for w in warnings:
        print(f"  WARN {w}")
    if errors:
        print(f"\nVALIDATION FAILED ({len(errors)} error(s)) — nothing was "
              "stamped or emitted:")
        for e in errors:
            print(f"  {e}")
        sys.exit(1)
    print("Validation: CLEAN — every source file has a page, all links resolve.")


if __name__ == "__main__":
    main()
