#!/usr/bin/env python3
"""plan.py — work plan + draft/split machinery for repo-docs-init.

The unit of work is a MODULE (from repo-map.json). For each module the
workflow is:

  1. `plan.py next`             -> shows the next task and its draft file
  2. write prose into docs/_drafts/<module>.md (single file, all of the
     module's content: purpose, design, connections, one section per file)
  3. `plan.py split --task Mxx` -> validates the draft and splits it into
     the final pages: docs/files/<module>/index.md (module overview) and
     docs/files/<path>.md — strictly one page per source file
  4. `plan.py complete --task Mxx` -> validates the pages, checks the box

After all module tasks: F (functionality.md), O (overview.md),
A (architecture.md), then the final gate V (build_index.py must run clean).
Ordering is enforced: F/O/A refuse while module tasks are pending; V
refuses until everything else is done.

docs/_PLAN.md is the source of truth across sessions — a checked box means
"validated", never a claim. Never edit checkboxes by hand.

Subcommands:
    init      Create _PLAN.md + all module drafts + page stubs (fresh start).
    status    Progress counts, drift check, next few tasks.
    next      The single next pending task with instructions.
    draft     (Re)generate one module's draft, pulling in any existing prose.
    split     Validate a module draft and split it into the final pages.
    complete  Validate a task's pages; mark done only if validation passes.
    refresh   Re-sync the plan after the code changed (run map_repo.py first).

Usage:
    python plan.py init|status|next|refresh --repo <path>
    python plan.py draft|split|complete --repo <path> --task M03
"""
import argparse
import json
import posixpath
import re
import subprocess
import sys
from datetime import date
from pathlib import Path

PLAN_REL = "docs/_PLAN.md"
TODO = "<!-- TODO:PROSE {hint} -->"
TODO_MARK = "TODO:PROSE"
FOOTER_MARK = "<!-- machine-footer -->"
TASK_RE = re.compile(r"^- \[(?P<st>[ x])\] `(?P<id>[A-Z]\d*)` "
                     r"(?P<page>\S+) — (?P<desc>.*?)(?: — done (?P<meta>.*))?$")

# ------------------------------------------------------------ path rules ---

def module_page_rel(m: str) -> str:
    return "files/index.md" if m == "." else f"files/{m}/index.md"


def file_page_rel(rel: str) -> str:
    return f"files/{rel}.md"


def module_from_page(page: str) -> str:
    if page == "files/index.md":
        return "."
    m = re.fullmatch(r"files/(.+)/index\.md", page)
    return m.group(1) if m else ""


def draft_rel(m: str) -> str:
    slug = "root" if m == "." else m.replace("/", "__")
    return f"_drafts/{slug}.md"


def mod_label(m: str) -> str:
    return "(root)" if m == "." else m


def rel_link(from_page: str, to_page: str) -> str:
    """Relative link between two docs-relative pages."""
    frm = posixpath.dirname(from_page) or "."
    return posixpath.relpath(to_page, frm)

# --------------------------------------------------------------- plan I/O --

def git_head(repo: Path) -> str:
    try:
        return subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                              cwd=repo, capture_output=True, text=True,
                              check=True).stdout.strip()
    except Exception:
        return "UNSTAMPED"


def load_map(repo: Path) -> dict:
    p = repo / "docs" / "repo-map.json"
    if not p.exists():
        sys.exit("ERROR: docs/repo-map.json not found — run map_repo.py first.")
    return json.loads(p.read_text(encoding="utf-8"))


HEADER = """# Documentation Plan — {repo}

generated_from_commit: {commit}
updated: {today}

## How to resume in a fresh session

This file is the source of truth for documentation progress — trust it over
any session memory. To continue:

1. `python <skill>/scripts/plan.py status --repo <repo_root>` — see what is
   done and what's next. Do NOT re-run map_repo.py unless `status` reports
   commit drift.
2. `plan.py next` — take the next pending task. For a module task, write
   prose into its draft file, then `plan.py split --task <ID>`, then
   `plan.py complete --task <ID>`.
3. A checked box means the pages passed validation. Never edit checkboxes
   by hand.

If the source code changed since this plan was made: re-run map_repo.py,
then `plan.py refresh`.

## Tasks

Statuses: `[ ]` pending · `[x]` done (validated). Module order is
dependencies-first; the synthesis pages (F/O/A) come last because they are
written FROM the module pages.

"""


def build_tasks(rmap: dict) -> list[dict]:
    tasks = []
    for i, m in enumerate(rmap["module_order"], 1):
        n = len(rmap["modules"][m]["files"])
        tasks.append({"id": f"M{i:02d}", "page": module_page_rel(m),
                      "desc": f"module `{mod_label(m)}` — draft, split, "
                              f"complete ({n} file(s))",
                      "done": False, "meta": ""})
    tasks += [
        {"id": "F", "page": "functionality.md",
         "desc": "capability catalog — everything the repo provides, with the Capability → Module Map table (write from the module pages)",
         "done": False, "meta": ""},
        {"id": "O", "page": "overview.md",
         "desc": "system overview — what it is, module table one-liners, key flows, where to start reading",
         "done": False, "meta": ""},
        {"id": "A", "page": "architecture.md",
         "desc": "cross-cutting decisions; verify/prune the Mermaid module diagram",
         "done": False, "meta": ""},
        {"id": "V", "page": "(all)",
         "desc": "final gate: build_index.py runs clean (emits llms.txt + docs-index.json)",
         "done": False, "meta": ""},
    ]
    return tasks


def write_plan(repo: Path, rmap: dict, tasks: list[dict], commit: str) -> None:
    lines = [HEADER.format(repo=rmap["repo_name"], commit=commit,
                           today=date.today().isoformat()).rstrip(), ""]
    for t in tasks:
        box = "x" if t["done"] else " "
        meta = f" — done {t['meta']}" if t["done"] and t["meta"] else ""
        lines.append(f"- [{box}] `{t['id']}` {t['page']} — {t['desc']}{meta}")
    (repo / PLAN_REL).write_text("\n".join(lines) + "\n", encoding="utf-8")


def read_plan(repo: Path) -> tuple[str, list[dict]]:
    p = repo / PLAN_REL
    if not p.exists():
        sys.exit(f"ERROR: {PLAN_REL} not found — run `plan.py init` first.")
    text = p.read_text(encoding="utf-8")
    tasks = []
    for line in text.splitlines():
        m = TASK_RE.match(line)
        if m:
            tasks.append({"id": m["id"], "page": m["page"], "desc": m["desc"],
                          "done": m["st"] == "x", "meta": m["meta"] or ""})
    if not tasks:
        sys.exit(f"ERROR: no parseable tasks in {PLAN_REL}.")
    return text, tasks

# ------------------------------------------------------ existing prose -----

def split_frontmatter(text: str) -> tuple[str, str]:
    m = re.match(r"^---\n.*?\n---\n", text, flags=re.S)
    return (text[:m.end()], text[m.end():]) if m else ("", text)


def section_prose(body: str, heading: str) -> str:
    """Content of a '## heading' section, stripped of machine comments."""
    m = re.search(rf"^## {re.escape(heading)}\s*\n(.*?)(?=^## |\Z)",
                  body, flags=re.M | re.S)
    if not m:
        return ""
    content = re.sub(r"<!--(?!.*TODO:PROSE).*?-->", "", m.group(1), flags=re.S)
    return content.strip()


def existing_module_prose(docs: Path, m: str) -> dict:
    """Pull prose back out of an existing module index (for draft regen)."""
    p = docs / module_page_rel(m)
    if not p.exists():
        return {}
    _, body = split_frontmatter(p.read_text(encoding="utf-8"))
    return {h: section_prose(body, h)
            for h in ("Purpose", "Design notes", "How it connects")}


def existing_file_prose(docs: Path, rel: str) -> str:
    """Pull the prose back out of an existing file page (for draft regen)."""
    p = docs / file_page_rel(rel)
    if not p.exists():
        return ""
    _, body = split_frontmatter(p.read_text(encoding="utf-8"))
    body = body.split(FOOTER_MARK)[0]
    body = re.sub(r"^# .*\n", "", body, count=1, flags=re.M)
    return body.strip()

# ---------------------------------------------------------------- drafts ---

def facts_comment(rel: str, meta: dict) -> str:
    bits = [meta.get("language", "?"), f"{meta.get('loc', '?')} lines"]
    if meta.get("public_symbols"):
        bits.append("public: " + ", ".join(meta["public_symbols"][:12]))
    if meta.get("internal_deps"):
        bits.append("imports: " + ", ".join(meta["internal_deps"][:8]))
    if meta.get("used_by"):
        bits.append("imported by: " + ", ".join(meta["used_by"][:8]))
    return f"<!-- facts: {' · '.join(bits)} -->"


def gen_draft(repo: Path, rmap: dict, m: str) -> Path:
    """(Re)generate a module draft. Existing prose from already-written pages
    is pulled in so a regenerated draft never loses work."""
    docs = repo / "docs"
    info = rmap["modules"][m]
    prev = existing_module_prose(docs, m)
    t = lambda hint: TODO.format(hint=hint)

    def sec(name: str, hint: str) -> str:
        return prev.get(name) or t(hint)

    deps = ", ".join(mod_label(d) for d in info["depends_on"]) or "nothing in this repo"
    used = ", ".join(mod_label(d) for d in info["depended_on_by"]) or "nothing in this repo"

    lines = [
        f"# Module: {mod_label(m)}",
        "",
        f"> Working draft for module `{mod_label(m)}`. Read the module's source",
        "> files first, then replace every TODO marker with prose (see the",
        "> editorial standard in SKILL.md). The `<!-- facts: ... -->` comments",
        "> are machine hints — they are stripped automatically on split.",
        f"> When done: `plan.py split` then `plan.py complete` for this task.",
        "",
        "## Purpose",
        "",
        sec("Purpose", "1-2 paragraphs, full sentences: the problem this "
            "module owns, who calls into it, and what it deliberately does "
            "not handle."),
        "",
        "## Design notes",
        "",
        sec("Design notes", "the decisions a reader cannot see in the code: "
            "invariants, why odd-looking choices were forced, the 2-3 things "
            "a newcomer would get wrong on their first change here. Write "
            "'Nothing beyond what the code shows.' only if that is true."),
        "",
        "## How it connects",
        "",
        f"<!-- facts: depends on: {deps} · used by: {used} -->",
        sec("How it connects", "a short paragraph on how data and control "
            "flow through this module: who calls it, what it calls, what "
            "passes across the boundary."),
        "",
        "## Files",
        "",
        "Write one short, readable passage per file — typically 2-6 sentences.",
        "The FIRST sentence doubles as the file's one-line summary in the",
        "module index, so make it carry the file's purpose on its own.",
        "",
    ]
    for rel in info["files"]:
        prose = existing_file_prose(docs, rel)
        lines += [f"### {rel}", "", facts_comment(rel, rmap["files"][rel]),
                  prose or t("what this file contributes and why it exists "
                             "as its own file; mention the symbols that "
                             "matter, in prose, not a table."),
                  ""]
    p = docs / draft_rel(m)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return p

# ----------------------------------------------------------------- split ---

def parse_draft(text: str) -> tuple[dict, dict]:
    """-> (sections {Purpose, Design notes, How it connects}, files {rel: prose}).
    Machine 'facts' comments are stripped; TODO markers are preserved so
    validation can catch them."""
    body = re.sub(r"^> .*\n?", "", text, flags=re.M)          # draft banner
    body = re.sub(r"<!-- facts:.*?-->", "", body, flags=re.S)
    secs = {}
    for h in ("Purpose", "Design notes", "How it connects"):
        m = re.search(rf"^## {re.escape(h)}\s*\n(.*?)(?=^## |\Z)",
                      body, flags=re.M | re.S)
        secs[h] = m.group(1).strip() if m else ""
    files = {}
    fm = re.search(r"^## Files\s*\n(.*)\Z", body, flags=re.M | re.S)
    if fm:
        for chunk in re.finditer(r"^### (\S+)\s*\n(.*?)(?=^### |\Z)",
                                 fm.group(1), flags=re.M | re.S):
            files[chunk.group(1)] = chunk.group(2).strip()
    return secs, files


def first_sentence(prose: str) -> str:
    text = re.sub(r"\s+", " ", re.sub(r"<!--.*?-->", "", prose, flags=re.S)).strip()
    m = re.match(r"(.+?[.!?])(\s|$)", text)
    s = m.group(1) if m else text
    return (s[:197] + "…") if len(s) > 200 else s


def yaml_list(items: list[str], cap: int = 25) -> str:
    shown = ", ".join(items[:cap])
    extra = f"  # +{len(items) - cap} more" if len(items) > cap else ""
    return f"[{shown}]{extra}"


def write_module_index(docs: Path, rmap: dict, m: str, secs: dict,
                       files: dict) -> None:
    info = rmap["modules"][m]
    page = module_page_rel(m)
    today = date.today().isoformat()
    fm = ["---",
          f"module: {m}",
          f"files: {yaml_list(info['files'])}",
          f"depends_on: {yaml_list(info['depends_on'])}",
          f"depended_on_by: {yaml_list(info['depended_on_by'])}",
          f"languages: {yaml_list(info['languages'])}",
          "last_synced_commit: UNSTAMPED",
          f"last_synced_at: {today}",
          "---"]
    rows = ["| File | What it does |", "|---|---|"]
    for rel in info["files"]:
        link = rel_link(page, file_page_rel(rel))
        label = rel if m == "." else posixpath.relpath(rel, m)
        rows.append(f"| [{label}]({link}) | {first_sentence(files[rel])} |")
    body = [f"# {mod_label(m) if m != '.' else rmap['repo_name'] + ' (repo root files)'}",
            "",
            "## Purpose", "", secs["Purpose"], "",
            "## Design notes", "", secs["Design notes"], "",
            "## How it connects", "", secs["How it connects"], "",
            "## Files", "", *rows, ""]
    p = docs / page
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join(fm) + "\n\n" + "\n".join(body), encoding="utf-8")


def write_file_page(docs: Path, rmap: dict, m: str, rel: str, prose: str) -> None:
    meta = rmap["files"][rel]
    page = file_page_rel(rel)
    today = date.today().isoformat()
    fm = ["---",
          f"source_path: {rel}",
          f"module: {m}",
          f"language: {meta['language']}",
          f"public_symbols: {yaml_list(meta.get('public_symbols', []), 15)}",
          f"internal_deps: {yaml_list(meta.get('internal_deps', []))}",
          f"used_by: {yaml_list(meta.get('used_by', []))}",
          f"loc: {meta.get('loc', 0)}",
          "last_synced_commit: UNSTAMPED",
          f"last_synced_at: {today}",
          "---"]
    dep_links = ", ".join(f"[{d}]({rel_link(page, file_page_rel(d))})"
                          for d in meta.get("internal_deps", [])) or "nothing in this repo"
    use_links = ", ".join(f"[{d}]({rel_link(page, file_page_rel(d))})"
                          for d in meta.get("used_by", [])) or "nothing in this repo"
    footer = [FOOTER_MARK,
              f"**Depends on:** {dep_links}",
              f"**Used by:** {use_links}",
              f"**Module:** [{mod_label(m)}]({rel_link(page, module_page_rel(m))}) · "
              f"{meta.get('loc', '?')} lines of {meta['language']}"]
    repo_url = rmap.get("repo_url", "")
    if repo_url:
        sep = "?path=/" if "_git" in repo_url else "/"
        footer.append(f"[View source]({repo_url.rstrip('/')}{sep}{rel})")
    body = [f"# {rel}", "", prose, "", "---", ""] + [footer[0]] + \
           ["", "\n\n".join(footer[1:]), ""]
    p = docs / page
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join(fm) + "\n\n" + "\n".join(body), encoding="utf-8")


def sweep_orphans(docs: Path, rmap: dict, m: str) -> list[str]:
    """Delete pages inside this module's docs subtree whose source file no
    longer exists (excluding subtrees that belong to deeper modules)."""
    base = docs / "files" if m == "." else docs / "files" / m
    if not base.exists():
        return []
    deeper = [x for x in rmap["modules"] if x != m and x != "." and
              (m == "." or x.startswith(m + "/"))]
    removed = []
    for p in base.rglob("*.md"):
        rel_doc = p.relative_to(docs / "files").as_posix()
        if rel_doc.endswith("/index.md") or rel_doc == "index.md":
            d = rel_doc[:-len("/index.md")] if rel_doc != "index.md" else "."
            if d in rmap["modules"]:
                continue
        src = rel_doc[:-3]                                     # strip ".md"
        owner = None
        for mm in rmap["modules"]:
            if mm != "." and (src == mm or src.startswith(mm + "/")):
                if owner is None or len(mm) > len(owner):
                    owner = mm
        owner = owner or "."
        if owner in deeper:
            continue                                           # not ours
        if src not in rmap["files"]:
            p.unlink()
            removed.append(f"docs/files/{rel_doc}")
    # drop directories emptied by the sweep
    for d in sorted((x for x in base.rglob("*") if x.is_dir()),
                    key=lambda x: len(x.parts), reverse=True):
        if not any(d.iterdir()):
            d.rmdir()
    return removed


def cmd_split(repo: Path, task_id: str) -> None:
    _, tasks = read_plan(repo)
    t = next((x for x in tasks if x["id"] == task_id), None)
    if not t or not re.fullmatch(r"M\d+", task_id):
        sys.exit(f"ERROR: `{task_id}` is not a module task in the plan.")
    m = module_from_page(t["page"])
    rmap = load_map(repo)
    if m not in rmap["modules"]:
        sys.exit(f"ERROR: module `{m}` not in repo-map.json — re-run "
                 "map_repo.py and `plan.py refresh`.")
    docs = repo / "docs"
    dpath = docs / draft_rel(m)
    if not dpath.exists():
        sys.exit(f"ERROR: draft docs/{draft_rel(m)} not found — run "
                 f"`plan.py draft --task {task_id}` to regenerate it.")

    secs, files = parse_draft(dpath.read_text(encoding="utf-8"))
    errs = []
    expected = rmap["modules"][m]["files"]
    for rel in expected:
        if rel not in files:
            errs.append(f"draft has no `### {rel}` section")
        elif not files[rel] or TODO_MARK in files[rel]:
            errs.append(f"section `### {rel}` is empty or still has a TODO marker")
    for rel in files:
        if rel not in expected:
            errs.append(f"draft section `### {rel}` matches no mapped source "
                        "file (typo, or the file moved — re-run map_repo.py "
                        "+ refresh)")
    for h in ("Purpose", "Design notes", "How it connects"):
        if not secs.get(h) or TODO_MARK in secs[h]:
            errs.append(f"'## {h}' is empty or still has a TODO marker")
    if errs:
        print(f"SPLIT BLOCKED for [{task_id}] `{mod_label(m)}` — fix the "
              f"draft (docs/{draft_rel(m)}):")
        for e in errs:
            print(f"  - {e}")
        sys.exit(1)

    write_module_index(docs, rmap, m, secs, files)
    for rel in expected:
        write_file_page(docs, rmap, m, rel, files[rel])
    removed = sweep_orphans(docs, rmap, m)
    dpath.unlink()
    print(f"Split OK: docs/{module_page_rel(m)} + {len(expected)} file "
          f"page(s) written; draft removed.")
    for r in removed:
        print(f"  removed orphan page (source file gone): {r}")
    print(f"Now run: plan.py complete --repo <repo_root> --task {task_id}")

# ------------------------------------------------------------- validation --

def page_errors(docs: Path, rel: str) -> list[str]:
    p = docs / rel
    if not p.exists():
        return [f"page docs/{rel} does not exist"]
    text = p.read_text(encoding="utf-8")
    errs = []
    n = text.count(TODO_MARK)
    if n:
        errs.append(f"{n} TODO marker(s) remain in docs/{rel}")
    return errs


CAP_ROW_RE = re.compile(
    r"^\|\s*(?!Capability\b|[-: ]+\|)([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]*?)\s*\|",
    re.M)
CAP_SECTION_RE = re.compile(
    r"^## Capability → Module Map\s*$(.*?)(?=^## |\Z)", re.M | re.S)
MOD_LINK_RE = re.compile(r"\[[^\]]*\]\(files/((?:[^)#]*?/)?)index\.md\)")


def parse_capabilities(func_text: str) -> list[dict]:
    sec = CAP_SECTION_RE.search(func_text)
    if not sec:
        return []
    caps = []
    for m in CAP_ROW_RE.finditer(sec.group(1)):
        name, mods_cell, entry = (g.strip() for g in m.groups())
        mods = [link.group(1).rstrip("/") or "."
                for link in MOD_LINK_RE.finditer(mods_cell)]
        if name and mods:
            caps.append({"capability": name, "modules": mods,
                         "entry_point": entry.strip("`")})
    return caps


def validate_task(repo: Path, t: dict, rmap: dict) -> list[str]:
    docs = repo / "docs"
    if t["id"] == "V":
        script = Path(__file__).parent / "build_index.py"
        r = subprocess.run([sys.executable, str(script), "--repo", str(repo)],
                           capture_output=True, text=True)
        return [] if r.returncode == 0 else ["build_index.py failed:\n"
                                             + r.stdout.strip()]
    if t["id"] == "F":
        errs = page_errors(docs, "functionality.md")
        p = docs / "functionality.md"
        if p.exists() and not parse_capabilities(p.read_text(encoding="utf-8")):
            errs.append("Capability → Module Map has no parseable rows "
                        "(| Capability | [module](files/<m>/index.md) links | `entry` |)")
        return errs
    if t["id"] == "O":
        return page_errors(docs, "overview.md")
    if t["id"] == "A":
        errs = page_errors(docs, "architecture.md")
        p = docs / "architecture.md"
        if p.exists() and "```mermaid" not in p.read_text(encoding="utf-8"):
            errs.append("architecture.md has no ```mermaid diagram")
        return errs

    # module task
    m = module_from_page(t["page"])
    if m not in rmap["modules"]:
        return [f"module `{m}` is no longer in repo-map.json — run refresh"]
    errs = []
    if (docs / draft_rel(m)).exists():
        errs.append(f"draft docs/{draft_rel(m)} still exists — run "
                    f"`plan.py split --task {t['id']}` first")
    errs += page_errors(docs, t["page"])
    idx = docs / t["page"]
    idx_text = idx.read_text(encoding="utf-8") if idx.exists() else ""
    for rel in rmap["modules"][m]["files"]:
        errs += page_errors(docs, file_page_rel(rel))
        if f"]({rel_link(t['page'], file_page_rel(rel))})" not in idx_text:
            errs.append(f"module index has no Files row for {rel}")
    return errs


def blocked_by(tasks: list[dict], t: dict) -> list[str]:
    pending = lambda pred: [x["id"] for x in tasks if pred(x) and not x["done"]]
    if t["id"] in ("F", "O", "A"):
        mods = pending(lambda x: x["id"].startswith("M"))
        if mods:
            return mods
    if t["id"] == "V":
        return pending(lambda x: x["id"] != "V")
    return []

# ----------------------------------------------------------------- stubs ---

def mermaid_module_graph(rmap: dict) -> str:
    def mid(m):
        return "root" if m == "." else re.sub(r"[^A-Za-z0-9_]", "_", m)
    lines = ["```mermaid", "graph LR"]
    for m in rmap["module_order"]:
        lines.append(f'  {mid(m)}["{mod_label(m)}"]')
    edges = False
    for m in rmap["module_order"]:
        for d in rmap["modules"][m]["depends_on"]:
            lines.append(f"  {mid(m)} --> {mid(d)}")
            edges = True
    if not edges:
        lines.append("  %% no cross-module dependencies detected")
    lines.append("```")
    return "\n".join(lines)


def gen_stubs(repo: Path, rmap: dict) -> None:
    docs = repo / "docs"
    t = lambda hint: TODO.format(hint=hint)
    mod_rows = "\n".join(
        f"| [{mod_label(m)}]({module_page_rel(m)}) | "
        f"{t('one plain sentence: what this module is for')} |"
        for m in rmap["module_order"])

    stubs = {
        "functionality.md": f"""# {rmap['repo_name']} — Functionality

{t("2-3 sentences: what this system provides to the people or systems that use it, written for someone who has never seen the code. Write AFTER the module pages.")}

## Capabilities

{t('''one "### <Capability>" section per distinct thing the repo can do. For each: what it does from the consumer's point of view, why it exists, how the request flows through the modules, and the entry point in `path::symbol` form. Capabilities often span modules — that cross-cutting view is the point. Cover everything: a capability missing from this page is invisible to readers.''')}

## Capability → Module Map

| Capability | Modules | Entry point |
|---|---|---|
{t("one row per capability. Module cells are links, e.g. | Process a payment | [src/api](files/src/api/index.md), [src/billing](files/src/billing/index.md) | `src/api/routes.py::pay` |. This table is machine-parsed into llms.txt and docs-index.json.")}
""",
        "overview.md": f"""# {rmap['repo_name']} — Overview

{t("3-5 sentences: what this system is, what it does, and for whom. Write from the module pages, not raw code.")}

For the system described by *what it can do*, see [Functionality](functionality.md).

## Modules at a glance

| Module | Purpose |
|---|---|
{mod_rows}

## Key flows

{t("the 2-3 most important data/control flows end to end, in prose, linking the module pages they pass through.")}

## Where to start reading

{t("a short reading order for a newcomer: which module first, and why.")}
""",
        "architecture.md": f"""# {rmap['repo_name']} — Architecture

{t("the cross-cutting decisions and the constraints that forced them: layering rules, error handling, configuration, anything that spans modules. Write LAST, from the module pages.")}

## Module dependency diagram

{mermaid_module_graph(rmap)}

Arrows point from a module to the modules it imports. The diagram is
generated from the import graph — prune edges only if they are noise.
""",
    }
    for name, content in stubs.items():
        p = docs / name
        if not p.exists():
            p.write_text(content, encoding="utf-8")


def gen_landing(repo: Path, rmap: dict) -> None:
    docs = repo / "docs"
    rows = "\n".join(
        f"| [{mod_label(m)}]({module_page_rel(m)}) | "
        f"{len(rmap['modules'][m]['files'])} | {rmap['modules'][m]['loc']} |"
        for m in rmap["module_order"])
    (docs / "index.md").write_text(f"""# {rmap['repo_name']} documentation

Generated by repo-docs-init. Every source file has exactly one page under
`files/` (same path, `.md` appended), and every module has an overview page.

| Start here | |
|---|---|
| [Overview](overview.md) | what the system is, its modules, key flows |
| [Functionality](functionality.md) | everything the repo can do — what, why, entry points |
| [Architecture](architecture.md) | cross-cutting decisions and the module dependency diagram |

## Modules

| Module | Files | Lines |
|---|---|---|
{rows}

LLM agents: start at [llms.txt](llms.txt); look up any source file via
[docs-index.json](docs-index.json).
""", encoding="utf-8")

# -------------------------------------------------------------- commands ---

def cmd_init(repo: Path) -> None:
    if (repo / PLAN_REL).exists():
        sys.exit(f"ERROR: {PLAN_REL} already exists — use `refresh`, or "
                 "delete it to restart.")
    rmap = load_map(repo)
    (repo / "docs").mkdir(parents=True, exist_ok=True)
    tasks = build_tasks(rmap)
    write_plan(repo, rmap, tasks, git_head(repo))
    for m in rmap["module_order"]:
        gen_draft(repo, rmap, m)
    gen_stubs(repo, rmap)
    gen_landing(repo, rmap)
    print(f"Plan created: {PLAN_REL} — {len(rmap['module_order'])} module "
          "task(s) + F, O, A, V.")
    print("Drafts written to docs/_drafts/ (one per module). Start with "
          "`plan.py next`.")


def cmd_status(repo: Path) -> None:
    _, tasks = read_plan(repo)
    done = [t for t in tasks if t["done"]]
    pending = [t for t in tasks if not t["done"]]
    print(f"Progress: {len(done)}/{len(tasks)} tasks done "
          f"({100 * len(done) // len(tasks)}%)")
    plan_commit = re.search(r"generated_from_commit: (\S+)",
                            (repo / PLAN_REL).read_text(encoding="utf-8"))
    head = git_head(repo)
    if plan_commit and plan_commit.group(1) not in ("UNSTAMPED", head):
        print(f"NOTE: repo HEAD ({head}) differs from plan commit "
              f"({plan_commit.group(1)}). If source code changed, re-run "
              "map_repo.py, then `plan.py refresh`.")
    if pending:
        print("\nNext tasks:")
        for t in pending[:5]:
            print(f"  [{t['id']}] {t['page']} — {t['desc']}")
    else:
        print("All tasks complete. Documentation is done and validated.")


def cmd_next(repo: Path) -> None:
    _, tasks = read_plan(repo)
    t = next((t for t in tasks if not t["done"]), None)
    if not t:
        print("All tasks complete.")
        return
    print(f"NEXT TASK [{t['id']}]: {t['desc']}")
    if re.fullmatch(r"M\d+", t["id"]):
        m = module_from_page(t["page"])
        print(f"1. Read the module's source files (module: {mod_label(m)}).\n"
              f"2. Write prose into docs/{draft_rel(m)} — replace every TODO "
              "marker.\n"
              f"3. python plan.py split --repo <repo_root> --task {t['id']}\n"
              f"4. python plan.py complete --repo <repo_root> --task {t['id']}")
    elif t["id"] == "V":
        print("Run: python <skill>/scripts/build_index.py --repo <repo_root>; "
              "fix any errors; then plan.py complete --task V")
    else:
        print(f"1. Open docs/{t['page']} and replace every TODO marker, "
              "writing FROM the module pages.\n"
              f"2. python plan.py complete --repo <repo_root> --task {t['id']}")


def cmd_draft(repo: Path, task_id: str) -> None:
    _, tasks = read_plan(repo)
    t = next((x for x in tasks if x["id"] == task_id), None)
    if not t or not re.fullmatch(r"M\d+", task_id):
        sys.exit(f"ERROR: `{task_id}` is not a module task in the plan.")
    m = module_from_page(t["page"])
    rmap = load_map(repo)
    if m not in rmap["modules"]:
        sys.exit(f"ERROR: module `{m}` not in repo-map.json.")
    p = gen_draft(repo, rmap, m)
    print(f"Draft (re)generated: {p.relative_to(repo)} — existing page prose "
          "was pulled in where available.")


def cmd_complete(repo: Path, task_id: str) -> None:
    text, tasks = read_plan(repo)
    t = next((t for t in tasks if t["id"] == task_id), None)
    if not t:
        sys.exit(f"ERROR: no task `{task_id}` in plan.")
    if t["done"]:
        print(f"Task {task_id} is already done.")
        return
    blockers = blocked_by(tasks, t)
    if blockers:
        shown = ", ".join(blockers[:8]) + (" …" if len(blockers) > 8 else "")
        sys.exit(f"ORDER ENFORCED: task {task_id} cannot complete while "
                 f"these are pending: {shown}\nSynthesis pages are written "
                 "FROM the module pages — finish those first.")
    rmap = load_map(repo)
    errs = validate_task(repo, t, rmap)
    if errs:
        print(f"VALIDATION FAILED for [{task_id}] — task stays pending:")
        for e in errs:
            print(f"  - {e}")
        sys.exit(1)
    stamp = f"{date.today().isoformat()} @{git_head(repo)}"
    clean_desc = re.sub(r" \(reopened:.*\)$", "", t["desc"])
    old = f"- [ ] `{t['id']}` {t['page']} — {t['desc']}"
    new = f"- [x] `{t['id']}` {t['page']} — {clean_desc} — done {stamp}"
    text = text.replace(old, new, 1)
    text = re.sub(r"^updated: .*$", f"updated: {date.today().isoformat()}",
                  text, count=1, flags=re.M)
    (repo / PLAN_REL).write_text(text, encoding="utf-8")
    remaining = sum(1 for x in tasks if not x["done"]) - 1
    print(f"[{task_id}] validated and marked done. {remaining} task(s) remaining.")


def cmd_refresh(repo: Path) -> None:
    text, tasks = read_plan(repo)
    rmap = load_map(repo)
    reopened, appended, retired = [], [], []
    docs = repo / "docs"

    valid_pages = {module_page_rel(m) for m in rmap["module_order"]}
    for t in tasks:
        if re.fullmatch(r"M\d+", t["id"]) and t["page"] not in valid_pages \
                and not t["desc"].startswith("obsolete:"):
            text = re.sub(
                rf"^- \[.\] `{t['id']}` .*$",
                f"- [x] `{t['id']}` {t['page']} — obsolete: module removed "
                f"from repo (retired by refresh; delete its stale pages)",
                text, count=1, flags=re.M)
            retired.append(t["id"])

    for t in tasks:
        if t["id"] in retired or t["desc"].startswith("obsolete:"):
            continue
        if t["done"] and t["id"] != "V" and validate_task(repo, t, rmap):
            old = f"- [x] `{t['id']}` {t['page']} — {t['desc']}" + \
                  (f" — done {t['meta']}" if t["meta"] else "")
            new = (f"- [ ] `{t['id']}` {t['page']} — {t['desc']} "
                   "(reopened: pages regressed or files changed)")
            if old in text:
                text = text.replace(old, new, 1)
                reopened.append(t["id"])
                if re.fullmatch(r"M\d+", t["id"]):
                    gen_draft(repo, rmap, module_from_page(t["page"]))

    known_pages = {t["page"] for t in tasks}
    max_m = max((int(t["id"][1:]) for t in tasks
                 if re.fullmatch(r"M\d+", t["id"])), default=0)
    new_lines = []
    for m in rmap["module_order"]:
        pg = module_page_rel(m)
        if pg not in known_pages:
            max_m += 1
            n = len(rmap["modules"][m]["files"])
            new_lines.append(f"- [ ] `M{max_m:02d}` {pg} — module "
                             f"`{mod_label(m)}` — draft, split, complete "
                             f"({n} file(s)) (added by refresh)")
            appended.append(f"M{max_m:02d}")
            gen_draft(repo, rmap, m)
    if new_lines:
        text = re.sub(r"^(- \[.\] `F` )", "\n".join(new_lines) + "\n\\1",
                      text, count=1, flags=re.M)

    if reopened or appended or retired:
        for tid in ("F", "O", "A", "V"):
            text = re.sub(rf"^- \[x\] `{tid}` (.*?)( — done .*)?$",
                          rf"- [ ] `{tid}` \1 (reopened: module set or pages changed)",
                          text, count=1, flags=re.M)
        gen_landing(repo, rmap)

    text = re.sub(r"^updated: .*$", f"updated: {date.today().isoformat()}",
                  text, count=1, flags=re.M)
    text = re.sub(r"^generated_from_commit: .*$",
                  f"generated_from_commit: {git_head(repo)}",
                  text, count=1, flags=re.M)
    (repo / PLAN_REL).write_text(text, encoding="utf-8")
    print(f"Refresh: reopened {reopened or 'none'}, appended "
          f"{appended or 'none'}, retired {retired or 'none'}. Drafts were "
          "regenerated for reopened/new modules (existing prose pulled in).")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["init", "status", "next", "draft",
                                    "split", "complete", "refresh"])
    ap.add_argument("--repo", required=True)
    ap.add_argument("--task", default=None)
    args = ap.parse_args()
    repo = Path(args.repo).resolve()
    if args.cmd == "init":
        cmd_init(repo)
    elif args.cmd == "status":
        cmd_status(repo)
    elif args.cmd == "next":
        cmd_next(repo)
    elif args.cmd in ("draft", "split", "complete"):
        if not args.task:
            sys.exit(f"ERROR: {args.cmd} requires --task <ID>")
        {"draft": cmd_draft, "split": cmd_split,
         "complete": cmd_complete}[args.cmd](repo, args.task)
    elif args.cmd == "refresh":
        cmd_refresh(repo)


if __name__ == "__main__":
    main()
