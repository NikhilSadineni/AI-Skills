# Example: a completed directory at the quality bar

A finished `src/auth` directory for a fictional service: one file page and the
directory index. Notice what the prose does — and, in the annotations at the
end, what it deliberately avoids.

## File page — `docs/reference/src/auth/session.py.md`

```markdown
---
file: session.py
directory: src/auth
source_path: src/auth/session.py
public_symbols: [create_session, validate_token, revoke_session]
internal_deps: [src/auth/crypto.py, src/auth/tokens.py]
used_by: [src/api/handlers.py, src/admin/actions.py]
last_synced_commit: a3f8c2d
last_synced_at: 2026-07-12
---

# session.py

The lifecycle orchestrator and the directory's public face — external callers
import from here only, never from `tokens.py` or `crypto.py`. It exists as a
separate file so the public API surface stays reviewable in one place while
the mechanics (encoding, signing) live behind it.

## What it provides

| Symbol | What it does & why it matters |
|---|---|
| `create_session` | Mints the opaque token at login and enforces the per-user concurrent-session cap (appears to default to 5; the limit lives in `src/core/config.py`, not here). |
| `validate_token` | Per-request check; returns a `SessionContext`, **not a boolean** — truthiness-checking the context treats an expired-but-present session as valid. |
| `revoke_session` | Idempotent by design so the force-logout job can be retried blindly. |

## Behavior notes

Every validation is a storage lookup — there is deliberately no caching layer
(see the revocation invariant in the [directory overview](index.md)). Failure
mode worth knowing: storage timeouts surface as `SessionUnavailable`, which
`src/api` maps to 503, not 401 — a session is never treated as invalid just
because the backend was slow. Assumes single-writer per session id; concurrent
revoke+refresh resolves in favor of revoke.

Internal dependencies: `src/auth/crypto.py`, `src/auth/tokens.py`
Used by: `src/api/handlers.py`, `src/admin/actions.py`
Size: 182 lines (python)

[View source](https://github.com/contoso/platform/blob/main/src/auth/session.py) · [Directory overview](index.md)
```

## Directory index — `docs/reference/src/auth/index.md`

```markdown
---
directory: src/auth
files: [crypto.py, session.py, tokens.py]
subdirectories: []
public_api: [create_session, validate_token, revoke_session, rotate_keys]
depends_on: [src/core, src/storage]
depended_on_by: [src/api, src/admin]
last_synced_commit: a3f8c2d
last_synced_at: 2026-07-12
---

# src/auth

## Purpose

Owns the full lifecycle of user sessions: creation at login, validation on
every request, and revocation on logout or compromise. It is the only code
allowed to mint or invalidate credentials — `src/api` and `src/admin` consume
its functions but never touch session storage directly.

It deliberately does **not** handle identity (who the user is) or
authorization (what they may do). Identity comes from the upstream SSO
callback handled in `src/api`; authorization lives in each consuming service.
Keeping auth purely about session mechanics is what allows the 1-second
revocation guarantee below.

## Functionality provided

Session management for the whole platform — see
[User sessions](../../functionality.md) in the catalog. Entry points:
`src/auth/session.py::create_session` (login),
`src/auth/session.py::validate_token` (every request),
`src/auth/session.py::revoke_session` (logout / force-logout),
`src/auth/crypto.py::rotate_keys` (ops runbook only).

## Design & Invariants

Sessions are **opaque server-side tokens, not JWTs**. The product requirement
is that revoking a session takes effect in under one second; stateless JWTs
can't be recalled once issued, so every validation is a lookup against
`src/storage`. If you're tempted to "optimize" validation by caching decoded
tokens in the consumer, you will silently break revocation — this has been
attempted and reverted twice (see ADR-0007).

All cryptographic primitives are confined to `crypto.py`. Nothing else in the
repo imports `hashlib` or `cryptography` directly (enforced by lint rule
`no-direct-crypto`). This is what makes key rotation a one-file change.

Things a newcomer gets wrong on their first PR here: (1) `validate_token`
returns a `SessionContext`, not a boolean; (2) tests must use
`tokens.py::test_signer`, because the real signer requires the KMS emulator;
(3) session TTL is configured in `src/core`, not hardcoded — several past PRs
re-introduced a constant.

## How It Connects

Login flow: `src/api` receives the SSO callback →
`src/auth/session.py::create_session` persists via
[src/storage](../storage/index.md) → the opaque token returns to the client as
an HttpOnly cookie. Every subsequent request passes through `src/api`'s
middleware, which calls `validate_token`; `src/admin` additionally calls
`revoke_session` for the force-logout feature. Key rotation is invoked only by
the ops runbook, never by application code.

## Files

| File | Overview |
|---|---|
| [crypto.py](crypto.py.md) | Single chokepoint for cryptographic primitives; wraps the KMS client, dual-writes during key rotation. |
| [session.py](session.py.md) | Public face of auth: session create/validate/revoke lifecycle. |
| [tokens.py](tokens.py.md) | Token encoding, signing, expiry math; versioned format (first byte) so old tokens survive one release cycle. |
```

## Why these pages pass the bar

- **Every paragraph fails the "10 seconds of code reading" test in the right
  direction** — revocation latency, the reverted caching attempts, the lint
  rule, the 503-vs-401 mapping: none of it is recoverable from signatures.
- **Boundaries are explicit.** "Does not handle identity or authorization"
  prevents the most likely misuse.
- **Calibrated confidence.** "appears to default to 5" marks an inference;
  verified facts are stated plainly.
- **References are durable.** `path::symbol` and relative page links, no line
  numbers, no invented anchors.
- **The index is written from the file pages** — the Files-table one-liners
  and Functionality entries summarize pages that already exist, so the two
  levels never contradict each other.
- **It is short.** ~600 words of prose across the whole directory. Twice this
  length is usually restating code.

## Anti-patterns (never write these)

> `create_session(user_id: str, ttl: int) -> Session` — creates a session
> for the given user id with the given ttl and returns a Session object.

Restates the signature. Zero information.

> This directory contains three Python files that implement various
> authentication-related functionality for the application.

True of every auth directory ever written. Says nothing.

> Sessions use industry-standard best-practice secure token technology.

Marketing. If it doesn't name an invariant or a consequence, delete it.
