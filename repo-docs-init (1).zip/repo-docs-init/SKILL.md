---
name: repo-docs-init
description: Generate a complete /docs folder for a code repository — a source of truth humans and LLMs can read without opening the code. One overview page per module (module list reviewed with the user), one page per source file (strict 1:1 mapping), a functionality catalog, llms.txt + docs-index.json for LLM navigation, and a self-contained static website (no installs, works offline). Progress is tracked in docs/_PLAN.md across sessions. Use whenever the user asks to document a repository, create initial/baseline documentation, generate a docs site, or says "document this repo", "create the docs", "generate documentation for this codebase" — even if they only describe wanting an explanation of the codebase saved into the repo. ALSO use when asked to CONTINUE or RESUME documentation ("continue from the plan", "pick up where we left off") or when the repo has a docs/_PLAN.md with pending tasks.
---

# repo-docs-init: Repository Documentation Generator

Generate the `/docs` tree for a repository. Three audiences consume it:
**humans** browse it as a static website (`scripts/build_site.py`, stdlib-only,
self-contained, works offline); **LLM agents** navigate via `llms.txt` and
`docs-index.json` instead of crawling code; and downstream tooling relies on
the mapping rule below being exact.

## The two rules everything depends on

1. **Strict 1:1 file mapping.** Every source file gets exactly one page, at a
   location that is a pure function of its path:
   `src/auth/session.py → docs/files/src/auth/session.py.md`.
2. **One module = one unit of work = one overview page.** A module is a
   top-level directory by default, or whatever the repo owner sets in
   `.docsgen.yaml`'s `modules:` list. Its overview lives at
   `docs/files/<module>/index.md` (root pseudo-module → `docs/files/index.md`).

Never invent doc locations — the scripts compute every path.

## Output shape (flat, no framework)

- `docs/files/…` — the 1:1 mirror: file pages + one index per module
- `docs/functionality.md` — everything the repo can do, with the machine-parsed **Capability → Module Map** table
- `docs/overview.md` — what the system is, module one-liners, key flows, where to start reading
- `docs/architecture.md` — cross-cutting decisions + Mermaid module dependency diagram
- `docs/index.md`, `docs/llms.txt`, `docs/docs-index.json` — machine-generated, never hand-edit
- `docs/_PLAN.md` — progress plan; `docs/_drafts/` — working drafts (deleted as work completes); `docs/_site/` — the built website

## Workflow

**FIRST, check for an existing plan.** If `docs/_PLAN.md` exists, this is a
resume — run `plan.py status` and jump to the working loop. Trust the plan
file over anything you or the user remember: checked boxes were validated,
unchecked ones were not. If `status` reports commit drift, re-run
`map_repo.py`, then `plan.py refresh` (it reopens affected tasks and
regenerates their drafts, pulling existing prose back in — no work is lost).

Otherwise:

### Step 1 — Configure and map

Copy `scripts/config.yaml` to the repo root as `.docsgen.yaml` if absent
(if it exists, it's the repo owner's — use as-is). Then:

```bash
python scripts/map_repo.py --repo <repo_root>
```

This maps files, symbols, and the import graph, and prints the **proposed
module list**.

### Step 2 — Review modules with the user (mandatory checkpoint)

Show the user the proposed modules (name, file count, dependencies) in plain
language and ask whether this split matches how they think about the
codebase. Common adjustments: splitting a huge top-level directory into its
subdirectories, or merging tiny ones. To adjust, set `modules:` in
`.docsgen.yaml` and re-run `map_repo.py`. Do not proceed until the user
approves — module boundaries decide the shape of everything downstream.

### Step 3 — Create the plan

```bash
python scripts/plan.py init --repo <repo_root>
```

Writes `docs/_PLAN.md` (one task per module, dependencies-first, then
F functionality → O overview → A architecture → V final gate; ordering is
enforced), one draft per module in `docs/_drafts/`, and the page stubs.

### Working loop — one module at a time

```bash
python scripts/plan.py next --repo <repo_root>
```

For a module task `Mxx` (all of the module's writing happens in ONE file,
its draft):

1. **Read the module's actual source files** — enough to understand why the
   module exists, not just what it contains. Callers (`imported by` in the
   facts hints) usually reveal purpose best.
2. **Write the draft** (`docs/_drafts/<module>.md`): Purpose, Design notes,
   How it connects, then one short passage per file under `### <path>`.
   The first sentence of each file passage becomes its one-line summary in
   the module index, so make it carry the file's purpose on its own.
3. `python scripts/plan.py split --repo <repo_root> --task Mxx` — validates
   the draft and splits it into the final pages (module index + one page
   per file, cross-linked). Fix anything it reports.
4. `python scripts/plan.py complete --repo <repo_root> --task Mxx` — never
   claim a task done without this; a checked box means "validated".

For repos too large to read exhaustively, prioritize public API files and
the largest files, skim the rest, and say so honestly in the prose
("documented at survey level").

### Synthesis tasks — write FROM the module pages, not raw code

- **F — functionality.md**: the page a person or LLM reads to learn what
  this codebase can do. One `###` per capability: what it does (consumer's
  view), why it exists, how it flows through the modules, entry point as
  `path::symbol`. Cover everything — a capability missing here is invisible.
  Capabilities often span modules; that cross-cutting view is the point.
  Finish the **Capability → Module Map** table — it is machine-parsed into
  `llms.txt` and `docs-index.json`.
- **O — overview.md**: what the system is, the module table one-liners, the
  2–3 key flows, and a reading order for newcomers.
- **A — architecture.md**: cross-cutting decisions and their forcing
  constraints; verify the generated Mermaid diagram renders in the site
  preview and prune noisy edges.

### Final gate and website

```bash
python scripts/build_index.py --repo <repo_root>   # task V: validate; emits llms.txt + docs-index.json when clean
python scripts/build_site.py --repo <repo_root> --serve   # docs/_site/ + preview
```

`build_index.py` checks that every source file has a page, every module has
an index, every link resolves, and no TODOs or drafts remain. Fix and re-run
until clean, then `plan.py complete --task V`. The site is fully
self-contained — host it anywhere or open `index.html` directly; Mermaid
diagrams show their source offline and render as graphics online.
Spot-check a few pages in the preview.

### Ending a session before the plan is finished

Leave every task either `complete`d or honestly unchecked. Run
`plan.py status`, report progress, remind the user to commit `/docs`
including `_PLAN.md`, and give the resume instruction: *"Point the
repo-docs-init skill at this repo and say 'continue from docs/_PLAN.md'"*.

## Editorial standard — this is what makes the docs worth reading

The reader can already read code. Give them what the code cannot say, and
say it like a person.

**Write prose, not fragments.** Full sentences, connected paragraphs, plain
words — the voice of a senior engineer writing onboarding notes for a
colleague, not a spec generator. No bullet-fragment lists where a paragraph
reads better, no headings invented beyond the scaffolded ones, no
marketing tone.

**Document why, not what.** Never enumerate parameters, restate signatures,
or narrate implementation ("this function loops over users"). Every sentence
must survive: *could the reader learn this in ten seconds from the code
itself?* If yes, delete it. Mention the symbols that matter naturally inside
the prose — "`create_session` mints the opaque token and enforces the
per-user cap" — never as a table of one-liners.

**Lead with purpose and boundaries.** What problem does this module own,
and what does it deliberately not handle? Boundaries prevent misuse.

**Surface the invisible.** Invariants, constraints that forced odd-looking
choices, the two or three things a newcomer would get wrong on their first
change. If you can't find the reason for a design choice (check git history
and comments), write "reason not evident from code or history" — a wrong
rationale is worse than none.

**Calibrated confidence.** Distinguish verified from inferred: "appears to
assume single-writer access (no locking found)" is honest; stating it as
fact is not.

**Reference code by name, never line number.** `path::symbol` form —
line numbers rot, names last.

**Length discipline.** File passages are typically 2–6 sentences; module
Purpose is one or two paragraphs. Short honest pages beat long redundant
ones.

Read `references/example-draft-and-pages.md` before writing your first
draft — it shows a completed draft and the pages it splits into, at the
expected quality bar.

## Failure modes to avoid

- Skipping the module-review checkpoint. The user must approve the module
  list before `plan.py init`.
- Writing docs from file names without reading the code. Mark sections
  "not yet reviewed" rather than confabulating.
- Editing final pages by hand instead of the draft. To revise a completed
  module, run `plan.py draft --task Mxx` (regenerates the draft with the
  existing prose pulled in), edit, and split again.
- Hand-editing `_PLAN.md` checkboxes, or claiming done without
  `plan.py complete`.
- Working F/O/A before the module tasks are done — they are written from
  the module pages. The plan enforces this; don't fight it.
- Documenting tests, generated code, or vendored dependencies. The default
  config excludes them; keep it that way unless the user asks.
- Skipping validation. A clean `build_index.py` run is the definition of
  done — and the only thing that emits `llms.txt` and `docs-index.json`.
