#!/usr/bin/env python3
"""map_repo.py — Phase 0 of repo-docs-init (deterministic, no LLM).

Walks a repository and mirrors its directory structure 1:1: every directory
that (transitively) contains source files becomes a documented unit ("module"
== directory), and every source file gets exactly one doc page. Classifies
files by language, extracts public symbols, and builds an import-based
dependency graph (stdlib-filtered, best-effort for non-Python).

Output: docs/repo-map.json consumed by scaffold_docs.py, plan.py,
build_index.py, build_graphs.py and build_site.py.

Usage:
    python map_repo.py --repo /path/to/repo [--config /path/to/.docsgen.yaml]
                       [--out /path/to/repo/docs/repo-map.json]

Stdlib-only by design so it runs anywhere without installs. Graph quality is
best for Python and good-enough for JS/TS/C#/Java/Go — a weaker graph
degrades the "How It Connects" prose, never the pipeline.
"""
import argparse
import ast
import fnmatch
import json
import posixpath
import re
import sys
from pathlib import Path, PurePosixPath

# ---------------------------------------------------------------- config ---

DEFAULT_CONFIG = {
    "src_roots": ["src", "lib", "app"],   # used only to compute import names
    "ignore": [
        ".git/*", ".*/*", "docs/*", "node_modules/*", "dist/*", "build/*",
        "out/*", "bin/*", "obj/*", "target/*", "venv/*", "__pycache__/*",
        "vendor/*", "*.min.js", "*.generated.*", "*.g.cs", "*.pb.go",
        "*_pb2.py", "tests/*", "test/*", "*/tests/*", "*/test/*", "*.spec.*",
        "*.test.*", "*_test.go", "test_*.py", "*_test.py",
    ],
    "site_base_url": "https://REPLACE-ME.example.com/docs",
}

LANG_BY_EXT = {
    ".py": "python", ".js": "javascript", ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "typescript", ".cs": "csharp",
    ".java": "java", ".go": "go", ".rb": "ruby", ".rs": "rust",
    ".php": "php", ".kt": "kotlin", ".scala": "scala", ".sql": "sql",
    ".sh": "shell", ".ps1": "powershell", ".c": "c", ".h": "c",
    ".cpp": "cpp", ".hpp": "cpp",
}

# languages whose imports are dotted names (vs path strings)
DOTTED_IMPORT_LANGS = {"python", "csharp", "java", "kotlin", "scala"}

STDLIB = set(getattr(sys, "stdlib_module_names", ()))


def load_config(path: Path | None) -> dict:
    cfg = {k: (list(v) if isinstance(v, list) else v)
           for k, v in DEFAULT_CONFIG.items()}
    if path and path.exists():
        parsed = _parse_simple_yaml(path.read_text(encoding="utf-8"))
        for k, v in parsed.items():
            if isinstance(v, list) and not v:
                print(f"WARNING: '{k}' parsed as an empty list in {path.name}; "
                      "keeping built-in defaults for it (check indentation).")
                continue
            cfg[k] = v
    else:
        print("NOTE: no .docsgen.yaml found — using built-in default config.")
    return cfg


def _parse_simple_yaml(text: str) -> dict:
    """Minimal YAML subset parser (scalars + string lists, any indentation)
    so the skill has zero dependencies. Uses PyYAML instead when available."""
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except ImportError:
        pass
    out: dict = {}
    key = None
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        item = re.match(r"^\s+-\s+(.*)$", line)
        if item and key:
            out.setdefault(key, []).append(item.group(1).strip().strip("'\""))
        elif ":" in line and not line.startswith((" ", "\t")):
            key, _, val = line.partition(":")
            key, val = key.strip(), val.strip().strip("'\"")
            if val:
                out[key] = int(val) if val.isdigit() else val
                key = None
            else:
                out[key] = []
    return out

# ----------------------------------------------------------------- walk ----

def is_ignored(rel: str, patterns: list[str]) -> bool:
    p = PurePosixPath(rel)
    for pat in patterns:
        if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(p.name, pat):
            return True
        if pat.endswith("/*"):
            head = pat[:-2]
            # a directory-prefix pattern matches any path component
            if any(fnmatch.fnmatch(part, head) for part in p.parts[:-1]):
                return True
    return False


def find_source_files(repo: Path, cfg: dict) -> list[str]:
    files = []
    for f in sorted(repo.rglob("*")):
        if not f.is_file() or f.suffix.lower() not in LANG_BY_EXT:
            continue
        rel = f.relative_to(repo).as_posix()
        if is_ignored(rel, cfg["ignore"]):
            continue
        files.append(rel)
    return files

# -------------------------------------------------------------- symbols ----

def python_symbols_and_imports(path: Path) -> tuple[list[str], list[str]]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        return [], []
    syms, imps = [], []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if not node.name.startswith("_"):
                syms.append(node.name)
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imps += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            prefix = "." * node.level
            imps.append(prefix + node.module)
            # `from pkg import sub` may name a submodule, not a symbol —
            # record pkg.sub too; unresolvable symbol forms are simply misses.
            imps += [f"{prefix}{node.module}.{a.name}" for a in node.names
                     if a.name != "*"]
    return syms, imps


GENERIC_PATTERNS = {
    "javascript": (
        re.compile(r"export\s+(?:default\s+)?(?:async\s+)?(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)"),
        re.compile(r"""(?:import\s.*?from\s+|require\()\s*['"]([^'"]+)['"]"""),
    ),
    "typescript": (
        re.compile(r"export\s+(?:default\s+)?(?:async\s+)?(?:function|class|const|let|interface|type|enum)\s+([A-Za-z_$][\w$]*)"),
        re.compile(r"""(?:import\s.*?from\s+|require\()\s*['"]([^'"]+)['"]"""),
    ),
    "csharp": (
        re.compile(r"public\s+(?:static\s+|sealed\s+|abstract\s+|partial\s+)*(?:class|interface|struct|enum|record)\s+(\w+)"),
        re.compile(r"^\s*using\s+([\w.]+)\s*;", re.M),
    ),
    "java": (
        re.compile(r"public\s+(?:final\s+|abstract\s+)*(?:class|interface|enum|record)\s+(\w+)"),
        re.compile(r"^\s*import\s+([\w.]+)\s*;", re.M),
    ),
    "go": (
        re.compile(r"^func\s+(?:\([^)]+\)\s+)?([A-Z]\w*)|^type\s+([A-Z]\w*)", re.M),
        re.compile(r"""^\s*(?:import\s+)?['"]([\w./-]+)['"]""", re.M),
    ),
}


def generic_symbols_and_imports(path: Path, lang: str) -> tuple[list[str], list[str]]:
    pats = GENERIC_PATTERNS.get(lang)
    if not pats:
        return [], []
    text = path.read_text(encoding="utf-8", errors="replace")
    sym_pat, imp_pat = pats
    syms = [next(g for g in m.groups() if g) for m in sym_pat.finditer(text)]
    imps = imp_pat.findall(text)
    return list(dict.fromkeys(syms)), list(dict.fromkeys(imps))

# ---------------------------------------------------------------- graph ----

def path_forms(rel: str, src_roots: list[str]) -> set[str]:
    """All the names by which this file might be imported: full path and
    src-root-stripped path, each in slash and dotted form; packages
    (__init__) also register their parent directory."""
    stem_path = PurePosixPath(rel).with_suffix("").as_posix()
    bases = {stem_path}
    for root in src_roots:
        root = str(root).rstrip("/")
        if root and root != "." and stem_path.startswith(root + "/"):
            bases.add(stem_path[len(root) + 1:])
    forms = set()
    for b in bases:
        forms.add(b.lower())
        forms.add(b.replace("/", ".").lower())
        if b.endswith("/__init__"):
            parent = b[: -len("/__init__")]
            forms.add(parent.lower())
            forms.add(parent.replace("/", ".").lower())
    return forms


def normalize_import(imp: str) -> tuple[str, int, bool]:
    """-> (normalized, up_levels, is_relative). up_levels: how many directory
    levels above the importing file's directory the import is anchored."""
    s = imp.strip().replace("\\", "/")
    up, is_rel = 0, False
    if s.startswith("."):                       # python relative: '.x', '..x'
        dots = len(s) - len(s.lstrip("."))
        # level 1 = same package, level 2 = one package up, ...
        up, is_rel, s = dots - 1, True, s.lstrip(".")
    else:                                       # js/ts relative: './x', '../x'
        while s.startswith("./") or s.startswith("../"):
            if s.startswith("../"):
                up += 1
                s = s[3:]
            else:
                s = s[2:]
            is_rel = True
    return s.lower().rstrip("/"), up, is_rel


def resolve_file_deps(files: dict, file_imports: dict, src_roots: list[str]) -> None:
    """File→file edges within the repo. Adds 'internal_deps' and 'used_by'.
    Rules that keep the graph honest:
      - exact dotted/path matches always win;
      - relative imports resolve against the importing file's directory;
      - stdlib names never match by stem (`import logging` won't hit a repo
        file named logging.py unless the full dotted path matches);
      - bare-stem fallback applies only to single-segment imports whose stem
        is unique across the repo."""
    exact: dict[str, str] = {}
    stems: dict[str, list[str]] = {}
    for rel in files:
        for f in path_forms(rel, src_roots):
            exact[f] = rel
        stems.setdefault(PurePosixPath(rel).stem.lower(), []).append(rel)

    for rel in files:
        lang = files[rel].get("language", "")
        base_dir = posixpath.dirname(rel)
        deps = set()
        for imp in file_imports.get(rel, []):
            s, up, is_rel = normalize_import(imp)
            if not s:
                continue
            hit = None
            if is_rel:                            # anchor at the file's dir
                anchor = base_dir
                for _ in range(up):
                    anchor = posixpath.dirname(anchor)
                cand = posixpath.join(anchor, s.replace(".", "/")).lower()
                hit = exact.get(cand) or exact.get(cand.replace("/", "."))
            if hit is None:
                for cand in (s, s.replace("/", "."), s.replace(".", "/")):
                    if cand in exact:
                        hit = exact[cand]
                        break
            if hit is None:
                first = re.split(r"[./]", s, 1)[0]
                if lang == "python" and first in STDLIB:
                    continue                       # stdlib, not the repo
                if lang in DOTTED_IMPORT_LANGS or is_rel:
                    if "." not in s and "/" not in s:   # single segment only
                        cands = stems.get(s, [])
                        if len(cands) == 1 and (lang != "python" or s not in STDLIB):
                            hit = cands[0]
            if hit and hit != rel:
                deps.add(hit)
        files[rel]["internal_deps"] = sorted(deps)

    for rel in files:
        files[rel]["used_by"] = sorted(
            other for other, meta in files.items()
            if rel in meta.get("internal_deps", []))

# ------------------------------------------------------------ directories --

def ancestors(rel_dir: str):
    """'src/core/a' -> ['.', 'src', 'src/core', 'src/core/a']"""
    if rel_dir in ("", "."):
        return ["."]
    out, cur = ["."], ""
    for part in rel_dir.split("/"):
        cur = f"{cur}/{part}" if cur else part
        out.append(cur)
    return out


def build_dirs(files: dict) -> dict:
    dirs: dict[str, dict] = {}
    for rel, meta in files.items():
        d = posixpath.dirname(rel) or "."
        for a in ancestors(d):
            dirs.setdefault(a, {"files": [], "subdirs": set(),
                                "languages": set(), "public_api": set()})
        dirs[d]["files"].append(rel)
        dirs[d]["languages"].add(meta["language"])
        dirs[d]["public_api"].update(meta["public_symbols"])
        chain = ancestors(d)
        for parent, child in zip(chain, chain[1:]):
            dirs[parent]["subdirs"].add(child)

    for d, info in dirs.items():
        info["files"].sort()
        info["subdirs"] = sorted(info["subdirs"])
        info["languages"] = sorted(info["languages"])
        info["public_api"] = sorted(info["public_api"])[:40]

    # dir-level dependency edges, aggregated from file edges
    for d in dirs:
        dirs[d]["depends_on"] = set()
    for rel, meta in files.items():
        d = posixpath.dirname(rel) or "."
        for dep in meta.get("internal_deps", []):
            dd = posixpath.dirname(dep) or "."
            if dd != d:
                dirs[d]["depends_on"].add(dd)
    for d in dirs:
        dirs[d]["depends_on"] = sorted(dirs[d]["depends_on"])
    for d in dirs:
        dirs[d]["depended_on_by"] = sorted(
            k for k, v in dirs.items() if d in v["depends_on"])
    return dirs


def post_order(dirs: dict) -> list[str]:
    """Leaf directories first, root last — parents synthesize from children."""
    order = []

    def visit(d):
        for sub in dirs[d]["subdirs"]:
            visit(sub)
        order.append(d)

    visit(".")
    return order

# ----------------------------------------------------------------- main ----

def build_map(repo: Path, cfg: dict) -> dict:
    rels = find_source_files(repo, cfg)
    if not rels:
        sys.exit("ERROR: no source files found — check the ignore list in .docsgen.yaml.")

    files: dict[str, dict] = {}
    file_imports: dict[str, list[str]] = {}
    for rel in rels:
        lang = LANG_BY_EXT[Path(rel).suffix.lower()]
        path = repo / rel
        if lang == "python":
            syms, imps = python_symbols_and_imports(path)
        else:
            syms, imps = generic_symbols_and_imports(path, lang)
        with path.open(encoding="utf-8", errors="replace") as fh:
            loc = sum(1 for _ in fh)
        files[rel] = {"language": lang, "public_symbols": syms, "loc": loc}
        file_imports[rel] = imps

    resolve_file_deps(files, file_imports, cfg.get("src_roots", []))
    dirs = build_dirs(files)

    return {
        "repo_name": repo.name,
        "site_base_url": cfg.get("site_base_url", ""),
        "dirs": dirs,
        "files": files,
        "dir_order": post_order(dirs),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--config", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    cfg_path = Path(args.config) if args.config else repo / ".docsgen.yaml"
    cfg = load_config(cfg_path if cfg_path.exists() else None)
    result = build_map(repo, cfg)

    out = Path(args.out) if args.out else repo / "docs" / "repo-map.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"Mapped {len(result['files'])} files into {len(result['dirs'])} "
          f"directories -> {out}\n")
    print("Directories in bottom-up writing order (each becomes a documented "
          "module; review before scaffolding):")
    for d in result["dir_order"]:
        info = result["dirs"][d]
        depth = 0 if d == "." else d.count("/") + 1
        label = "(repo root)" if d == "." else d.rsplit("/", 1)[-1] + "/"
        deps = ", ".join(info["depends_on"]) or "-"
        print(f"  {'  ' * depth}{label:<{max(28 - 2 * depth, 8)}} "
              f"{len(info['files']):>3} file(s)  deps: {deps}")
    print("\nWriting order is bottom-up (leaf directories first, root last).")


if __name__ == "__main__":
    main()
