# repo-docs-init

An Anthropic Skill that generates and maintains a repository's `/docs` folder:
a **Sphinx (MyST Markdown) documentation site** organized by
[Diátaxis](https://diataxis.fr) that both humans and LLM agents can use to
understand the codebase without opening the code. It is the front half of a
living-documentation system; the back half is a PR-sync pipeline (separate
deliverable) that keeps the docs updated on every pull request.

## What it produces

```
docs/
├── conf.py                      Sphinx config (MyST, autodoc, napoleon, mermaid)
├── index.md                     root toctree
├── _PLAN.md                     validated progress plan (multi-session state)
├── docs-index.json              machine map: source file → page#anchor
├── llms.txt                     entry point for LLM agents
├── _static/
│   ├── repo-graph.html          interactive module/file dependency map
│   └── functionality-map.html   interactive capability ↔ module map
├── reference/                   Diátaxis: facts, mirrors the code
│   ├── modules/<module>/        one directory per module:
│   │   ├── index.md             overview: functionality provided + Files
│   │   │                        table linking every file page
│   │   └── <file-slug>.md       ONE PAGE PER SOURCE FILE (purpose, symbol
│   │                            table, behavior notes, deps, back-link)
│   ├── api/<module>.md          Sphinx autodoc pages (Python, generated)
│   ├── functionality.md         capability catalog + sequence diagrams
│   └── glossary.md
└── explanation/                 Diátaxis: understanding, the why
    ├── overview.md
    ├── architecture.md          (+ Mermaid dependency graph)
    ├── repo-map.md              wrapper for the interactive repo graph
    └── functionality-map.md     wrapper for the interactive capability map
```

The load-bearing invariant: **every source file maps to its own doc page by a
pure function of its path** (`src/auth/session.py →
docs/reference/modules/auth/sessionpy.md`; module overview →
`.../auth/index.md`). Scripts own all structure
(frontmatter, headings, anchors, links, indexes); the AI agent writes only
prose. Downstream tooling (PR sync, editor shortcuts) depends on this split.

## Contents of this skill

| File | Role |
|---|---|
| `SKILL.md` | The agent's instructions: workflow, editorial standard, Diátaxis boundaries |
| `scripts/map_repo.py` | Analyze repo: modules, symbols, dependency graphs (stdlib-only) |
| `scripts/scaffold_docs.py` | Create the docs tree with structure + TODO markers (non-destructive on re-run) |
| `scripts/plan.py` | Multi-session progress plan; tasks completable only after validation |
| `scripts/call_trace.py` | Draft Mermaid sequence diagrams from an entry point (Python) |
| `scripts/build_graphs.py` | Generate the two interactive Cytoscape.js graph pages |
| `scripts/build_index.py` | Emit docs-index.json + llms.txt; validate the whole tree; final gate |
| `scripts/config.yaml` | Template for the repo-side `.docsgen.yaml` |
| `references/page-template.md` | Structural contract: what is immutable vs editable |
| `references/page-example.md` | A completed module page at the expected quality bar |

## Setup

1. **Install the skill.** In Claude.ai / Claude Code, add the packaged
   `repo-docs-init.skill` (or place this folder in your skills directory,
   e.g. `~/.claude/skills/repo-docs-init/` for Claude Code).
2. **Repo-side config.** The first run copies `scripts/config.yaml` to the
   repo root as `.docsgen.yaml`. Review it: `src_roots`, `ignore` globs,
   `module_depth`, and `site_base_url` (URL of the published site, used by
   docs-index.json and editor shortcuts).
3. **Sphinx toolchain** (for building/viewing the site):

   ```bash
   pip install sphinx myst-parser furo sphinxcontrib-mermaid
   ```

## Usage

### Fresh run

Point the agent at a repo and say **"document this repo"** (or similar). The
agent will: run `map_repo.py` (review the printed module grouping!), run
`scaffold_docs.py`, create the plan (`plan.py init`), then work the plan
task by task — each `plan.py complete --task <ID>` validates the page and
refuses if TODO/STALE markers remain. Task order: module pages bottom-up →
`F` functionality catalog → `O` overview → `A` architecture → `G` glossary →
`D` diagrams/graphs → `V` final validation gate.

### Multi-session / resume

Codebases rarely fit one session. Progress lives in `docs/_PLAN.md` — commit
it with the docs. In a new chat, say **"continue from docs/_PLAN.md"**: the
agent runs `plan.py status` and resumes at the first unchecked task. A checked
box is a *validated* fact, not a claim, so sessions can trust each other.

If code changed between sessions, the agent re-runs map + scaffold (both
non-destructive) and `plan.py refresh`, which reopens tasks whose pages
gained new TODO/STALE markers and appends tasks for new modules.

### Building and viewing the site

```bash
sphinx-build -n docs docs/_build/html      # build (-n flags broken refs)
open docs/_build/html/index.html           # macOS (Windows: start …, Linux: xdg-open …)

# or live-reload while writing:
pip install sphinx-autobuild
sphinx-autobuild docs docs/_build/html     # http://127.0.0.1:8000
```

Autodoc imports your code at build time — the environment needs the repo's
Python dependencies installed. API pages are only as good as your docstrings.

### Manual script usage (everything the agent runs, you can run)

```bash
python scripts/map_repo.py      --repo .                       # analyze
python scripts/scaffold_docs.py --repo . --repo-url https://dev.azure.com/org/proj/_git/repo
python scripts/plan.py          init|status|next|refresh --repo .
python scripts/plan.py          complete --repo . --task M03
python scripts/call_trace.py    --repo . --entry src/auth/session.py::create_session
python scripts/build_graphs.py  --repo .
python scripts/build_index.py   --repo .                       # final gate
```

## Rules that keep the system healthy

- Never hand-edit frontmatter, anchors (`(name)=` target lines), machine
  lines (`Internal dependencies:` / `Used by:` / `Size:`), back-links, or
  `_PLAN.md` checkboxes. Fix `.docsgen.yaml` and re-run scripts instead.
- Never edit generated artifacts: `reference/api/*`, `_static/*.html`,
  section `index.md` toctrees, `docs-index.json`, `llms.txt`.
- A clean `build_index.py` run (task `V`) is the definition of done — the
  PR-sync pipeline and editor shortcuts treat it as a contract.

## Troubleshooting

- **Wrong module grouping** → adjust `module_depth` / `ignore` in
  `.docsgen.yaml`, re-run `map_repo.py`. Never hand-edit `repo-map.json`.
- **`E4 placeholder back-links`** → re-run `scaffold_docs.py` with `--repo-url`.
- **Autodoc import errors at build** → install the repo's dependencies in the
  build environment; the prose docs are unaffected.
- **Functionality map shows a placeholder** → task `F`'s Capability → Module
  table isn't written/parseable yet; finish it, re-run `build_graphs.py`.
- **Plan says commit drift** → re-run map + scaffold, then `plan.py refresh`.
