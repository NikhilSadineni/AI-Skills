#!/usr/bin/env python3
"""build_graphs.py — interactive graphs for the docs site (deterministic).

Generates two self-contained HTML pages into docs/_static/ (Cytoscape.js from
CDN, data inlined — no build step):

  repo-graph.html          modules as compound boxes containing file nodes;
                           edges are file-level dependencies; node size by
                           LOC, color by language; search filter; click a
                           node -> opens its documentation page.
  functionality-map.html   bipartite capability <-> module graph parsed from
                           reference/functionality.md's Capability→Module
                           table; click a module -> its doc page. If the
                           table isn't written yet (TODO markers), emits a
                           placeholder that says so.

Both are embedded by the scaffold's wrapper pages (explanation/repo-map.md,
explanation/functionality-map.md). Machine-owned: regenerate, never edit.

Usage:
    python build_graphs.py --repo <repo_root>
"""
import argparse
import json
import re
from pathlib import Path, PurePosixPath

LANG_COLORS = {"python": "#3572A5", "typescript": "#3178c6",
               "javascript": "#f1e05a", "csharp": "#178600", "java": "#b07219",
               "go": "#00ADD8", "rust": "#dea584", "ruby": "#701516"}

def slug(filename: str) -> str:
    return re.sub(r"[^a-z0-9_]", "", Path(filename).name.lower())

def module_html(mkey: str) -> str:
    return ("../reference/modules/_root.html" if mkey == "_root"
            else f"../reference/modules/{mkey}.html")

PAGE_TMPL = """<!doctype html><html><head><meta charset="utf-8">
<title>{title}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.28.1/cytoscape.min.js"></script>
<style>
 body{{margin:0;font:13px system-ui,sans-serif}}
 #bar{{padding:8px;background:#f6f6f6;border-bottom:1px solid #ddd;display:flex;gap:8px;align-items:center}}
 #cy{{width:100vw;height:calc(100vh - 46px)}}
 input{{padding:4px 8px;width:240px}}
 #tip{{color:#666}}
</style></head><body>
<div id="bar"><input id="q" placeholder="filter nodes…">
<span id="tip">{tip}</span></div>
<div id="cy"></div>
<script>
const elements = {elements};
const cy = cytoscape({{
  container: document.getElementById('cy'),
  elements: elements,
  layout: {{ name: '{layout}', animate: false, nodeDimensionsIncludeLabels: true }},
  wheelSensitivity: 0.2,
  style: [
    {{ selector: 'node', style: {{ label: 'data(label)', 'font-size': 11,
       'text-valign': 'center', 'background-color': 'data(color)',
       width: 'data(size)', height: 'data(size)', color: '#222' }} }},
    {{ selector: ':parent', style: {{ 'text-valign': 'top', 'font-weight': 'bold',
       'background-opacity': 0.08, 'border-color': '#999' }} }},
    {{ selector: 'edge', style: {{ width: 1.5, 'curve-style': 'bezier',
       'target-arrow-shape': 'triangle', 'line-color': '#bbb',
       'target-arrow-color': '#bbb' }} }},
    {{ selector: '.dim', style: {{ opacity: 0.12 }} }},
    {{ selector: '.cap', style: {{ shape: 'round-rectangle', 'text-valign': 'center',
       width: 'label', 'padding': '10px' }} }}
  ]
}});
cy.on('tap', 'node', e => {{
  const url = e.target.data('url');
  if (url) window.top.location.href = url;
}});
document.getElementById('q').addEventListener('input', e => {{
  const q = e.target.value.toLowerCase();
  cy.elements().removeClass('dim');
  if (!q) return;
  const hit = cy.nodes().filter(n => (n.data('label')||'').toLowerCase().includes(q));
  cy.elements().not(hit.closedNeighborhood()).addClass('dim');
}});
</script></body></html>
"""

def repo_graph(rmap: dict) -> str:
    els = []
    for mkey, m in rmap["modules"].items():
        els.append({"data": {"id": f"mod:{mkey}", "label": mkey,
                             "color": "#eeeeee", "size": 30,
                             "url": module_html(mkey)}})
    for rel, meta in rmap["files"].items():
        mkey = next((k for k, m in rmap["modules"].items()
                     if rel in m["source_files"]), None)
        if not mkey:
            continue
        loc = meta.get("loc", 10)
        els.append({"data": {
            "id": rel, "label": PurePosixPath(rel).name, "parent": f"mod:{mkey}",
            "color": LANG_COLORS.get(meta.get("language"), "#999999"),
            "size": max(18, min(70, 12 + loc // 15)),
            "url": f"{module_html(mkey)}#{slug(rel)}"}})
    for rel, meta in rmap["files"].items():
        for dep in meta.get("internal_deps", []):
            els.append({"data": {"id": f"{rel}->{dep}",
                                 "source": rel, "target": dep}})
    return PAGE_TMPL.format(
        title="Repository Map", layout="cose",
        tip="click a node to open its docs · node size = lines of code · color = language",
        elements=json.dumps(els))

CAP_ROW_RE = re.compile(r"^\|\s*(?!Capability|[-: ]+\|)([^|]+?)\s*\|\s*([^|]+?)\s*\|", re.M)
MOD_LINK_RE = re.compile(r"\[([^\]]+)\]\(modules/([^)#]+)\.md")

def functionality_graph(docs: Path, rmap: dict) -> str:
    func = docs / "reference" / "functionality.md"
    caps = []
    if func.exists():
        text = func.read_text(encoding="utf-8")
        if "TODO:PROSE" not in text:
            for m in CAP_ROW_RE.finditer(text):
                cap, mods_cell = m.group(1).strip(), m.group(2)
                mods = [mm.group(2) for mm in MOD_LINK_RE.finditer(mods_cell)]
                if cap and mods:
                    caps.append((cap, mods))
    if not caps:
        return ("<!doctype html><html><body style='font:14px system-ui;padding:2em'>"
                "<h2>Functionality map not available yet</h2>"
                "<p>The Capability → Module table in "
                "<code>reference/functionality.md</code> hasn't been written "
                "(task <code>F</code> in docs/_PLAN.md). Complete it, then re-run "
                "<code>scripts/build_graphs.py</code>.</p></body></html>")
    els, used_mods = [], set()
    for i, (cap, mods) in enumerate(caps):
        els.append({"data": {"id": f"cap:{i}", "label": cap, "color": "#e8d5f9",
                             "size": 40, "url": "../reference/functionality.html"},
                    "classes": "cap"})
        for mod in mods:
            used_mods.add(mod)
            els.append({"data": {"id": f"c{i}->m:{mod}",
                                 "source": f"cap:{i}", "target": f"m:{mod}"}})
    for mod in sorted(used_mods):
        els.append({"data": {"id": f"m:{mod}", "label": mod, "color": "#cfe8fc",
                             "size": 34, "url": f"../reference/modules/{mod}.html"}})
    return PAGE_TMPL.format(
        title="Functionality Map", layout="cose",
        tip="capabilities ↔ implementing modules · click to open docs",
        elements=json.dumps(els))

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    args = ap.parse_args()
    repo = Path(args.repo).resolve()
    docs = repo / "docs"
    rmap = json.loads((docs / "repo-map.json").read_text(encoding="utf-8"))
    static = docs / "_static"
    static.mkdir(parents=True, exist_ok=True)
    (static / "repo-graph.html").write_text(repo_graph(rmap), encoding="utf-8")
    fg = functionality_graph(docs, rmap)
    (static / "functionality-map.html").write_text(fg, encoding="utf-8")
    placeholder = "not available yet" in fg
    print(f"repo-graph.html: {sum(len(m['source_files']) for m in rmap['modules'].values())} "
          f"file nodes in {len(rmap['modules'])} modules")
    print("functionality-map.html: "
          + ("PLACEHOLDER (write the capability table first, then re-run)"
             if placeholder else "built from capability table"))

if __name__ == "__main__":
    main()
