# repo-docs-init

A Claude skill that generates a complete `/docs` folder for a code
repository — a source of truth that humans and LLM agents can read without
opening the code.

## What it produces

```
docs/
├── index.md              landing page (generated)
├── overview.md           what the system is, modules, key flows
├── functionality.md      everything the repo can do + Capability → Module Map
├── architecture.md       cross-cutting decisions + Mermaid module diagram
├── llms.txt              LLM navigation entry point (generated)
├── docs-index.json       machine map: source file → doc page (generated)
├── files/                strict 1:1 mirror of the source tree
│   ├── <module>/index.md   one overview page per module
│   └── <path>.md           one page per source file
├── _PLAN.md              progress plan (resumable across sessions)
└── _site/                self-contained static website (generated)
```

## Key design points

- **One task per module.** Modules default to top-level directories; the
  repo owner can override with `modules:` in `.docsgen.yaml`. The skill
  shows the proposed module list and asks the user to approve it before any
  writing starts.
- **Draft-then-split workflow.** All of a module's prose is written in a
  single draft file (`docs/_drafts/<module>.md`), then a script splits it
  mechanically into the final pages: one module index plus one page per
  source file (strict 1:1), with frontmatter, summary tables, and
  cross-links generated. Drafts regenerate with existing prose pulled back
  in, so revising a module never loses work.
- **Validated progress.** `docs/_PLAN.md` tracks one checkbox per module
  plus the synthesis tasks (functionality → overview → architecture →
  final gate). A box can only be checked by passing validation; ordering is
  enforced (synthesis pages are written from the module pages).
- **Self-contained website.** `build_site.py` is stdlib-only and produces a
  site that works offline and from `file://` — sidebar with per-module
  file trees, filter box, breadcrumbs. Mermaid diagrams show their source
  as readable text offline and upgrade to rendered graphics when online.
- **LLM-navigable.** `llms.txt` lists capabilities and module purposes;
  `docs-index.json` maps every source file to its page and module page,
  every module to its dependencies, and every capability to its modules.

## Scripts

| Script | Role |
|---|---|
| `map_repo.py` | Walk the repo, extract symbols + import graph, propose modules |
| `plan.py` | Plan init/status/next/refresh; draft generation; split; validated complete |
| `build_index.py` | Final gate: validate everything, emit `llms.txt` + `docs-index.json` |
| `build_site.py` | Render the self-contained static website (`--serve` to preview) |
| `config.yaml` | Template for the repo's `.docsgen.yaml` |

All scripts are stdlib-only Python 3.10+. No installs required.

## Typical run

```bash
python scripts/map_repo.py  --repo <repo>        # review module list with user
python scripts/plan.py init --repo <repo>
python scripts/plan.py next --repo <repo>        # loop: write draft → split → complete
python scripts/plan.py split    --repo <repo> --task M01
python scripts/plan.py complete --repo <repo> --task M01
# ... F, O, A tasks, then:
python scripts/build_index.py --repo <repo>      # task V
python scripts/build_site.py  --repo <repo> --serve
```

To resume in a new session: `plan.py status`, then continue the loop. If
the code changed: `map_repo.py`, then `plan.py refresh`.
