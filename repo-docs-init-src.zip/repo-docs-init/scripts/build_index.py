#!/usr/bin/env python3
"""build_index.py — Phase 3 of repo-docs-init (deterministic).

Emits docs/docs-index.json and docs/llms.txt from repo-map.json plus the
written pages, stamps last_synced_commit into every page's frontmatter (when
inside a git repo), and VALIDATES the docs tree:

  E1  source file has no anchored section on its module page
  E2  page still contains TODO:PROSE or STALE:REMOVED markers
  E3  internal relative link points at a missing page
  E4  source back-link still contains REPO_URL_PLACEHOLDER
  E5  module page listed in repo-map is missing entirely

Exit code is non-zero if any error remains — a clean run is the contract
that downstream tooling (PR sync pipeline, editor shortcut) relies on.

Usage:
    python build_index.py --repo /path/to/repo [--map docs/repo-map.json]
"""
import argparse
import json
import re
import subprocess
import sys
from datetime import date
from pathlib import Path

def slug(filename: str) -> str:
    return re.sub(r"[^a-z0-9_]", "", Path(filename).name.lower())

def page_path(mkey: str) -> str:
    return ("reference/modules/_root.md" if mkey == "_root"
            else f"reference/modules/{mkey}.md")

def git_head(repo: Path) -> str:
    try:
        return subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                              cwd=repo, capture_output=True, text=True,
                              check=True).stdout.strip()
    except Exception:
        return "UNSTAMPED"

def first_line_after_h1(text: str) -> str:
    """Best-effort one-line description of a page for llms.txt: first prose
    line under ## Purpose (module pages) or under the H1 (synthesis pages)."""
    m = re.search(r"^## Purpose\s*\n+(.+)$", text, re.M)
    if not m:
        m = re.search(r"^# .+\n+(.+)$", text, re.M)
    if not m:
        return ""
    line = m.group(1).strip()
    return "" if line.startswith("<!--") else line[:160]

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--map", default=None)
    ap.add_argument("--allow-todos", action="store_true",
                    help="Downgrade E2 (remaining TODO/STALE markers) to a warning.")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    docs = repo / "docs"
    map_path = Path(args.map) if args.map else docs / "repo-map.json"
    rmap = json.loads(map_path.read_text(encoding="utf-8"))
    commit = git_head(repo)
    errors: list[str] = []
    warnings: list[str] = []

    # ---- validate + stamp module pages -----------------------------------
    for mkey, m in rmap["modules"].items():
        p = docs / page_path(mkey)
        if not p.exists():
            errors.append(f"E5 missing page: docs/{page_path(mkey)}")
            continue
        text = p.read_text(encoding="utf-8")

        for rel in m["source_files"]:
            a = slug(Path(rel).name)
            if f"{{#{a}}}" not in text and f"({a})=" not in text:
                errors.append(f"E1 {page_path(mkey)}: no section for {rel}")

        for marker, label in (("TODO:PROSE", "TODO"), ("STALE:REMOVED", "STALE")):
            n = text.count(marker)
            if n:
                msg = f"E2 {page_path(mkey)}: {n} {label} marker(s) remain"
                (warnings if args.allow_todos else errors).append(msg)

        if "REPO_URL_PLACEHOLDER" in text:
            errors.append(f"E4 {page_path(mkey)}: source back-links are placeholders "
                          f"(re-run scaffold_docs.py with --repo-url)")

        linkable = re.sub(r"<!--.*?-->", "", text, flags=re.S)  # comments are instructions, not content
        for link in re.findall(r"\]\((?!https?://|#)([^)#]+\.md)", linkable):
            if not (p.parent / link).resolve().exists():
                errors.append(f"E3 {page_path(mkey)}: broken link -> {link}")

        # stamp provenance
        new = re.sub(r"^last_synced_commit: .*$",
                     f"last_synced_commit: {commit}", text, count=1, flags=re.M)
        new = re.sub(r"^last_synced_at: .*$",
                     f"last_synced_at: {date.today().isoformat()}", new, count=1, flags=re.M)
        if new != text:
            p.write_text(new, encoding="utf-8")

    for name in ("explanation/overview.md", "explanation/architecture.md",
                 "reference/functionality.md"):
        p = docs / name
        if p.exists():
            text = p.read_text(encoding="utf-8")
            n = text.count("TODO:PROSE")
            if n:
                (warnings if args.allow_todos else errors).append(
                    f"E2 {name}: {n} TODO marker(s) remain")
            linkable = re.sub(r"<!--.*?-->", "", text, flags=re.S)
            for link in re.findall(r"\]\((?!https?://|#)([^)#]+\.md)", linkable):
                if not (p.parent / link).resolve().exists():
                    errors.append(f"E3 {name}: broken link -> {link}")

    # ---- docs-index.json ---------------------------------------------------
    index = {
        "site_base_url": rmap.get("site_base_url", ""),
        "generated_from_commit": commit,
        "files": {
            rel: {"page": page_path(mkey), "anchor": slug(Path(rel).name)}
            for mkey, m in rmap["modules"].items()
            for rel in m["source_files"]
        },
        "modules": {
            mkey: {"page": page_path(mkey), "depends_on": m["depends_on"]}
            for mkey, m in rmap["modules"].items()
        },
    }
    (docs / "docs-index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")

    # ---- llms.txt ------------------------------------------------------------
    lines = [f"# {rmap['repo_name']}", "",
             "> Repository documentation. Start with the overview, use the",
             "> index for file-level lookup, then read module pages as needed.", "",
             "## Core", "",
             "- [Overview](explanation/overview.md): system map — components and key flows",
             "- [Functionality Catalog](reference/functionality.md): every capability the system provides — what, why, entry points",
             "- [Architecture](explanation/architecture.md): cross-cutting decisions, dependency graph",
             "- [File index](docs-index.json): machine map source file -> doc page#anchor", "",
             "## Modules", ""]
    for mkey in rmap["suggested_writing_order"]:
        p = docs / page_path(mkey)
        desc = first_line_after_h1(p.read_text(encoding="utf-8")) if p.exists() else ""
        lines.append(f"- [{mkey}]({page_path(mkey)}): {desc}")
    (docs / "llms.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

    # ---- report ---------------------------------------------------------------
    print(f"docs-index.json: {len(index['files'])} files, {len(index['modules'])} modules")
    print(f"llms.txt: written | provenance stamped: {commit}")
    for w in warnings:
        print(f"  WARN {w}")
    if errors:
        print(f"\nVALIDATION FAILED ({len(errors)} error(s)):")
        for e in errors:
            print(f"  {e}")
        sys.exit(1)
    print("Validation: CLEAN — docs tree satisfies the pipeline contract.")

if __name__ == "__main__":
    main()
