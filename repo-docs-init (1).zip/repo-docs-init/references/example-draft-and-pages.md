# Example: a module draft and the pages it becomes

Read this before writing your first draft. It shows the quality bar: prose a
senior engineer would write in onboarding notes — full sentences, why-level,
honest — and how the split turns one draft into the final 1:1 pages.

## The draft you write (docs/_drafts/src__auth.md)

The stub arrives with TODO markers and `<!-- facts: ... -->` hints (stripped
automatically on split). You replace the TODOs:

```markdown
# Module: src/auth

## Purpose

This module owns authentication state for the service. Everything that
mints, verifies, or revokes a user's proof of identity lives here, so the
rest of the codebase can treat "is this request authenticated?" as a single
question with a single answer. It deliberately does not handle
authorization — deciding what an authenticated user may do is left to the
callers in `src/api`.

## Design notes

All hashing goes through `crypto.py` rather than being inlined at call
sites, so the algorithm can be rotated in one place. Session tokens are
opaque hashes rather than self-describing tokens, because revocation must
land server-side immediately. A newcomer's most likely mistake is to sign a
first-party session with `tokens/jwt.py` — don't; sessions must stay
revocable.

## How it connects

`src/api` is the only caller: its route handlers call `create_session` when
a login succeeds and pass the returned token back to the client. Internally,
both session handling and JWT signing funnel through `crypto.py`, so no
other file in the repo touches a hash function directly.

## Files

### src/auth/session.py

Creates and revokes user sessions. `create_session` derives an opaque
session token from the user id via the shared hash, and `revoke_session` is
the seam for server-side invalidation. It exists as its own file so session
lifecycle stays separate from token-format concerns.

### src/auth/crypto.py

Wraps the hashing primitive the whole auth module relies on. `hash_token`
turns any raw string into a SHA-256 hex digest, and keeping it here means an
algorithm change touches exactly one file.
```

Why this passes review:

- **The first sentence of each file passage stands alone** — it becomes that
  file's summary row in the module index ("Creates and revokes user
  sessions.").
- **Symbols appear inside prose**, doing work in the sentence — never as a
  table of signature restatements.
- **Every claim is something the code can't say in ten seconds**: the
  revocation constraint, the rotation rationale, the newcomer trap.
- **Boundaries are explicit**: what the module deliberately does not handle.

## What the split produces

`plan.py split` turns that draft into a module index plus one page per file
(strict 1:1). You never write these by hand — frontmatter, tables,
cross-links and the machine footer are generated:

`docs/files/src/auth/index.md`:

```markdown
---
module: src/auth
files: [src/auth/crypto.py, src/auth/session.py]
depends_on: []
depended_on_by: [src/api]
languages: [python]
last_synced_commit: UNSTAMPED
last_synced_at: 2026-07-12
---

# src/auth

## Purpose
(your Purpose prose)

## Design notes
(your Design notes prose)

## How it connects
(your How it connects prose)

## Files

| File | What it does |
|---|---|
| [crypto.py](crypto.py.md) | Wraps the hashing primitive the whole auth module relies on. |
| [session.py](session.py.md) | Creates and revokes user sessions. |
```

`docs/files/src/auth/session.py.md`:

```markdown
---
source_path: src/auth/session.py
module: src/auth
language: python
public_symbols: [create_session, revoke_session]
internal_deps: [src/auth/crypto.py]
used_by: [src/api/routes.py]
loc: 7
last_synced_commit: UNSTAMPED
last_synced_at: 2026-07-12
---

# src/auth/session.py

(your file passage, verbatim)

---

<!-- machine-footer -->
**Depends on:** [src/auth/crypto.py](crypto.py.md)
**Used by:** [src/api/routes.py](../api/routes.py.md)
**Module:** [src/auth](index.md) · 7 lines of python
```

## Bad prose, for contrast

> `session.py` — Contains functions for sessions.
> | Symbol | Description |
> |---|---|
> | `create_session` | Creates a session |
> | `revoke_session` | Revokes a session |

Everything here is visible in ten seconds of reading the code; the table
restates signatures; nothing explains why the file exists, what would break,
or what a newcomer should know. This is the style to avoid.
