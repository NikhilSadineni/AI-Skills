#!/usr/bin/env python3
"""plan.py — resumable work plan for repo-docs-init (deterministic).

Large codebases can't be documented in one session. This script maintains
docs/_PLAN.md: an ordered task list where a task can only be marked done by
passing per-page validation. The plan file — not any session's memory — is
the source of truth, so a fresh session can resume exactly where the last
one stopped.

One task per repository directory (index.md + its direct file pages),
ordered bottom-up (leaf directories first), then the synthesis tasks:
F functionality catalog, O overview, A architecture, G glossary,
D diagrams/graphs, V final validation gate. Ordering is ENFORCED: synthesis
tasks refuse to complete while directory tasks are pending; D requires F;
V requires everything else.

Subcommands:
    init      Create docs/_PLAN.md from repo-map.json (refuses if it exists).
    status    Show progress counts and the next few pending tasks.
    next      Print the single next pending task with work instructions.
    complete  Validate one task's pages; mark done only if validation passes.
    refresh   Re-sync plan with reality: reopen done tasks whose pages have
              new TODO/STALE markers, append tasks for new directories.

Usage:
    python plan.py init|status|next|refresh --repo <path>
    python plan.py complete --repo <path> --task M03
"""
import argparse
import json
import re
import subprocess
import sys
from datetime import date
from pathlib import Path

PLAN_REL = "docs/_PLAN.md"
TASK_RE = re.compile(r"^- \[(?P<st>[ x])\] `(?P<id>[A-Z]\d*)` "
                     r"(?P<page>\S+) — (?P<desc>.*?)(?: — done (?P<meta>.*))?$")
SYNTH_IDS = ("F", "O", "A", "G", "D", "V")

HEADER = """# Documentation Plan — {repo}

generated_from_commit: {commit}
updated: {today}

## How to resume in a fresh session

This file is the source of truth for documentation progress — trust it over
any session memory. To continue:

1. Run `python <skill>/scripts/plan.py status --repo <repo_root>` to see
   what's done and what's next. Do NOT re-run map/scaffold unless `refresh`
   or `status` tells you the code has drifted.
2. Take the next pending task (`plan.py next`), do the work per SKILL.md
   (write prose into the TODO markers of that task's pages only).
3. Mark it done with `plan.py complete --task <ID>` — this validates the
   pages and refuses if TODO/STALE markers remain, so a checked box is a
   verified fact, not a claim.
4. Repeat until the session budget runs out. Task order is enforced:
   synthesis tasks (F/O/A/G) require all directory tasks; D requires F;
   the final gate `V` requires everything else.

If the code changed since this plan was generated, run map_repo.py and
scaffold_docs.py again (non-destructive), then `plan.py refresh`.

## Tasks

Statuses: `[ ]` pending · `[x]` done (validated). Work top to bottom —
directory order is bottom-up (leaf directories first); synthesis pages come
after all directories because they are written FROM the directory pages.

"""

# ------------------------------------------------------------- plan I/O ----

def git_head(repo: Path) -> str:
    try:
        return subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                              cwd=repo, capture_output=True, text=True,
                              check=True).stdout.strip()
    except Exception:
        return "UNSTAMPED"


def load_map(repo: Path) -> dict:
    p = repo / "docs" / "repo-map.json"
    if not p.exists():
        sys.exit("ERROR: docs/repo-map.json not found — run map_repo.py first.")
    return json.loads(p.read_text(encoding="utf-8"))


def dir_index_rel(d: str) -> str:
    return "reference/index.md" if d == "." else f"reference/{d}/index.md"


def build_tasks(rmap: dict) -> list[dict]:
    tasks = []
    for i, d in enumerate(rmap["dir_order"], 1):
        n = len(rmap["dirs"][d]["files"])
        label = "(repo root)" if d == "." else f"`{d}`"
        tasks.append({"id": f"M{i:02d}", "page": dir_index_rel(d),
                      "desc": f"write prose for directory {label} "
                              f"(index + {n} file page(s))",
                      "done": False, "meta": ""})
    tasks += [
        {"id": "F", "page": "reference/functionality.md",
         "desc": "capability catalog — every capability: what/why/entry points/directories (write from directory pages)",
         "done": False, "meta": ""},
        {"id": "O", "page": "explanation/overview.md",
         "desc": "system overview — components, key flows, reading order (write from directory pages)",
         "done": False, "meta": ""},
        {"id": "A", "page": "explanation/architecture.md",
         "desc": "cross-cutting decisions; verify/prune Mermaid graph",
         "done": False, "meta": ""},
        {"id": "G", "page": "reference/glossary.md",
         "desc": "domain terms explained more than once while writing",
         "done": False, "meta": ""},
        {"id": "D", "page": "explanation/repo-map.md",
         "desc": "interactive graphs (build_graphs.py) + refine capability sequence diagrams (call_trace.py drafts)",
         "done": False, "meta": ""},
        {"id": "V", "page": "(all)",
         "desc": "final gate: build_index.py exits clean (index + llms.txt + provenance)",
         "done": False, "meta": ""},
    ]
    return tasks


def write_plan(repo: Path, rmap: dict, tasks: list[dict], commit: str) -> None:
    lines = [HEADER.format(repo=rmap["repo_name"], commit=commit,
                           today=date.today().isoformat()).rstrip(), ""]
    for t in tasks:
        box = "x" if t["done"] else " "
        meta = f" — done {t['meta']}" if t["done"] and t["meta"] else ""
        lines.append(f"- [{box}] `{t['id']}` {t['page']} — {t['desc']}{meta}")
    (repo / PLAN_REL).write_text("\n".join(lines) + "\n", encoding="utf-8")


def read_plan(repo: Path) -> tuple[str, list[dict]]:
    p = repo / PLAN_REL
    if not p.exists():
        sys.exit(f"ERROR: {PLAN_REL} not found — run `plan.py init` first.")
    text = p.read_text(encoding="utf-8")
    tasks = []
    for line in text.splitlines():
        m = TASK_RE.match(line)
        if m:
            tasks.append({"id": m["id"], "page": m["page"], "desc": m["desc"],
                          "done": m["st"] == "x", "meta": m["meta"] or ""})
    if not tasks:
        sys.exit(f"ERROR: no parseable tasks in {PLAN_REL}.")
    return text, tasks

# --------------------------------------------------------- order + checks --

def blocked_by(tasks: list[dict], t: dict) -> list[str]:
    """Enforced ordering: F/O/A/G need all M tasks; D needs F (and all M);
    V needs everything."""
    pending = lambda pred: [x["id"] for x in tasks if pred(x) and not x["done"]]
    if t["id"] in ("F", "O", "A", "G", "D"):
        mods = pending(lambda x: x["id"].startswith("M"))
        if mods:
            return mods
    if t["id"] == "D":
        f = pending(lambda x: x["id"] == "F")
        if f:
            return f
    if t["id"] == "V":
        return pending(lambda x: x["id"] != "V")
    return []


def page_errors(docs: Path, rel: str) -> list[str]:
    p = docs / rel
    if not p.exists():
        return [f"page docs/{rel} does not exist"]
    text = p.read_text(encoding="utf-8")
    errs = []
    for marker in ("TODO:PROSE", "STALE:REMOVED"):
        n = text.count(marker)
        if n:
            errs.append(f"{n} {marker} marker(s) remain in docs/{rel}")
    if "REPO_URL_PLACEHOLDER" in text:
        errs.append(f"placeholder back-link in docs/{rel} "
                    "(re-run scaffold with --repo-url)")
    return errs


def validate_task(repo: Path, task: dict, rmap: dict) -> list[str]:
    """Per-task validation. Empty list = pass."""
    docs = repo / "docs"
    if task["id"] == "D":
        errs = []
        for f in ("_static/repo-graph.html", "_static/functionality-map.html"):
            if not (docs / f).exists():
                errs.append(f"docs/{f} missing — run scripts/build_graphs.py")
        fmap = docs / "_static" / "functionality-map.html"
        if fmap.exists() and "not available yet" in fmap.read_text(encoding="utf-8"):
            errs.append("functionality-map.html is a placeholder — complete "
                        "task F's Capability → Module Map, re-run build_graphs.py")
        func = docs / "reference" / "functionality.md"
        if func.exists() and "sequenceDiagram" not in func.read_text(encoding="utf-8"):
            errs.append("no sequenceDiagram found in reference/functionality.md — "
                        "add a refined ```mermaid flow per major capability")
        return errs

    if task["id"] == "V":
        script = Path(__file__).parent / "build_index.py"
        r = subprocess.run([sys.executable, str(script), "--repo", str(repo)],
                           capture_output=True, text=True)
        return [] if r.returncode == 0 else ["build_index.py failed:\n" + r.stdout.strip()]

    errs = page_errors(docs, task["page"])

    # directory tasks: index + every direct file page must be clean and linked
    d = next((k for k in rmap["dirs"] if dir_index_rel(k) == task["page"]), None)
    if d is not None:
        info = rmap["dirs"][d]
        idx = docs / task["page"]
        idx_text = idx.read_text(encoding="utf-8") if idx.exists() else ""
        for rel in info["files"]:
            name = Path(rel).name
            if f"]({name}.md)" not in idx_text:
                errs.append(f"index Files table has no row for {rel}")
            errs += page_errors(docs, f"{task['page'].rsplit('/', 1)[0]}/{name}.md")
        for sub in info["subdirs"]:
            name = sub.rsplit("/", 1)[-1]
            if f"]({name}/index.md)" not in idx_text:
                errs.append(f"index Subdirectories table has no row for {sub}")
    return errs

# ------------------------------------------------------------ commands -----

def cmd_init(repo: Path) -> None:
    if (repo / PLAN_REL).exists():
        sys.exit(f"ERROR: {PLAN_REL} already exists — use `refresh`, or delete it to restart.")
    rmap = load_map(repo)
    write_plan(repo, rmap, build_tasks(rmap), git_head(repo))
    print(f"Plan created: {PLAN_REL} "
          f"({len(rmap['dirs'])} directory tasks + 6 synthesis/validation tasks)")


def cmd_status(repo: Path) -> None:
    _, tasks = read_plan(repo)
    done = [t for t in tasks if t["done"]]
    pending = [t for t in tasks if not t["done"]]
    print(f"Progress: {len(done)}/{len(tasks)} tasks done "
          f"({100 * len(done) // len(tasks)}%)")
    plan_commit = re.search(r"generated_from_commit: (\S+)",
                            (repo / PLAN_REL).read_text(encoding="utf-8"))
    head = git_head(repo)
    if plan_commit and plan_commit.group(1) not in ("UNSTAMPED", head):
        print(f"NOTE: repo HEAD ({head}) differs from plan commit "
              f"({plan_commit.group(1)}). If source code changed, re-run "
              "map_repo.py + scaffold_docs.py, then `plan.py refresh`.")
    if pending:
        print("\nNext tasks:")
        for t in pending[:5]:
            print(f"  [{t['id']}] {t['page']} — {t['desc']}")
    else:
        print("All tasks complete. Documentation is done and validated.")


def cmd_next(repo: Path) -> None:
    _, tasks = read_plan(repo)
    t = next((t for t in tasks if not t["done"]), None)
    if not t:
        print("All tasks complete.")
        return
    print(f"NEXT TASK [{t['id']}]: {t['desc']}")
    if t["id"] == "V":
        print("Run: python <skill>/scripts/build_index.py --repo <repo_root> ; "
              "fix errors; then plan.py complete --task V")
    elif t["id"] == "D":
        print("1. Run: python <skill>/scripts/build_graphs.py --repo <repo_root>\n"
              "2. Draft a sequenceDiagram per major capability with call_trace.py, "
              "refine, embed in reference/functionality.md.\n"
              f"3. Run: plan.py complete --task {t['id']}")
    else:
        print(f"1. Open docs/{t['page']} and read the source files it covers.\n"
              f"2. Replace every TODO:PROSE marker per SKILL.md's editorial standard\n"
              f"   (and resolve any STALE:REMOVED markers).\n"
              f"3. Run: plan.py complete --task {t['id']}")


def cmd_complete(repo: Path, task_id: str) -> None:
    text, tasks = read_plan(repo)
    t = next((t for t in tasks if t["id"] == task_id), None)
    if not t:
        sys.exit(f"ERROR: no task `{task_id}` in plan.")
    if t["done"]:
        print(f"Task {task_id} is already done.")
        return
    blockers = blocked_by(tasks, t)
    if blockers:
        shown = ", ".join(blockers[:8]) + (" …" if len(blockers) > 8 else "")
        sys.exit(f"ORDER ENFORCED: task {task_id} cannot complete while "
                 f"these are pending: {shown}\nSynthesis pages are written "
                 "FROM the directory pages — finish those first.")
    rmap = load_map(repo)
    errs = validate_task(repo, t, rmap)
    if errs:
        print(f"VALIDATION FAILED for [{task_id}] — task stays pending:")
        for e in errs:
            print(f"  - {e}")
        sys.exit(1)
    stamp = f"{date.today().isoformat()} @{git_head(repo)}"
    old = f"- [ ] `{t['id']}` {t['page']} — {t['desc']}"
    new = f"- [x] `{t['id']}` {t['page']} — {t['desc']} — done {stamp}"
    text = text.replace(old, new, 1)
    text = re.sub(r"^updated: .*$", f"updated: {date.today().isoformat()}",
                  text, count=1, flags=re.M)
    (repo / PLAN_REL).write_text(text, encoding="utf-8")
    remaining = sum(1 for x in tasks if not x["done"]) - 1
    print(f"[{task_id}] validated and marked done. {remaining} task(s) remaining.")


def cmd_refresh(repo: Path) -> None:
    text, tasks = read_plan(repo)
    rmap = load_map(repo)
    reopened, appended, retired = [], [], []

    # retire directory tasks whose directory no longer exists in the map
    valid_pages = {dir_index_rel(d) for d in rmap["dir_order"]}
    for t in tasks:
        if re.fullmatch(r"M\d+", t["id"]) and t["page"] not in valid_pages:
            text = re.sub(
                rf"^- \[.\] `{t['id']}` .*$",
                f"- [x] `{t['id']}` {t['page']} — obsolete: directory removed "
                f"from repo (retired by refresh; delete its stale pages and "
                f"table rows)",
                text, count=1, flags=re.M)
            retired.append(t["id"])

    for t in tasks:                    # reopen regressed tasks
        if t["id"] in retired:
            continue
        if t["done"] and t["id"] != "V" and validate_task(repo, t, rmap):
            old = f"- [x] `{t['id']}` {t['page']} — {t['desc']}" + \
                  (f" — done {t['meta']}" if t["meta"] else "")
            new = f"- [ ] `{t['id']}` {t['page']} — {t['desc']} (reopened: page has new markers)"
            if old in text:
                text = text.replace(old, new, 1)
                reopened.append(t["id"])
    if reopened:
        text = re.sub(r"^- \[x\] `V` (.*?)( — done .*)?$", r"- [ ] `V` \1",
                      text, count=1, flags=re.M)

    known_pages = {t["page"] for t in tasks}
    max_m = max((int(t["id"][1:]) for t in tasks
                 if re.fullmatch(r"M\d+", t["id"])), default=0)
    new_lines = []
    for d in rmap["dir_order"]:
        pg = dir_index_rel(d)
        if pg not in known_pages:
            max_m += 1
            n = len(rmap["dirs"][d]["files"])
            label = "(repo root)" if d == "." else f"`{d}`"
            new_lines.append(f"- [ ] `M{max_m:02d}` {pg} — write prose for "
                             f"directory {label} (index + {n} file page(s)) "
                             f"(added by refresh)")
            appended.append(f"M{max_m:02d}")
    if new_lines:
        text = re.sub(r"^(- \[.\] `F` )", "\n".join(new_lines) + "\n\\1",
                      text, count=1, flags=re.M)
        text = re.sub(r"^- \[x\] `F` (.*?)( — done .*)?$",
                      r"- [ ] `F` \1 (reopened: new directorie(s) added)",
                      text, count=1, flags=re.M)
        text = re.sub(r"^- \[x\] `V` (.*?)( — done .*)?$", r"- [ ] `V` \1",
                      text, count=1, flags=re.M)

    text = re.sub(r"^updated: .*$", f"updated: {date.today().isoformat()}",
                  text, count=1, flags=re.M)
    text = re.sub(r"^generated_from_commit: .*$",
                  f"generated_from_commit: {git_head(repo)}",
                  text, count=1, flags=re.M)
    (repo / PLAN_REL).write_text(text, encoding="utf-8")
    print(f"Refresh: reopened {reopened or 'none'}, appended "
          f"{appended or 'none'}, retired {retired or 'none'}.")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["init", "status", "next", "complete", "refresh"])
    ap.add_argument("--repo", required=True)
    ap.add_argument("--task", default=None)
    args = ap.parse_args()
    repo = Path(args.repo).resolve()
    if args.cmd == "init":
        cmd_init(repo)
    elif args.cmd == "status":
        cmd_status(repo)
    elif args.cmd == "next":
        cmd_next(repo)
    elif args.cmd == "complete":
        if not args.task:
            sys.exit("ERROR: complete requires --task <ID>")
        cmd_complete(repo, args.task)
    elif args.cmd == "refresh":
        cmd_refresh(repo)


if __name__ == "__main__":
    main()
