---
name: repo-docs-init
description: Generate a complete /docs folder for a code repository — a single source of truth that both humans and LLMs can read to understand the codebase without opening the code. Produces module-level Markdown pages with YAML frontmatter, an OVERVIEW.md and ARCHITECTURE.md, a machine-readable docs-index.json, and an llms.txt entry point, all following a deterministic source-path-to-doc-page mapping. Use this skill whenever the user asks to document a repository, create initial/baseline documentation, generate a docs site source, onboard a repo into the living-documentation system, re-document a repo after large changes, or says anything like "document this repo", "create the docs", "generate documentation for this codebase", or "set up the single source of truth" — even if they don't say the word "documentation" but describe wanting an explanation of the codebase saved into the repo.
---

# repo-docs-init: Initial Repository Documentation Generator

Generate the initial `/docs` tree for a repository. The output is the single source of truth consumed by three downstream systems, so structure discipline matters as much as prose quality:

1. **Humans** read the pages as a website (ADO Wiki or MkDocs).
2. **LLM agents** navigate via `llms.txt` and `docs-index.json` instead of crawling code.
3. **The PR sync pipeline** uses frontmatter `source_files` and the index to map code diffs to doc edits deterministically. If the mapping rule or anchors are violated, the pipeline breaks silently.

## The one rule everything depends on

Every source file maps to a doc location by a pure function of its path:

```
<src_root>/<module_path>/<file>  →  docs/modules/<module_path>.md#<file-slug>
src/auth/session.py              →  docs/modules/auth.md#sessionpy
```

Docs are written at **module granularity** (one page per module directory), with one anchored `##` section per source file inside the page. Never invent doc locations outside this rule; the scripts compute them for you.

## Workflow

Follow these steps in order. Steps 1, 2, and 5 are deterministic scripts — run them, don't reimplement them. Steps 3 and 4 are your writing work.

### Step 0 — Configure

Copy `scripts/config.yaml` to the target repo root as `.docsgen.yaml` if it doesn't already exist, then adjust it: source roots, ignore globs, module depth, and `site_base_url` (ask the user for the base URL if unknown; leave the placeholder if they don't have one yet). If `.docsgen.yaml` already exists in the repo, use it as-is — it's the repo owner's configuration.

### Step 1 — Map the repository (deterministic)

```bash
python scripts/map_repo.py --repo <repo_root> --config <repo_root>/.docsgen.yaml --out <repo_root>/docs/repo-map.json
```

This walks the tree (respecting ignore globs), classifies files by language, groups them into modules, extracts public symbols, and builds the import-dependency graph. Review the printed module summary before continuing. If the module grouping looks wrong (e.g., one giant module, or test folders included), fix `.docsgen.yaml` and re-run — do not hand-edit `repo-map.json`.

### Step 2 — Scaffold the docs tree (deterministic)

```bash
python scripts/scaffold_docs.py --repo <repo_root> --map <repo_root>/docs/repo-map.json
```

This creates `docs/modules/*.md` with correct frontmatter, headings, anchors, and source back-links already in place, plus stub `OVERVIEW.md`, `ARCHITECTURE.md`, and `GLOSSARY.md`. Every place needing prose is marked `<!-- TODO:PROSE ... -->` with a hint. Never change frontmatter keys, heading anchors, or the file-section structure — only replace the TODO markers with prose.

### Step 3 — Write the module pages (your core work)

Work **bottom-up**: document modules with no internal dependencies first (the scaffold prints a suggested order), so that when you document higher-level modules you can reference what you already wrote.

For each module page:

1. Read the module's actual source files. Read enough to understand *why* the module exists, not just what it contains. Read the callers too (the `depended_on_by` list in frontmatter) — purpose is usually visible from the outside.
2. Replace each `<!-- TODO:PROSE -->` marker following the **editorial standard** below.
3. Keep every anchor, heading, frontmatter line, and back-link exactly as scaffolded.

For repos too large to read exhaustively, prioritize: public API files first, largest files second, and skim the rest. Say so honestly in the page ("less-trafficked helpers in `util/` are documented at survey level").

### Step 4 — Write the synthesis pages (top-down, last)

Write `OVERVIEW.md` and `ARCHITECTURE.md` **from the module pages you just wrote, not from raw code** — this keeps altitude consistent and the pages mutually coherent. OVERVIEW answers: what is this system, what are its five-or-fewer major parts, what are the two or three key data/control flows through it, where would a newcomer start reading. ARCHITECTURE records cross-cutting decisions and includes the Mermaid dependency diagram the scaffold generated (verify it renders; prune edges below the significance threshold if it's spaghetti). Fill GLOSSARY.md with domain terms you found yourself needing to explain more than once.

### Step 5 — Build the index and validate (deterministic)

```bash
python scripts/build_index.py --repo <repo_root> --map <repo_root>/docs/repo-map.json
```

This emits `docs/docs-index.json` and `docs/llms.txt`, stamps `last_synced_commit` into every page's frontmatter (when run inside a git repo), and **validates** the tree: every source file has a section anchor, every internal link resolves, no TODO markers remain. Fix every reported error and re-run until clean — downstream tooling treats a clean build as a contract.

### Step 6 — Report

Summarize for the user: modules documented, total pages, anything documented at survey level, validation status, and suggested next steps (publish `/docs` as ADO Wiki; wire up the PR sync pipeline).

## Editorial standard

This is the difference between documentation worth maintaining and noise. The reader can already read code — give them only what the code cannot say.

**Document why, not what.** Never enumerate parameters, restate signatures, or narrate implementation ("this function loops over users"). Every sentence should survive this test: *could the reader have learned this in ten seconds of reading the code itself?* If yes, delete it.

**Lead with purpose and responsibility.** The Purpose section states what problem the module owns and, just as importantly, what it deliberately does *not* handle. Boundaries prevent misuse.

**Surface invariants and constraints.** The things that break if violated: "all crypto goes through `crypto.py` so algorithms rotate in one place", "session tokens are opaque, not JWTs, because revocation must land in under 1s". If a design choice looks odd, hunt for the constraint that forced it (git history and comments often hold the answer) and record it. If you can't find the reason, write "reason not evident from code or history" rather than inventing one — a wrong rationale is worse than none.

**Name the gotchas.** Each module page should tell a newcomer the two or three things they would get wrong on their first PR into this module.

**Reference code by name, never by line number.** Use `path::symbol` form (`auth/session.py::create_session`). Line numbers rot; names are durable.

**Calibrated confidence.** Distinguish what you verified from what you inferred. "Appears to assume single-writer access (no locking found)" is honest; stating it as fact is not.

**Length discipline.** 300–800 words of prose per module page (excluding scaffolded structure). A file section is typically 2–5 sentences plus its key entry points. If you need more, the module probably deserves splitting — flag it rather than sprawling.

**Voice.** Plain, direct, present tense, no marketing. Write for a competent engineer new to this repo, or an LLM agent with no context — the same text serves both.

Read `references/page-example.md` before writing your first page — it shows a completed module page at the expected quality bar. `references/page-template.md` documents every structural element and which ones are immutable.

## Re-running on an already-documented repo

If `docs/` already exists with pages: this skill regenerates *structure* non-destructively. `scaffold_docs.py` adds sections for new files and new modules, marks sections whose source files vanished with `<!-- STALE:REMOVED -->`, and never overwrites existing prose. Your job then is to write prose for the new TODOs, resolve the STALE markers (delete or rewrite), and re-run Step 5. Incremental *content* sync for code changes is the PR pipeline's job, not this skill's.

## Failure modes to avoid

- Writing docs from file names without reading the code. If you haven't read it, mark the section "not yet reviewed" rather than confabulating.
- Restating code mechanics to fill space. Short honest pages beat long redundant ones.
- Editing scaffolded structure (anchors, frontmatter, back-links). The pipeline and editor shortcut depend on these byte-for-byte.
- Documenting test directories, generated code, or vendored dependencies. The default config excludes them; keep it that way unless the user asks.
- Skipping validation. A `build_index.py` run with zero errors is the definition of done.
