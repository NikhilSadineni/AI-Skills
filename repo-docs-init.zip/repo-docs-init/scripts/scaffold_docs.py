#!/usr/bin/env python3
"""scaffold_docs.py — Phase 1 scaffolding for repo-docs-init (deterministic).

Creates the docs/ tree from repo-map.json. The docs mirror the repository
structure 1:1 (collision-free by construction):

  src/auth/session.py  ->  docs/reference/src/auth/session.py.md
  src/auth/            ->  docs/reference/src/auth/index.md   (dir overview)
  repo root            ->  docs/reference/index.md

Plus synthesis stubs (reference/functionality.md, reference/glossary.md,
explanation/overview.md, explanation/architecture.md), graph wrapper pages,
and a generated docs/index.md landing page. Viewing is handled by
build_site.py (stdlib static site) — no Sphinx, no external toolchain.

Prose locations carry <!-- TODO:PROSE hint --> markers for the agent.
Non-destructive on re-run: existing prose is never touched; new source files
get new pages + table rows; pages whose source vanished get a STALE:REMOVED
banner (inserted AFTER the frontmatter so metadata keeps parsing).

Usage:
    python scaffold_docs.py --repo /path/to/repo [--map docs/repo-map.json]
                            [--repo-url https://github.com/org/repo/blob/main]
"""
import argparse
import json
import posixpath
import re
from datetime import date
from pathlib import Path

TODO = "<!-- TODO:PROSE {hint} -->"
STALE_BANNER = ("<!-- STALE:REMOVED source file no longer exists; delete this "
                "page (and its row in the directory index) or fold content "
                "into another page -->")

# ------------------------------------------------------------- path rules --

def file_page_rel(rel: str) -> str:
    """src/auth/session.py -> reference/src/auth/session.py.md"""
    return f"reference/{rel}.md"


def dir_index_rel(d: str) -> str:
    return "reference/index.md" if d == "." else f"reference/{d}/index.md"


def source_url(base: str, rel: str) -> str:
    if "_git" in base:                    # Azure DevOps web UI style
        return f"{base}?path=/{rel}"
    return f"{base}/{rel}"

# ------------------------------------------------------------ file pages ---

def yaml_list(items: list[str], cap: int = 25) -> str:
    shown = ", ".join(items[:cap])
    extra = f"  # +{len(items) - cap} more" if len(items) > cap else ""
    return f"[{shown}]{extra}"


def file_page(rel: str, meta: dict, repo_url: str, today: str) -> str:
    name = Path(rel).name
    d = posixpath.dirname(rel) or "."
    syms = meta.get("public_symbols", [])
    fm = [
        "---",
        f"file: {name}",
        f"directory: {d}",
        f"source_path: {rel}",
        f"public_symbols: {yaml_list(syms, 15)}",
        f"internal_deps: {yaml_list(meta.get('internal_deps', []))}",
        f"used_by: {yaml_list(meta.get('used_by', []))}",
        "last_synced_commit: UNSTAMPED",
        f"last_synced_at: {today}",
        "---",
    ]
    if syms:
        rows = "\n".join(
            f"| `{s}` | {TODO.format(hint='one line, why-level: the job it does and when a caller reaches for it')} |"
            for s in syms[:10])
        overflow = ("\nAdditional symbols: "
                    + ", ".join(f"`{s}`" for s in syms[10:]) + "\n") if len(syms) > 10 else ""
        symbol_block = ("## What it provides\n\n"
                        "| Symbol | What it does & why it matters |\n|---|---|\n"
                        f"{rows}\n{overflow}")
    else:
        symbol_block = "## What it provides\n\nKey public symbols: (none detected)\n"

    deps = ", ".join(f"`{x}`" for x in meta.get("internal_deps", [])) or "(none within repo)"
    used = ", ".join(f"`{x}`" for x in meta.get("used_by", [])) or "(none within repo)"
    body = [
        f"# {name}",
        "",
        TODO.format(hint=f"2-5 sentences: what {name} contributes to `{d}` "
                         "and why it exists as a separate file. Do NOT "
                         "restate signatures."),
        "",
        symbol_block,
        "## Behavior notes",
        "",
        TODO.format(hint="side effects, failure modes, state/concurrency assumptions, "
                         "and performance characteristics worth knowing. Write "
                         "'None notable.' only if you verified that."),
        "",
        f"Internal dependencies: {deps}",
        f"Used by: {used}",
        f"Size: {meta.get('loc', '?')} lines ({meta.get('language', '?')})",
        "",
        f"[View source]({source_url(repo_url, rel)}) · [Directory overview](index.md)",
        "",
    ]
    return "\n".join(fm) + "\n\n" + "\n".join(body)

# ----------------------------------------------------------- dir indexes ---

FILES_HEADER = "| File | Overview |\n|---|---|"
SUBDIRS_HEADER = "| Directory | Overview |\n|---|---|"


def file_row(rel: str) -> str:
    name = Path(rel).name
    return (f"| [{name}]({name}.md) | "
            f"{TODO.format(hint='one line: what this file is for')} |")


def subdir_row(sub: str) -> str:
    name = sub.rsplit("/", 1)[-1]
    return (f"| [{name}/]({name}/index.md) | "
            f"{TODO.format(hint='one line: what lives in this directory')} |")


def dir_index(d: str, info: dict, repo_name: str, today: str) -> str:
    title = f"{repo_name} (repository root)" if d == "." else d
    fm = [
        "---",
        f"directory: {d}",
        f"files: {yaml_list([Path(f).name for f in info['files']])}",
        f"subdirectories: {yaml_list(info['subdirs'])}",
        f"public_api: {yaml_list(info['public_api'], 15)}",
        f"depends_on: {yaml_list(info['depends_on'])}",
        f"depended_on_by: {yaml_list(info['depended_on_by'])}",
        "last_synced_commit: UNSTAMPED",
        f"last_synced_at: {today}",
        "---",
    ]
    body = [
        f"# {title}",
        "",
        "## Purpose",
        "",
        TODO.format(hint="2-3 paragraphs: why this directory exists, what responsibility it owns, and what it deliberately does NOT handle."),
        "",
        "## Functionality provided",
        "",
        TODO.format(hint="The capabilities this directory contributes, consumer's perspective, "
                         "with entry points in path::symbol form. Link the relevant sections of "
                         "the functionality catalog rather than duplicating them."),
        "",
        "## Design & Invariants",
        "",
        TODO.format(hint="The decisions and constraints NOT visible in the code: invariants, why odd-looking choices were forced, the 2-3 things a newcomer would get wrong."),
        "",
        "## How It Connects",
        "",
        TODO.format(hint=f"Callers, callees, data flows. depends_on: [{', '.join(info['depends_on']) or 'none'}]; depended_on_by: [{', '.join(info['depended_on_by']) or 'none'}]. Link other directory indexes with relative links."),
        "",
    ]
    if info["files"]:
        body += ["## Files", "", FILES_HEADER,
                 *[file_row(rel) for rel in info["files"]], ""]
    if info["subdirs"]:
        body += ["## Subdirectories", "", SUBDIRS_HEADER,
                 *[subdir_row(s) for s in info["subdirs"]], ""]
    return "\n".join(fm) + "\n\n" + "\n".join(body)

# ----------------------------------------------------------- upsert logic --

def insert_stale(text: str) -> str:
    """Insert the STALE banner AFTER the closing frontmatter delimiter so
    metadata keeps parsing; prepend only if there is no frontmatter."""
    m = re.match(r"^---\n.*?\n---\n", text, flags=re.S)
    if m:
        return text[:m.end()] + STALE_BANNER + "\n" + text[m.end():]
    return STALE_BANNER + "\n" + text


def append_table_row(text: str, header: str, section: str, row: str) -> str:
    """Append a row at the END of the table under `header`; create the
    section+table if missing."""
    idx = text.find(header)
    if idx == -1:
        return (text.rstrip() + f"\n\n## {section}\n\n{header}\n{row}\n")
    end = idx + len(header)
    while True:
        nl = text.find("\n", end)
        if nl == -1:
            return text + "\n" + row
        nxt = text.find("\n", nl + 1)
        line = text[nl + 1: nxt if nxt != -1 else len(text)]
        if not line.startswith("|"):
            return text[:nl + 1] + row + "\n" + text[nl + 1:]
        end = nl + 1


def upsert_dir(docs: Path, d: str, info: dict, files: dict, repo_name: str,
               repo_url: str, today: str, actions: dict) -> None:
    ddir = docs / (Path("reference") if d == "." else Path("reference") / d)
    ddir.mkdir(parents=True, exist_ok=True)

    # -- file pages ---------------------------------------------------------
    for rel in info["files"]:
        p = docs / file_page_rel(rel)
        if not p.exists():
            p.write_text(file_page(rel, files.get(rel, {}), repo_url, today),
                         encoding="utf-8")
            actions[file_page_rel(rel)] = "created"
    # (orphan/stale detection is a global sweep — see sweep_stale)

    # -- directory index ----------------------------------------------------
    idx = docs / dir_index_rel(d)
    if not idx.exists():
        idx.write_text(dir_index(d, info, repo_name, today), encoding="utf-8")
        actions[dir_index_rel(d)] = "created"
        return
    text = idx.read_text(encoding="utf-8")
    changed = False
    for rel in info["files"]:
        if f"]({Path(rel).name}.md)" not in text:
            text = append_table_row(text, FILES_HEADER, "Files", file_row(rel))
            changed = True
    for sub in info["subdirs"]:
        name = sub.rsplit("/", 1)[-1]
        if f"]({name}/index.md)" not in text:
            text = append_table_row(text, SUBDIRS_HEADER, "Subdirectories",
                                    subdir_row(sub))
            changed = True
    if changed:
        idx.write_text(text, encoding="utf-8")
        actions[dir_index_rel(d)] = "updated"
    else:
        actions.setdefault(dir_index_rel(d), "unchanged")

# --------------------------------------------------------------- graphs ----

def mermaid_graph(dirs: dict, max_depth: int = 2) -> str:
    """Architecture overview graph: directories collapsed to max_depth,
    deeper edges aggregated onto their depth-limited ancestor."""
    def collapse(d: str) -> str:
        if d == ".":
            return "."
        parts = d.split("/")
        return "/".join(parts[:max_depth])

    nodes, edges = set(), set()
    for d, info in dirs.items():
        cd = collapse(d)
        nodes.add(cd)
        for dep in info["depends_on"]:
            cdep = collapse(dep)
            if cdep != cd:
                edges.add((cd, cdep))

    def nid(d):
        return re.sub(r"[^A-Za-z0-9_]", "_", d) or "root"

    lines = ["```mermaid", "graph TD"]
    for d in sorted(nodes):
        lines.append(f'    {nid(d)}["{d if d != "." else "(root)"}"]')
    for a, b in sorted(edges):
        lines.append(f"    {nid(a)} --> {nid(b)}")
    lines.append("```")
    return "\n".join(lines)

# ------------------------------------------------------------- templates ---

FUNCTIONALITY_TMPL = """# {repo} — Functionality Catalog

{todo_intro}

<!-- Editorial contract for this page:
Document the system by WHAT IT PROVIDES, not how it is organized. A reader
(human or LLM) who finishes this page should know every job this codebase can
do, why each job exists, and where to enter the code to invoke or change it.
Write this page AFTER all directory pages, synthesizing from them. One
subsection per distinct capability, using exactly this shape: -->

## Capabilities

{todo_capabilities}

<!-- Template for each capability (copy per capability):

### <Capability name, verb phrase, e.g. "Create and validate user sessions">

**What it does:** One or two sentences, consumer's perspective.

**Why it exists:** The problem or requirement that forced this capability
into existence. If the reason is not evident from code or history, say so.

**Entry points:** `path/file.py::symbol` (the functions/classes a consumer
or maintainer starts from — path::symbol form, never line numbers).

**Implemented in:** [directory](src/auth/index.md) links relative to
reference/, main ones first.

**Flow:** a ```mermaid sequenceDiagram``` showing the capability end to end
(actor -> entry point -> internal calls -> externals). Draft it with
`scripts/call_trace.py --entry <path::symbol>`, then refine: prune noise,
name the actor, annotate what each hop MEANS, add the error path.

-->

## Capability → Module Map

| Capability | Implemented in | Entry point |
|---|---|---|
{todo_map_rows}
"""

OVERVIEW_TMPL = """# {repo} — Overview

{todo_purpose}

For the system described by *what it can do* rather than how it is
structured, see the [Functionality Catalog](../reference/functionality.md).

## Major Components

{todo_components}

| Directory | Purpose (one line) |
|---|---|
{dir_rows}

## Key Flows

{todo_flows}

## Where To Start Reading

{todo_start}
"""

ARCH_TMPL = """# {repo} — Architecture

{todo_decisions}

## Component Dependency Graph

{mermaid}

## Cross-Cutting Concerns

{todo_crosscut}
"""

GRAPH_WRAPPER_TMPL = """# {title}

{blurb}

<iframe src="../_static/{html}" style="width:100%;height:80vh;border:1px solid #ccc;border-radius:6px;" title="{title}"></iframe>

Generated by `scripts/build_graphs.py` — re-run it after docs change; do not edit.
"""

LANDING_TMPL = """# {repo} documentation

Generated by repo-docs-init. The **reference** tree mirrors the repository
1:1 — one page per source file, one overview per directory. **Explanation**
pages carry the system-level why.

| Start here | |
|---|---|
| [Overview](explanation/overview.md) | what the system is, its parts, key flows |
| [Functionality Catalog](reference/functionality.md) | every capability: what, why, entry points |
| [Architecture](explanation/architecture.md) | cross-cutting decisions + dependency graph |
| [Code reference](reference/index.md) | browse the mirrored source tree |
| [Glossary](reference/glossary.md) | domain terms |
| [Repository map](explanation/repo-map.md) | interactive dependency graph |
| [Functionality map](explanation/functionality-map.md) | interactive capability ↔ module graph |

LLM agents: start at [llms.txt](llms.txt); file-level lookup via
[docs-index.json](docs-index.json).
"""

# ----------------------------------------------------------------- main ----


def sweep_stale(docs: Path, rmap: dict, actions: dict) -> None:
    """Mark orphaned pages under docs/reference/ whose source file or
    directory no longer exists in the map: STALE banner below the
    frontmatter. Covers vanished files AND vanished whole directories.
    Root synthesis pages (functionality.md, glossary.md) are never
    source-mapped and are skipped."""
    ref = docs / "reference"
    if not ref.exists():
        return
    synth = {"functionality.md", "glossary.md"}
    for p in ref.rglob("*.md"):
        rel_doc = p.relative_to(docs).as_posix()      # reference/...
        inner = rel_doc[len("reference/"):]
        if "/" not in inner and inner in synth:
            continue
        if p.name == "index.md":
            d = posixpath.dirname(inner) or "."
            ok = d in rmap["dirs"]
        else:
            ok = inner[:-3] in rmap["files"]          # strip ".md"
        if ok:
            continue
        text = p.read_text(encoding="utf-8")
        if "STALE:REMOVED" not in text:
            p.write_text(insert_stale(text), encoding="utf-8")
            actions[rel_doc] = "stale-marked"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--map", default=None)
    ap.add_argument("--repo-url", default="",
                    help="Base URL of the repo web UI for source back-links")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    map_path = Path(args.map) if args.map else repo / "docs" / "repo-map.json"
    rmap = json.loads(map_path.read_text(encoding="utf-8"))
    docs = repo / "docs"
    repo_url = args.repo_url or "REPO_URL_PLACEHOLDER"
    today = date.today().isoformat()

    actions: dict = {}
    for d in rmap["dir_order"]:
        upsert_dir(docs, d, rmap["dirs"][d], rmap["files"],
                   rmap["repo_name"], repo_url, today, actions)
    sweep_stale(docs, rmap, actions)

    t = lambda hint: TODO.format(hint=hint)
    dir_rows = "\n".join(
        f"| [{d if d != '.' else '(root)'}](../{dir_index_rel(d)}) | {t('one line')} |"
        for d in rmap["dir_order"])
    prose_stubs = [
        ("reference/functionality.md", FUNCTIONALITY_TMPL.format(
            repo=rmap["repo_name"],
            todo_intro=t("2-3 sentences: what this system provides to its consumers, written for someone who has never seen the code. Write AFTER directory pages."),
            todo_capabilities=t("One ### subsection per distinct capability, following the commented template below. Cover ALL functionality the code provides — a capability absent here is invisible to readers."),
            todo_map_rows=t("| rows: one per capability | [dir](src/x/index.md) links | `path::symbol` |"))),
        ("explanation/overview.md", OVERVIEW_TMPL.format(
            repo=rmap["repo_name"],
            todo_purpose=t("3-5 sentences: what this system does and for whom. Write LAST, from the directory pages."),
            todo_components=t("Prose naming the <=5 major parts and their relationships."),
            dir_rows=dir_rows,
            todo_flows=t("The 2-3 key data/control flows end to end, referencing directory pages."),
            todo_start=t("Reading order for a newcomer."))),
        ("explanation/architecture.md", ARCH_TMPL.format(
            repo=rmap["repo_name"],
            todo_decisions=t("Cross-cutting decisions and their forcing constraints. Write LAST."),
            mermaid=mermaid_graph(rmap["dirs"]),
            todo_crosscut=t("Auth, error handling, logging, config — patterns that span directories."))),
        ("reference/glossary.md", "# Glossary\n\n" + t("Domain terms you needed to explain more than once while writing directory pages. | Term | Meaning | table.") + "\n"),
    ]
    for name, content in prose_stubs:
        p = docs / name
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            p.write_text(content, encoding="utf-8")
            actions[name] = "created"
        else:
            actions.setdefault(name, "unchanged")

    # machine-owned pages, regenerated every run
    regenerated = [
        ("index.md", LANDING_TMPL.format(repo=rmap["repo_name"])),
        ("explanation/repo-map.md", GRAPH_WRAPPER_TMPL.format(
            title="Interactive Repository Map",
            blurb="Every directory and file as an explorable dependency graph. "
                  "Click a node to open its documentation; use the search box "
                  "to filter; drag to rearrange.",
            html="repo-graph.html")),
        ("explanation/functionality-map.md", GRAPH_WRAPPER_TMPL.format(
            title="Interactive Functionality Map",
            blurb="Capabilities on the left, the directories implementing them "
                  "on the right. Click a node to open its documentation.",
            html="functionality-map.html")),
    ]
    for name, content in regenerated:
        p = docs / name
        p.parent.mkdir(parents=True, exist_ok=True)
        prev = p.read_text(encoding="utf-8") if p.exists() else None
        if prev != content:
            p.write_text(content, encoding="utf-8")
            actions[name] = "created" if prev is None else "regenerated"
        else:
            actions.setdefault(name, "unchanged")

    created = sum(1 for a in actions.values() if a == "created")
    changed = sum(1 for a in actions.values() if a in ("updated", "stale-marked", "regenerated"))
    print(f"Scaffold complete: {created} created, {changed} updated/regenerated/"
          f"stale-marked, {len(actions) - created - changed} unchanged, under {docs}")
    print("\nWrite prose bottom-up (leaf directories first); each directory "
          "task = its index.md + its direct file pages:")
    for d in rmap["dir_order"]:
        n = len(rmap["dirs"][d]["files"])
        print(f"  docs/{dir_index_rel(d)} (+ {n} file page(s))")
    print("Then functionality, overview, architecture last, from the directory pages.")
    if repo_url == "REPO_URL_PLACEHOLDER":
        print("\nNOTE: pass --repo-url to fill real source back-links "
              "(placeholders were written; build_index.py will flag them).")


if __name__ == "__main__":
    main()
