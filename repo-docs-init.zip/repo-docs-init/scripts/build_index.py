#!/usr/bin/env python3
"""build_index.py — final gate of repo-docs-init (deterministic).

Validates the whole docs tree, and when clean emits the two machine entry
points and stamps provenance:

  docs/docs-index.json   source file -> doc page; directory -> doc page +
                         deps; capability -> directories + entry point
  docs/llms.txt          LLM navigation file: what the system does
                         (capabilities), what each directory does (one line),
                         and where every answer lives

Error classes:
  E1  a source file has no page, or no row in its directory index
  E2  TODO:PROSE / STALE:REMOVED markers remain (scans EVERY .md in docs/)
  E3  internal relative link points at a missing page
  E4  source back-link still contains REPO_URL_PLACEHOLDER
  E5  a directory index listed in repo-map is missing
  E6  interactive graphs missing or placeholder (task D artifacts)

Provenance (last_synced_commit / last_synced_at) is stamped ONLY on a clean
run, so a failing validation never mutates the tree. Exit code is non-zero
if any error remains — a clean run is the contract downstream tooling
(PR sync pipeline, editor shortcuts) relies on.

Usage:
    python build_index.py --repo /path/to/repo [--allow-todos]
"""
import argparse
import json
import posixpath
import re
import subprocess
import sys
from datetime import date
from pathlib import Path

SKIP_NAMES = {"_PLAN.md"}
SKIP_DIRS = {"_site", "_build", "node_modules"}


def dir_index_rel(d: str) -> str:
    return "reference/index.md" if d == "." else f"reference/{d}/index.md"


def file_page_rel(rel: str) -> str:
    return f"reference/{rel}.md"


def git_head(repo: Path) -> str:
    try:
        return subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                              cwd=repo, capture_output=True, text=True,
                              check=True).stdout.strip()
    except Exception:
        return "UNSTAMPED"


def all_doc_pages(docs: Path):
    for p in sorted(docs.rglob("*.md")):
        if p.name in SKIP_NAMES:
            continue
        if any(part in SKIP_DIRS for part in p.relative_to(docs).parts):
            continue
        yield p


def strip_noise(text: str) -> str:
    """Remove fenced code blocks and HTML comments before link scanning."""
    text = re.sub(r"```.*?```", "", text, flags=re.S)
    return re.sub(r"<!--.*?-->", "", text, flags=re.S)


def first_line_of_purpose(text: str) -> str:
    m = re.search(r"^## Purpose\s*\n+(.+)$", text, re.M)
    if not m:
        m = re.search(r"^# .+\n+(.+)$", text, re.M)
    if not m:
        return ""
    line = m.group(1).strip()
    return "" if line.startswith("<!--") else line[:160]


CAP_SECTION_RE = re.compile(
    r"^## Capability → Module Map\s*$(.*?)(?=^## |\Z)", re.M | re.S)
CAP_ROW_RE = re.compile(
    r"^\|\s*(?!Capability\b|[-: ]+\|)([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]*?)\s*\|", re.M)
DIR_LINK_RE = re.compile(r"\[[^\]]*\]\(((?:[^)#]*?/)?index\.md|index\.md)\)")


def parse_capabilities(func_text: str) -> list[dict]:
    """Parse capability rows ONLY from the Capability → Module Map section."""
    sec = CAP_SECTION_RE.search(func_text)
    if not sec:
        return []
    caps = []
    for m in CAP_ROW_RE.finditer(sec.group(1)):
        name, dirs_cell, entry = (g.strip() for g in m.groups())
        dirs = []
        for link in DIR_LINK_RE.finditer(dirs_cell):
            target = link.group(1)
            d = target[:-len("/index.md")] if target.endswith("/index.md") else "."
            dirs.append(d)
        if name and dirs:
            caps.append({"capability": name, "directories": dirs,
                         "entry_point": entry.strip("`")})
    return caps


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--map", default=None)
    ap.add_argument("--allow-todos", action="store_true",
                    help="Downgrade E2 (remaining TODO/STALE markers) to warnings.")
    ap.add_argument("--skip-graphs", action="store_true",
                    help="Downgrade E6 (missing interactive graphs) to warnings.")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    docs = repo / "docs"
    map_path = Path(args.map) if args.map else docs / "repo-map.json"
    rmap = json.loads(map_path.read_text(encoding="utf-8"))
    commit = git_head(repo)
    errors: list[str] = []
    warnings: list[str] = []

    # ---- E1/E5: structural completeness -----------------------------------
    for d, info in rmap["dirs"].items():
        idx = docs / dir_index_rel(d)
        if not idx.exists():
            errors.append(f"E5 missing directory index: docs/{dir_index_rel(d)}")
            continue
        idx_text = idx.read_text(encoding="utf-8")
        for rel in info["files"]:
            name = Path(rel).name
            if not (docs / file_page_rel(rel)).exists():
                errors.append(f"E1 missing file page: docs/{file_page_rel(rel)}")
            if f"]({name}.md)" not in idx_text:
                errors.append(f"E1 {dir_index_rel(d)}: Files table has no row for {rel}")
        for sub in info["subdirs"]:
            name = sub.rsplit("/", 1)[-1]
            if f"]({name}/index.md)" not in idx_text:
                errors.append(f"E1 {dir_index_rel(d)}: Subdirectories table has "
                              f"no row for {sub}")

    # ---- E2/E3/E4: every page in the tree ----------------------------------
    for p in all_doc_pages(docs):
        rel_name = p.relative_to(docs).as_posix()
        text = p.read_text(encoding="utf-8")
        for marker, label in (("TODO:PROSE", "TODO"), ("STALE:REMOVED", "STALE")):
            n = text.count(marker)
            if n:
                msg = f"E2 {rel_name}: {n} {label} marker(s) remain"
                (warnings if args.allow_todos else errors).append(msg)
        if "REPO_URL_PLACEHOLDER" in text:
            errors.append(f"E4 {rel_name}: source back-links are placeholders "
                          "(re-run scaffold_docs.py with --repo-url)")
        for link in re.findall(r"\]\((?!https?://|mailto:|#)([^)#\s]+\.md)",
                               strip_noise(text)):
            target = (p.parent / link).resolve()
            if not target.exists():
                errors.append(f"E3 {rel_name}: broken link -> {link}")

    # ---- E6: interactive graph artifacts -----------------------------------
    for f in ("_static/repo-graph.html", "_static/functionality-map.html"):
        g = docs / f
        if not g.exists():
            msg = f"E6 docs/{f} missing — run scripts/build_graphs.py"
            (warnings if args.skip_graphs else errors).append(msg)
        elif "not available yet" in g.read_text(encoding="utf-8"):
            msg = f"E6 docs/{f} is a placeholder — finish the capability table, re-run build_graphs.py"
            (warnings if args.skip_graphs else errors).append(msg)

    # ---- capabilities -------------------------------------------------------
    func_p = docs / "reference" / "functionality.md"
    caps = parse_capabilities(func_p.read_text(encoding="utf-8")) if func_p.exists() else []

    # ---- emit index + llms.txt, stamp provenance (clean runs only) ---------
    if not errors:
        base = rmap.get("site_base_url", "")
        if "REPLACE-ME" in base:
            base = ""
        url = lambda rel: f"{base.rstrip('/')}/{rel}" if base else rel

        index = {
            "site_base_url": rmap.get("site_base_url", ""),
            "generated_from_commit": commit,
            "files": {rel: {"page": file_page_rel(rel),
                            "directory_page": dir_index_rel(posixpath.dirname(rel) or ".")}
                      for rel in rmap["files"]},
            "directories": {d: {"page": dir_index_rel(d),
                                "depends_on": info["depends_on"]}
                            for d, info in rmap["dirs"].items()},
            "capabilities": caps,
        }
        (docs / "docs-index.json").write_text(json.dumps(index, indent=2),
                                              encoding="utf-8")

        lines = [f"# {rmap['repo_name']}", "",
                 "> Generated repository documentation. The reference tree mirrors",
                 "> the source tree 1:1 (one page per file, one overview per",
                 "> directory). Read Capabilities to learn what the system does,",
                 "> Directories to learn how it is organized, docs-index.json for",
                 "> file-level lookup.", "",
                 "## Start here", "",
                 f"- [Overview]({url('explanation/overview.md')}): what the system is — components and key flows",
                 f"- [Functionality Catalog]({url('reference/functionality.md')}): every capability — what, why, entry points, flows",
                 f"- [Architecture]({url('explanation/architecture.md')}): cross-cutting decisions, dependency graph",
                 f"- [File index]({url('docs-index.json')}): machine map, source file -> doc page", "",
                 "## Capabilities (what this repo provides)", ""]
        if caps:
            for c in caps:
                dirs = ", ".join(c["directories"])
                entry = f" — entry: `{c['entry_point']}`" if c["entry_point"] else ""
                lines.append(f"- {c['capability']} — implemented in: {dirs}{entry}")
        else:
            lines.append("- (capability table not written yet — see "
                         "reference/functionality.md)")
        lines += ["", "## Directories (how the code is organized)", ""]
        for d in rmap["dir_order"]:
            p = docs / dir_index_rel(d)
            desc = first_line_of_purpose(p.read_text(encoding="utf-8")) if p.exists() else ""
            label = "(repo root)" if d == "." else d
            lines.append(f"- [{label}]({url(dir_index_rel(d))}): {desc}")
        (docs / "llms.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

        stamped = 0
        for p in all_doc_pages(docs):
            text = p.read_text(encoding="utf-8")
            new = re.sub(r"^last_synced_commit: .*$",
                         f"last_synced_commit: {commit}", text, count=1, flags=re.M)
            new = re.sub(r"^last_synced_at: .*$",
                         f"last_synced_at: {date.today().isoformat()}",
                         new, count=1, flags=re.M)
            if new != text:
                p.write_text(new, encoding="utf-8")
                stamped += 1
        print(f"docs-index.json: {len(index['files'])} files, "
              f"{len(index['directories'])} directories, {len(caps)} capabilities")
        print(f"llms.txt: written | provenance stamped on {stamped} page(s): {commit}")

    for w in warnings:
        print(f"  WARN {w}")
    if errors:
        print(f"\nVALIDATION FAILED ({len(errors)} error(s)) — nothing was "
              "stamped or emitted:")
        for e in errors:
            print(f"  {e}")
        sys.exit(1)
    print("Validation: CLEAN — docs tree satisfies the pipeline contract.")


if __name__ == "__main__":
    main()
