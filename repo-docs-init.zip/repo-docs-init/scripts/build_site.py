#!/usr/bin/env python3
"""build_site.py — render docs/ into a browsable static website (stdlib only).

Replaces Sphinx: no pip installs, no build toolchain. Converts every
Markdown page under docs/ into HTML in docs/_site/, preserving the mirrored
repository hierarchy, with:

  - a sidebar showing the exact source tree (directories collapsible,
    files color-coded by language, filter box),
  - breadcrumbs, heading anchors, tables, fenced code, Mermaid diagrams
    (rendered via CDN when online; shown as code when offline),
  - relative *.md links rewritten to *.html,
  - llms.txt, docs-index.json and _static/ copied through so machine
    consumers and the interactive graphs work from the same site.

Usage:
    python build_site.py --repo /path/to/repo            # build docs/_site
    python build_site.py --repo /path/to/repo --serve    # build + serve
    python build_site.py --repo . --serve --port 8080
"""
import argparse
import html
import json
import re
import shutil
from pathlib import Path

LANG_COLORS = {"python": "#3572A5", "typescript": "#3178c6",
               "javascript": "#f1e05a", "csharp": "#178600", "java": "#b07219",
               "go": "#00ADD8", "rust": "#dea584", "ruby": "#701516",
               "shell": "#89e051", "sql": "#e38c00", "c": "#555555",
               "cpp": "#f34b7d"}

SKIP_NAMES = {"_PLAN.md"}
SKIP_DIRS = {"_site", "_build", "node_modules"}

# ============================================================ markdown ======

def esc(s: str) -> str:
    return html.escape(s, quote=False)


def slugify(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-") or "section"


def split_frontmatter(text: str) -> tuple[dict, str]:
    m = re.match(r"^---\n(.*?)\n---\n", text, flags=re.S)
    if not m:
        return {}, text
    meta = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            meta[k.strip()] = v.strip()
    return meta, text[m.end():]


def rewrite_href(href: str) -> str:
    if re.match(r"^(https?://|mailto:|#)", href):
        return href
    base, _, frag = href.partition("#")
    if base.endswith(".md"):
        base = base[:-3] + ".html"
    return base + ("#" + frag if frag else "")


def render_inline(s: str) -> str:
    codes: list[str] = []

    def stash(m):
        codes.append(m.group(1))
        return f"\x00{len(codes) - 1}\x00"

    s = re.sub(r"`([^`]+)`", stash, s)
    s = esc(s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)\s]+)\)",
               lambda m: f'<img src="{rewrite_href(m.group(2))}" alt="{m.group(1)}">', s)
    s = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)",
               lambda m: f'<a href="{rewrite_href(m.group(2))}">{m.group(1)}</a>', s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"(?<![\w*])\*([^*\n]+)\*(?![\w*])", r"<em>\1</em>", s)
    s = re.sub(r"\x00(\d+)\x00", lambda m: f"<code>{esc(codes[int(m.group(1))])}</code>", s)
    return s


def render_markdown(text: str) -> tuple[str, str, bool]:
    """-> (body_html, title, has_mermaid)"""
    blocks: list[str] = []          # rendered fenced blocks, by placeholder id
    has_mermaid = False

    def stash_fence(m):
        nonlocal has_mermaid
        lang, code = m.group(1).strip().lower(), m.group(2)
        if lang == "mermaid":
            has_mermaid = True
            blocks.append(f'<pre class="mermaid">{esc(code)}</pre>')
        else:
            cls = f' class="language-{lang}"' if lang else ""
            blocks.append(f"<pre><code{cls}>{esc(code)}</code></pre>")
        return f"\x01{len(blocks) - 1}\x01"

    text = re.sub(r"```([^\n]*)\n(.*?)```", stash_fence, text, flags=re.S)
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)

    lines = text.split("\n")
    out: list[str] = []
    title = ""
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        fence = re.fullmatch(r"\x01(\d+)\x01", stripped)
        if fence:
            out.append(blocks[int(fence.group(1))])
            i += 1
            continue

        m = re.match(r"^(#{1,6})\s+(.+)$", line)
        if m:
            level = len(m.group(1))
            raw = m.group(2).strip()
            if level == 1 and not title:
                title = raw
            out.append(f'<h{level} id="{slugify(raw)}">{render_inline(raw)}</h{level}>')
            i += 1
            continue

        if re.fullmatch(r"(-{3,}|\*{3,})", stripped):
            out.append("<hr>")
            i += 1
            continue

        if stripped.startswith("<") and not stripped.startswith("<!--"):
            raw_block = []                       # raw HTML passthrough
            while i < len(lines) and lines[i].strip():
                raw_block.append(lines[i])
                i += 1
            out.append("\n".join(raw_block))
            continue

        if stripped.startswith("|") and i + 1 < len(lines) \
                and re.match(r"^\s*\|[\s:|-]+\|\s*$", lines[i + 1]):
            header = [c.strip() for c in stripped.strip("|").split("|")]
            i += 2
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            thead = "".join(f"<th>{render_inline(c)}</th>" for c in header)
            tbody = "".join(
                "<tr>" + "".join(f"<td>{render_inline(c)}</td>" for c in r) + "</tr>"
                for r in rows)
            out.append(f"<table><thead><tr>{thead}</tr></thead>"
                       f"<tbody>{tbody}</tbody></table>")
            continue

        if stripped.startswith(">"):
            quote = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote.append(lines[i].strip()[1:].strip())
                i += 1
            out.append(f"<blockquote><p>{render_inline(' '.join(quote))}</p></blockquote>")
            continue

        lm = re.match(r"^(\s*)([-*+]|\d+\.)\s+(.*)$", line)
        if lm:
            items = []                             # (indent_level, ordered, text)
            while i < len(lines):
                m2 = re.match(r"^(\s*)([-*+]|\d+\.)\s+(.*)$", lines[i])
                if not m2:
                    break
                items.append((len(m2.group(1)) // 2,
                              m2.group(2)[0].isdigit(), m2.group(3)))
                i += 1
            out.append(render_list(items))
            continue

        para = []                                   # paragraph
        while i < len(lines) and lines[i].strip() \
                and not re.match(r"^(#{1,6}\s|\||>|\s*([-*+]|\d+\.)\s|<|\x01)", lines[i].strip()):
            para.append(lines[i].strip())
            i += 1
        if para:
            out.append(f"<p>{render_inline(' '.join(para))}</p>")
        else:
            i += 1

    return "\n".join(out), title, has_mermaid


def render_list(items: list[tuple[int, bool, str]]) -> str:
    out, stack = [], []                    # stack of "ul"/"ol"

    def open_tag(ordered):
        tag = "ol" if ordered else "ul"
        stack.append(tag)
        out.append(f"<{tag}>")

    def close_tag():
        out.append(f"</{stack.pop()}>")

    prev = -1
    for level, ordered, text in items:
        level = min(level, prev + 1) if prev >= 0 else 0
        while len(stack) > level + 1:
            close_tag()
        while len(stack) < level + 1:
            open_tag(ordered)
        out.append(f"<li>{render_inline(text)}</li>")
        prev = level
    while stack:
        close_tag()
    return "\n".join(out)

# ============================================================ site ==========

PAGE_TMPL = """<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title} · {repo}</title>
<style>{css}</style>
</head><body>
<nav id="side">
  <div class="brand"><a href="{root}index.html">{repo}</a><span class="sub">docs</span></div>
  <input id="filter" type="search" placeholder="Filter pages…" autocomplete="off">
  {nav}
</nav>
<main>
  <div class="crumbs">{crumbs}</div>
  <article>
  {meta_block}
  {body}
  </article>
  <footer>Generated by repo-docs-init · <a href="{root}llms.txt">llms.txt</a> · <a href="{root}docs-index.json">docs-index.json</a></footer>
</main>
<script>{js}</script>
{mermaid}
</body></html>
"""

CSS = """
:root{
  --bg:#f6f6f4; --panel:#fdfdfc; --ink:#1c1e21; --muted:#6a7076;
  --accent:#0e7467; --accent-ink:#0a5a50; --border:#e3e3de;
  --code-bg:#eef0ee; --mono:ui-monospace,"SF Mono","Cascadia Code",Consolas,Menlo,monospace;
  --sans:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
}
*{box-sizing:border-box}
body{margin:0;display:flex;min-height:100vh;background:var(--bg);color:var(--ink);
  font:15px/1.65 var(--sans)}
a{color:var(--accent-ink);text-decoration:none}
a:hover{text-decoration:underline}
#side{width:300px;flex:none;border-right:1px solid var(--border);background:var(--panel);
  padding:16px 12px 40px;overflow-y:auto;height:100vh;position:sticky;top:0}
#side .brand{font-weight:650;font-size:16px;margin:0 4px 12px;letter-spacing:.01em}
#side .brand a{color:var(--ink)}
#side .brand .sub{color:var(--muted);font-weight:400;margin-left:6px;font-size:12px;
  text-transform:uppercase;letter-spacing:.12em}
#filter{width:100%;padding:6px 9px;margin-bottom:12px;border:1px solid var(--border);
  border-radius:6px;background:var(--bg);font:13px var(--sans);color:var(--ink)}
#filter:focus{outline:2px solid var(--accent);outline-offset:1px}
#side .group{margin:14px 4px 4px;font-size:11px;font-weight:650;color:var(--muted);
  text-transform:uppercase;letter-spacing:.14em}
#side ul{list-style:none;margin:0;padding-left:0}
#side li{margin:0}
#side a.pg{display:block;padding:3px 8px;border-radius:5px;color:var(--ink);font-size:13.5px}
#side a.pg:hover{background:var(--code-bg);text-decoration:none}
#side a.current{background:var(--accent);color:#fff}
#side details{margin:0}
#side details ul{padding-left:14px;border-left:1px dotted var(--border);margin-left:9px}
#side summary{cursor:pointer;padding:3px 8px;border-radius:5px;font-size:13.5px;
  list-style:none;display:flex;align-items:center;gap:2px}
#side summary::before{content:"▸";font-size:10px;color:var(--muted);width:12px;
  transition:transform .12s}
#side details[open]>summary::before{transform:rotate(90deg)}
#side summary:hover{background:var(--code-bg)}
#side summary a{color:var(--ink)}
#side .file a,#side summary a{font-family:var(--mono);font-size:12.5px}
#side .dot{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:6px;
  background:var(--muted);flex:none;vertical-align:1px}
main{flex:1;min-width:0;padding:28px 48px 80px}
.crumbs{font:12.5px var(--mono);color:var(--muted);margin-bottom:18px}
.crumbs a{color:var(--muted)}
.crumbs .sep{margin:0 6px;color:var(--border)}
article{max-width:860px;background:var(--panel);border:1px solid var(--border);
  border-radius:10px;padding:36px 44px 44px}
article h1{font-size:27px;margin:0 0 14px;letter-spacing:-.01em}
article h2{font-size:19px;margin:34px 0 10px;padding-top:14px;border-top:1px solid var(--border)}
article h3{font-size:16px;margin:24px 0 8px}
article p{margin:10px 0}
article code{font:12.8px var(--mono);background:var(--code-bg);padding:1.5px 5px;
  border-radius:4px}
article pre{background:var(--code-bg);border:1px solid var(--border);border-radius:8px;
  padding:14px 16px;overflow-x:auto;font:12.8px/1.55 var(--mono)}
article pre code{background:none;padding:0}
article table{border-collapse:collapse;width:100%;margin:14px 0;font-size:14px}
article th{text-align:left;font-size:12px;text-transform:uppercase;letter-spacing:.08em;
  color:var(--muted)}
article th,article td{border-bottom:1px solid var(--border);padding:7px 10px;
  vertical-align:top}
article td:first-child code,article td:first-child a{font-family:var(--mono);font-size:12.8px}
article blockquote{border-left:3px solid var(--accent);margin:14px 0;padding:2px 16px;
  color:var(--muted)}
article img,article iframe{max-width:100%}
article hr{border:none;border-top:1px solid var(--border);margin:22px 0}
details.meta{font:12.5px var(--mono);color:var(--muted);margin:0 0 18px;
  border:1px dashed var(--border);border-radius:7px;padding:7px 12px}
details.meta summary{cursor:pointer}
details.meta table{margin:8px 0 2px;font-size:12.5px}
details.meta td{border:none;padding:2px 10px 2px 0}
footer{max-width:860px;margin-top:18px;color:var(--muted);font-size:12.5px}
:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
@media (max-width:900px){body{flex-direction:column}
  #side{width:100%;height:auto;position:static;border-right:none;
  border-bottom:1px solid var(--border)} main{padding:20px 16px}
  article{padding:24px 20px}}
@media (prefers-reduced-motion:reduce){#side summary::before{transition:none}}
"""

JS = """
document.getElementById('filter').addEventListener('input', function(e){
  const q = e.target.value.toLowerCase();
  document.querySelectorAll('#side li, #side details').forEach(el=>{el.style.display=''});
  if(!q) return;
  document.querySelectorAll('#side li.file, #side li.leaf').forEach(li=>{
    const hit = li.textContent.toLowerCase().includes(q);
    li.style.display = hit ? '' : 'none';
  });
  document.querySelectorAll('#side details').forEach(d=>{
    const any = Array.from(d.querySelectorAll('li')).some(li=>li.style.display!=='none');
    d.style.display = any ? '' : 'none';
    if(any) d.open = true;
  });
});
"""

MERMAID_TAG = ('<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/'
               'mermaid.min.js"></script>\n<script>window.mermaid&&'
               'mermaid.initialize({startOnLoad:true,theme:"neutral"});</script>')

# ------------------------------------------------------------- nav tree ----

def build_nav(docs: Path, langs: dict) -> list:
    """Nav model: list of ('link', label, relpath) | ('group', label)
    | ('tree', node). Tree node = {name, index, files:[(label, rel, lang)],
    dirs:[node]}."""
    nav = [("link", "Home", "index.md"), ("group", "Explanation")]
    for label, rel in [("Overview", "explanation/overview.md"),
                       ("Architecture", "explanation/architecture.md"),
                       ("Repository map", "explanation/repo-map.md"),
                       ("Functionality map", "explanation/functionality-map.md")]:
        if (docs / rel).exists():
            nav.append(("link", label, rel))
    nav.append(("group", "Reference"))
    for label, rel in [("Functionality catalog", "reference/functionality.md"),
                       ("Glossary", "reference/glossary.md")]:
        if (docs / rel).exists():
            nav.append(("link", label, rel))

    def tree(dpath: Path, name: str) -> dict:
        node = {"name": name, "index": None, "files": [], "dirs": []}
        idx = dpath / "index.md"
        if idx.exists():
            node["index"] = idx.relative_to(docs).as_posix()
        for f in sorted(dpath.iterdir()):
            if f.is_dir():
                node["dirs"].append(tree(f, f.name + "/"))
            elif f.suffix == ".md" and f.name != "index.md" \
                    and f.relative_to(docs).as_posix() not in (
                        "reference/functionality.md", "reference/glossary.md"):
                rel = f.relative_to(docs).as_posix()
                src = rel[len("reference/"):-3]          # original source path
                node["files"].append((f.name[:-3], rel,
                                      langs.get(src, "")))
        return node

    ref = docs / "reference"
    if ref.exists():
        nav.append(("tree", tree(ref, "(repo root)")))
    return nav


def render_nav(nav: list, current: str, root: str) -> str:
    out = ["<ul>"]

    def link(label, rel, cls=""):
        href = root + rel[:-3] + ".html" if rel.endswith(".md") else root + rel
        cur = ' current' if rel == current else ""
        return f'<li class="{cls}"><a class="pg{cur}" href="{href}">{esc(label)}</a></li>'

    def node_html(node) -> tuple[str, bool]:
        inner, has_current = [], False
        for label, rel, lang in node["files"]:
            color = LANG_COLORS.get(lang, "#9aa0a6")
            cur = ' current' if rel == current else ""
            href = root + rel[:-3] + ".html"
            inner.append(f'<li class="file"><a class="pg{cur}" href="{href}">'
                         f'<span class="dot" style="background:{color}"></span>'
                         f'{esc(label)}</a></li>')
            has_current |= rel == current
        for sub in node["dirs"]:
            sub_html, sub_cur = node_html(sub)
            inner.append(sub_html)
            has_current |= sub_cur
        is_cur = node["index"] == current
        has_current |= is_cur
        idx_href = root + node["index"][:-3] + ".html" if node["index"] else "#"
        cur = ' current' if is_cur else ""
        return (f'<li><details{" open" if has_current else ""}>'
                f'<summary><a class="pg{cur}" href="{idx_href}">{esc(node["name"])}</a>'
                f'</summary><ul>{"".join(inner)}</ul></details></li>', has_current)

    for kind, *rest in nav:
        if kind == "link":
            out.append(link(rest[0], rest[1]))
        elif kind == "group":
            out.append(f'</ul><div class="group">{esc(rest[0])}</div><ul>')
        elif kind == "tree":
            root_node = rest[0]
            html_str, _ = node_html(root_node)
            out.append(html_str)
    out.append("</ul>")
    return "".join(out)


def breadcrumbs(rel: str, root: str, docs: Path) -> str:
    parts = rel.split("/")
    crumbs = [f'<a href="{root}index.html">docs</a>']
    for i, part in enumerate(parts[:-1]):
        prefix = "/".join(parts[: i + 1])
        if (docs / prefix / "index.md").exists():
            crumbs.append(f'<a href="{root}{prefix}/index.html">{esc(part)}</a>')
        else:
            crumbs.append(esc(part))
    leaf = parts[-1][:-3] if parts[-1].endswith(".md") else parts[-1]
    crumbs.append(esc(leaf))
    return '<span class="sep">/</span>'.join(crumbs)


META_KEYS = ("source_path", "directory", "public_symbols", "depends_on",
             "depended_on_by", "internal_deps", "used_by",
             "last_synced_commit", "last_synced_at")


def meta_block(meta: dict) -> str:
    rows = [(k, meta[k]) for k in META_KEYS if meta.get(k)]
    if not rows:
        return ""
    body = "".join(f"<tr><td>{esc(k)}</td><td>{esc(v)}</td></tr>" for k, v in rows)
    return (f'<details class="meta"><summary>metadata</summary>'
            f"<table>{body}</table></details>")

# ----------------------------------------------------------------- build ---

def build(repo: Path) -> Path:
    docs = repo / "docs"
    site = docs / "_site"
    if site.exists():
        shutil.rmtree(site)
    site.mkdir(parents=True)

    langs = {}
    rmap_p = docs / "repo-map.json"
    if rmap_p.exists():
        rmap = json.loads(rmap_p.read_text(encoding="utf-8"))
        langs = {rel: meta.get("language", "")
                 for rel, meta in rmap.get("files", {}).items()}
        repo_name = rmap.get("repo_name", repo.name)
    else:
        repo_name = repo.name

    nav = build_nav(docs, langs)

    pages = []
    for p in sorted(docs.rglob("*.md")):
        rel = p.relative_to(docs).as_posix()
        if p.name in SKIP_NAMES or any(part in SKIP_DIRS
                                       for part in p.relative_to(docs).parts):
            continue
        pages.append((p, rel))

    for p, rel in pages:
        meta, body_md = split_frontmatter(p.read_text(encoding="utf-8"))
        body, title, has_mermaid = render_markdown(body_md)
        depth = rel.count("/")
        root = "../" * depth
        out = site / (rel[:-3] + ".html")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(PAGE_TMPL.format(
            title=esc(title or Path(rel).stem), repo=esc(repo_name),
            css=CSS, js=JS, root=root,
            nav=render_nav(nav, rel, root),
            crumbs=breadcrumbs(rel, root, docs),
            meta_block=meta_block(meta),
            body=body,
            mermaid=MERMAID_TAG if has_mermaid else ""), encoding="utf-8")

    for extra in ("llms.txt", "docs-index.json"):
        src = docs / extra
        if src.exists():
            shutil.copy2(src, site / extra)
    static = docs / "_static"
    if static.exists():
        shutil.copytree(static, site / "_static")

    print(f"Site built: {len(pages)} page(s) -> {site}")
    return site


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--serve", action="store_true",
                    help="build, then serve docs/_site over HTTP")
    ap.add_argument("--port", type=int, default=8000)
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    site = build(repo)

    if args.serve:
        import functools
        from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
        handler = functools.partial(SimpleHTTPRequestHandler, directory=str(site))
        with ThreadingHTTPServer(("127.0.0.1", args.port), handler) as srv:
            print(f"Serving docs at http://127.0.0.1:{args.port} (Ctrl-C to stop)")
            try:
                srv.serve_forever()
            except KeyboardInterrupt:
                pass


if __name__ == "__main__":
    main()
