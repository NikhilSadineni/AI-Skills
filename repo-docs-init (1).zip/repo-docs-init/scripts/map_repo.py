#!/usr/bin/env python3
"""map_repo.py — step 1 of repo-docs-init (deterministic, no LLM).

Walks a repository, classifies source files by language, extracts public
symbols, resolves the import-dependency graph (stdlib-filtered), and groups
files into MODULES — the unit of documentation work.

Modules default to the repository's top-level directories (plus a "(root)"
module for loose files at the repo root). The repo owner can override this
with a `modules:` list in .docsgen.yaml; every file is assigned to the
deepest listed module that contains it.

Output: docs/repo-map.json, consumed by plan.py, build_index.py and
build_site.py. The printed module list MUST be reviewed with the user
before plan.py init — module boundaries decide the shape of the docs.

Usage:
    python map_repo.py --repo /path/to/repo [--config /path/to/.docsgen.yaml]
                       [--out /path/to/repo/docs/repo-map.json]

Stdlib-only by design so it runs anywhere without installs.
"""
import argparse
import ast
import fnmatch
import json
import posixpath
import re
import sys
from pathlib import Path, PurePosixPath

# ---------------------------------------------------------------- config ---

DEFAULT_CONFIG = {
    "src_roots": ["src", "lib", "app"],   # used only to compute import names
    "modules": [],                        # empty = top-level directories
    "ignore": [
        ".git/*", ".*/*", "docs/*", "node_modules/*", "dist/*", "build/*",
        "out/*", "bin/*", "obj/*", "target/*", "venv/*", "__pycache__/*",
        "vendor/*", "*.min.js", "*.generated.*", "*.g.cs", "*.pb.go",
        "*_pb2.py", "tests/*", "test/*", "*/tests/*", "*/test/*", "*.spec.*",
        "*.test.*", "*_test.go", "test_*.py", "*_test.py",
    ],
    "repo_url": "",          # optional: base URL of the repo web UI
    "site_base_url": "",     # optional: where docs/_site will be hosted
}

LANG_BY_EXT = {
    ".py": "python", ".js": "javascript", ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "typescript", ".cs": "csharp",
    ".java": "java", ".go": "go", ".rb": "ruby", ".rs": "rust",
    ".php": "php", ".kt": "kotlin", ".scala": "scala", ".sql": "sql",
    ".sh": "shell", ".ps1": "powershell", ".c": "c", ".h": "c",
    ".cpp": "cpp", ".hpp": "cpp",
}

DOTTED_IMPORT_LANGS = {"python", "csharp", "java", "kotlin", "scala"}
STDLIB = set(getattr(sys, "stdlib_module_names", ()))


def load_config(path: Path | None) -> dict:
    cfg = {k: (list(v) if isinstance(v, list) else v)
           for k, v in DEFAULT_CONFIG.items()}
    if path and path.exists():
        parsed = _parse_simple_yaml(path.read_text(encoding="utf-8"))
        for k, v in parsed.items():
            if k == "ignore" and isinstance(v, list) and not v:
                print(f"WARNING: 'ignore' parsed as empty in {path.name}; "
                      "keeping defaults (check indentation).")
                continue
            cfg[k] = v
    else:
        print("NOTE: no .docsgen.yaml found — using built-in default config.")
    return cfg


def _parse_simple_yaml(text: str) -> dict:
    """Minimal YAML subset parser (scalars + string lists) so the skill has
    zero dependencies. Uses PyYAML instead when available."""
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except ImportError:
        pass
    out: dict = {}
    key = None
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        item = re.match(r"^\s+-\s+(.*)$", line)
        if item and key:
            out.setdefault(key, []).append(item.group(1).strip().strip("'\""))
        elif ":" in line and not line.startswith((" ", "\t")):
            key, _, val = line.partition(":")
            key, val = key.strip(), val.strip().strip("'\"")
            if val:
                out[key] = int(val) if val.isdigit() else val
                key = None
            else:
                out[key] = []
    return out

# ----------------------------------------------------------------- walk ----

def is_ignored(rel: str, patterns: list[str]) -> bool:
    p = PurePosixPath(rel)
    for pat in patterns:
        if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(p.name, pat):
            return True
        if pat.endswith("/*"):
            head = pat[:-2]
            if any(fnmatch.fnmatch(part, head) for part in p.parts[:-1]):
                return True
    return False


def find_source_files(repo: Path, cfg: dict) -> list[str]:
    files = []
    for f in sorted(repo.rglob("*")):
        if not f.is_file() or f.suffix.lower() not in LANG_BY_EXT:
            continue
        rel = f.relative_to(repo).as_posix()
        if is_ignored(rel, cfg["ignore"]):
            continue
        files.append(rel)
    return files

# -------------------------------------------------------------- symbols ----

def python_symbols_and_imports(path: Path) -> tuple[list[str], list[str]]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        return [], []
    syms, imps = [], []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if not node.name.startswith("_"):
                syms.append(node.name)
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imps += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            prefix = "." * node.level
            imps.append(prefix + node.module)
            imps += [f"{prefix}{node.module}.{a.name}" for a in node.names
                     if a.name != "*"]
    return syms, imps


GENERIC_PATTERNS = {
    "javascript": (
        re.compile(r"export\s+(?:default\s+)?(?:async\s+)?(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)"),
        re.compile(r"""(?:import\s.*?from\s+|require\()\s*['"]([^'"]+)['"]"""),
    ),
    "typescript": (
        re.compile(r"export\s+(?:default\s+)?(?:async\s+)?(?:function|class|const|let|interface|type|enum)\s+([A-Za-z_$][\w$]*)"),
        re.compile(r"""(?:import\s.*?from\s+|require\()\s*['"]([^'"]+)['"]"""),
    ),
    "csharp": (
        re.compile(r"public\s+(?:static\s+|sealed\s+|abstract\s+|partial\s+)*(?:class|interface|struct|enum|record)\s+(\w+)"),
        re.compile(r"^\s*using\s+([\w.]+)\s*;", re.M),
    ),
    "java": (
        re.compile(r"public\s+(?:final\s+|abstract\s+)*(?:class|interface|enum|record)\s+(\w+)"),
        re.compile(r"^\s*import\s+([\w.]+)\s*;", re.M),
    ),
    "go": (
        re.compile(r"^func\s+(?:\([^)]+\)\s+)?([A-Z]\w*)|^type\s+([A-Z]\w*)", re.M),
        re.compile(r"""^\s*(?:import\s+)?['"]([\w./-]+)['"]""", re.M),
    ),
}


def generic_symbols_and_imports(path: Path, lang: str) -> tuple[list[str], list[str]]:
    pats = GENERIC_PATTERNS.get(lang)
    if not pats:
        return [], []
    text = path.read_text(encoding="utf-8", errors="replace")
    sym_pat, imp_pat = pats
    syms = [next(g for g in m.groups() if g) for m in sym_pat.finditer(text)]
    imps = imp_pat.findall(text)
    return list(dict.fromkeys(syms)), list(dict.fromkeys(imps))

# ---------------------------------------------------------------- graph ----

def path_forms(rel: str, src_roots: list[str]) -> set[str]:
    """All the names by which a file might be imported: full path and
    src-root-stripped path, each in slash and dotted form; packages
    (__init__) also register their parent directory."""
    stem_path = PurePosixPath(rel).with_suffix("").as_posix()
    bases = {stem_path}
    for root in src_roots:
        root = str(root).rstrip("/")
        if root and root != "." and stem_path.startswith(root + "/"):
            bases.add(stem_path[len(root) + 1:])
    forms = set()
    for b in bases:
        forms.add(b.lower())
        forms.add(b.replace("/", ".").lower())
        if b.endswith("/__init__"):
            parent = b[: -len("/__init__")]
            forms.add(parent.lower())
            forms.add(parent.replace("/", ".").lower())
    return forms


def normalize_import(imp: str) -> tuple[str, int, bool]:
    s = imp.strip().replace("\\", "/")
    up, is_rel = 0, False
    if s.startswith("."):                       # python relative: '.x', '..x'
        dots = len(s) - len(s.lstrip("."))
        up, is_rel, s = dots - 1, True, s.lstrip(".")
    else:                                       # js/ts relative: './x', '../x'
        while s.startswith("./") or s.startswith("../"):
            if s.startswith("../"):
                up += 1
                s = s[3:]
            else:
                s = s[2:]
            is_rel = True
    return s.lower().rstrip("/"), up, is_rel


def resolve_file_deps(files: dict, file_imports: dict, src_roots: list[str]) -> None:
    """File→file edges within the repo. Adds 'internal_deps' and 'used_by'."""
    exact: dict[str, str] = {}
    stems: dict[str, list[str]] = {}
    for rel in files:
        for f in path_forms(rel, src_roots):
            exact[f] = rel
        stems.setdefault(PurePosixPath(rel).stem.lower(), []).append(rel)

    for rel in files:
        lang = files[rel].get("language", "")
        base_dir = posixpath.dirname(rel)
        deps = set()
        for imp in file_imports.get(rel, []):
            s, up, is_rel = normalize_import(imp)
            if not s:
                continue
            hit = None
            if is_rel:
                anchor = base_dir
                for _ in range(up):
                    anchor = posixpath.dirname(anchor)
                cand = posixpath.join(anchor, s.replace(".", "/")).lower()
                hit = exact.get(cand) or exact.get(cand.replace("/", "."))
            if hit is None:
                for cand in (s, s.replace("/", "."), s.replace(".", "/")):
                    if cand in exact:
                        hit = exact[cand]
                        break
            if hit is None:
                first = re.split(r"[./]", s, 1)[0]
                if lang == "python" and first in STDLIB:
                    continue
                if lang in DOTTED_IMPORT_LANGS or is_rel:
                    if "." not in s and "/" not in s:
                        cands = stems.get(s, [])
                        if len(cands) == 1 and (lang != "python" or s not in STDLIB):
                            hit = cands[0]
            if hit and hit != rel:
                deps.add(hit)
        files[rel]["internal_deps"] = sorted(deps)

    for rel in files:
        files[rel]["used_by"] = sorted(
            other for other, meta in files.items()
            if rel in meta.get("internal_deps", []))

# --------------------------------------------------------------- modules ---

def compute_module_list(files: list[str], cfg_modules: list[str]) -> list[str]:
    """Module set: config override, or top-level directories (+ '.' for loose
    root files). '.' is always the fallback for unassigned files."""
    if cfg_modules:
        mods = sorted({str(m).strip("/").strip() for m in cfg_modules if str(m).strip()})
    else:
        tops = sorted({rel.split("/", 1)[0] for rel in files if "/" in rel})
        mods = tops
    if any("/" not in rel for rel in files) or not mods:
        mods = mods + ["."]
    # if custom modules don't cover every file, '.' catches the rest
    elif cfg_modules:
        covered = lambda rel: any(rel == m or rel.startswith(m + "/") for m in mods)
        if any(not covered(rel) for rel in files):
            mods = mods + ["."]
    return mods


def assign_module(rel: str, modules: list[str]) -> str:
    """Deepest module that contains the file; '.' as fallback."""
    best = "."
    for m in modules:
        if m != "." and (rel == m or rel.startswith(m + "/")):
            if best == "." or len(m) > len(best):
                best = m
    return best


def build_modules(files: dict, module_list: list[str]) -> dict:
    mods: dict[str, dict] = {m: {"files": [], "languages": set(),
                                 "public_api": []} for m in module_list}
    for rel, meta in files.items():
        m = assign_module(rel, module_list)
        meta["module"] = m
        mods[m]["files"].append(rel)
        mods[m]["languages"].add(meta["language"])
        mods[m]["public_api"] += meta["public_symbols"]
    # drop modules that ended up empty (e.g. '.' when everything is covered)
    mods = {m: v for m, v in mods.items() if v["files"]}
    for m, v in mods.items():
        v["files"].sort()
        v["languages"] = sorted(v["languages"])
        v["public_api"] = sorted(set(v["public_api"]))[:40]
        v["loc"] = sum(files[f].get("loc", 0) for f in v["files"])

    for m in mods:
        mods[m]["depends_on"] = set()
    for rel, meta in files.items():
        m = meta["module"]
        for dep in meta.get("internal_deps", []):
            dm = files[dep]["module"]
            if dm != m and dm in mods:
                mods[m]["depends_on"].add(dm)
    for m in mods:
        mods[m]["depends_on"] = sorted(mods[m]["depends_on"])
    for m in mods:
        mods[m]["depended_on_by"] = sorted(
            k for k, v in mods.items() if m in v["depends_on"])
    return mods


def module_order(mods: dict) -> list[str]:
    """Dependencies first (write low-level modules before the things built on
    them). Cycles broken alphabetically."""
    remaining = dict(mods)
    order: list[str] = []
    placed: set[str] = set()
    while remaining:
        ready = sorted(m for m, v in remaining.items()
                       if all(d in placed or d not in mods
                              for d in v["depends_on"]))
        if not ready:                       # cycle — break it deterministically
            ready = [sorted(remaining)[0]]
        for m in ready:
            order.append(m)
            placed.add(m)
            remaining.pop(m)
    return order

# ----------------------------------------------------------------- main ----

def build_map(repo: Path, cfg: dict) -> dict:
    rels = find_source_files(repo, cfg)
    if not rels:
        sys.exit("ERROR: no source files found — check the ignore list in .docsgen.yaml.")

    files: dict[str, dict] = {}
    file_imports: dict[str, list[str]] = {}
    for rel in rels:
        lang = LANG_BY_EXT[Path(rel).suffix.lower()]
        path = repo / rel
        if lang == "python":
            syms, imps = python_symbols_and_imports(path)
        else:
            syms, imps = generic_symbols_and_imports(path, lang)
        with path.open(encoding="utf-8", errors="replace") as fh:
            loc = sum(1 for _ in fh)
        files[rel] = {"language": lang, "public_symbols": syms, "loc": loc}
        file_imports[rel] = imps

    resolve_file_deps(files, file_imports, cfg.get("src_roots", []))
    module_list = compute_module_list(rels, cfg.get("modules", []))
    mods = build_modules(files, module_list)

    return {
        "repo_name": repo.name,
        "repo_url": cfg.get("repo_url", "") or "",
        "site_base_url": cfg.get("site_base_url", "") or "",
        "modules": mods,
        "module_order": module_order(mods),
        "files": files,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--config", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    cfg_path = Path(args.config) if args.config else repo / ".docsgen.yaml"
    cfg = load_config(cfg_path if cfg_path.exists() else None)
    result = build_map(repo, cfg)

    out = Path(args.out) if args.out else repo / "docs" / "repo-map.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"Mapped {len(result['files'])} source files into "
          f"{len(result['modules'])} module(s) -> {out}\n")
    print("Proposed modules (each becomes ONE documentation task):\n")
    print(f"  {'module':<32} {'files':>5} {'lines':>7}  depends on")
    for m in result["module_order"]:
        info = result["modules"][m]
        label = "(root)" if m == "." else m
        deps = ", ".join("(root)" if d == "." else d
                         for d in info["depends_on"]) or "-"
        print(f"  {label:<32} {len(info['files']):>5} {info['loc']:>7}  {deps}")
    print("\nSTOP — review this module list with the user before continuing."
          "\nTo change it, set `modules:` in .docsgen.yaml (a list of repo-"
          "relative\ndirectory paths) and re-run this script. When the user "
          "approves, run\nplan.py init.")


if __name__ == "__main__":
    main()
