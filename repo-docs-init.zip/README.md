# repo-docs-init

Skill that generates an initial `/docs` tree for a code repository and builds a
self-contained static website for browsing it. The docs mirror the repo's
directory structure exactly 1:1 — one page per source file, one `index.md` per
directory — and every page carries machine-readable frontmatter so a PR-sync
pipeline can map code diffs to doc edits deterministically. LLM agents consume
the tree through `llms.txt` and `docs-index.json` instead of crawling code.

No Sphinx, no npm, no installs: every script is Python stdlib.

## The mapping rule

```
<repo_rel_path>       →  docs/reference/<repo_rel_path>.md
src/auth/session.py   →  docs/reference/src/auth/session.py.md
every directory       →  docs/reference/<dir>/index.md   (repo root → docs/reference/index.md)
```

Real path, real filename, `.md` appended — so two files named `config.py` in
different directories can never collide, and the docs tree is navigable by
anyone who knows the repo tree.

## Output layout (inside the target repo)

```
docs/
├── index.md                      # landing page (machine-generated)
├── _PLAN.md                      # validated, order-enforced progress plan
├── repo-map.json                 # machine model of the repo (map_repo.py)
├── docs-index.json               # file→page, dir→page, capability→dir maps  (emitted by clean build_index)
├── llms.txt                      # LLM entry point: capabilities + directory purposes
├── reference/                    # mirrors the repo 1:1
│   ├── index.md                  #   repo-root overview
│   ├── functionality.md          #   capability catalog + Capability → Module Map table
│   ├── glossary.md
│   └── src/
│       ├── index.md
│       └── auth/
│           ├── index.md          #   directory overview: purpose, invariants, files table
│           └── session.py.md     #   file page: why it exists, symbols, behavior notes
├── explanation/
│   ├── overview.md
│   ├── architecture.md           #   + Mermaid dependency diagram
│   ├── repo-map.md               #   wrapper for the interactive graph (machine-generated)
│   └── functionality-map.md      #   wrapper (machine-generated)
├── _static/
│   ├── repo-graph.html           # interactive dependency map (Cytoscape)
│   └── functionality-map.html    # capability ↔ directory bipartite graph
└── _site/                        # the built website (build_site.py) — host anywhere
```

## Scripts

| Script | Role | Deterministic? |
|---|---|---|
| `map_repo.py` | Walk the repo, classify files, extract public symbols, resolve import deps (stdlib filtered), emit `repo-map.json` | yes |
| `scaffold_docs.py` | Create/refresh the mirrored docs tree with frontmatter, tables, TODO markers; non-destructive on re-runs | yes |
| `plan.py` | `init` / `next` / `complete` / `status` / `refresh` — order-enforced task list in `docs/_PLAN.md`; `complete` validates pages before checking boxes | yes |
| `call_trace.py` | Draft a Mermaid sequenceDiagram from a Python entry point (`--entry file.py::symbol`); agent refines it | yes (draft only) |
| `build_graphs.py` | Generate the two interactive HTML graphs from `repo-map.json` + the capability table | yes |
| `build_index.py` | Final gate: validate the whole tree; on a clean run, stamp provenance and emit `docs-index.json` + `llms.txt` | yes |
| `build_site.py` | Render all pages to `docs/_site/` (own stdlib Markdown renderer, file-tree sidebar, Mermaid, link rewriting); `--serve` for local preview | yes |

The scripts own all *structure*; the agent writes only prose into
`<!-- TODO:PROSE -->` markers, per the editorial standard in `SKILL.md`.

## Typical run

```bash
cp scripts/config.yaml <repo>/.docsgen.yaml            # step 0 — adjust ignore globs, site_base_url
python scripts/map_repo.py      --repo <repo> --config <repo>/.docsgen.yaml --out <repo>/docs/repo-map.json
python scripts/scaffold_docs.py --repo <repo> --map <repo>/docs/repo-map.json
python scripts/plan.py init     --repo <repo>

# working loop (agent):
python scripts/plan.py next     --repo <repo>
#   ...write prose for that directory's pages...
python scripts/plan.py complete --repo <repo> --task M03

# after all directory + synthesis tasks:
python scripts/build_graphs.py  --repo <repo>
python scripts/build_index.py   --repo <repo>           # must be CLEAN → emits llms.txt, docs-index.json
python scripts/plan.py complete --repo <repo> --task V
python scripts/build_site.py    --repo <repo> --serve   # preview at http://127.0.0.1:8000
```

## Resuming

`docs/_PLAN.md` is the source of truth across sessions. In a new session:

```bash
python scripts/plan.py status --repo <repo>
```

If it reports commit drift, re-run `map_repo.py` + `scaffold_docs.py`
(non-destructive) and `plan.py refresh` — it reopens regressed tasks, appends
tasks for new directories, and reopens F and V. Then continue the working loop.

## Task order (enforced)

`M##` one per directory, leaves first (children documented before the parent's
index) → `F` functionality catalog → `O` overview → `A` architecture →
`G` glossary → `D` diagrams/graphs (requires F) → `V` validation gate.
`plan.py complete` refuses out-of-order completion.

## Troubleshooting

- **`complete` refuses a task** — read its output: either the page still has
  TODO/STALE markers (finish the prose) or the order is wrong (do the blocking
  tasks first). Never edit the checkboxes by hand.
- **`build_index.py` reports errors** — each line names the file and the rule
  (E1 missing page/row, E2 leftover marker, E3 broken link, E4 placeholder URL,
  E5 missing dir index, E6 graphs missing). Nothing is emitted until clean.
  `--allow-todos` / `--skip-graphs` downgrade E2/E6 for mid-plan smoke checks.
- **Functionality map says PLACEHOLDER** — the Capability → Module Map table in
  `reference/functionality.md` isn't filled/parseable yet (task F).
- **Wrong files documented** — fix `.docsgen.yaml` `ignore` globs and re-run
  `map_repo.py` + `scaffold_docs.py`; don't hand-edit `repo-map.json`.
- **Graphs/diagrams blank in the site** — they load Mermaid/Cytoscape from a
  CDN; the built site is otherwise fully offline.
