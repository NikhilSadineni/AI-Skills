---
name: repo-docs-init
description: Generate a complete /docs folder for a code repository — a source of truth humans and LLMs can read without opening the code. Mirrors the repo structure 1:1 (one page per source file, one index per directory), produces a functionality.md capability catalog, overview/architecture pages, docs-index.json, and llms.txt, and builds a self-contained static website for browsing (no Sphinx, no installs). Maintains a validated, order-enforced progress plan (docs/_PLAN.md) spanning multiple sessions. Use whenever the user asks to document a repository, create initial/baseline documentation, generate a docs site, or says "document this repo", "create the docs", "generate documentation for this codebase" — even if they only describe wanting an explanation of the codebase saved into the repo. ALSO use when asked to CONTINUE or RESUME documentation ("continue from the plan", "pick up where we left off") or when the repo has a docs/_PLAN.md with pending tasks.
---

# repo-docs-init: Initial Repository Documentation Generator

Generate the initial `/docs` tree for a repository. The output is the single source of truth consumed by three audiences, so structure discipline matters as much as prose quality:

1. **Humans** browse the pages as a static website (`scripts/build_site.py`, stdlib-only — no Sphinx, no npm).
2. **LLM agents** navigate via `llms.txt` (capabilities + directory purposes) and `docs-index.json` (file → page, capability → directory maps) instead of crawling code.
3. **The PR sync pipeline** uses frontmatter (`source_path`, `directory`) and the index to map code diffs to doc edits deterministically. If the mapping rule is violated, the pipeline breaks silently.

## The one rule everything depends on

The docs tree under `docs/reference/` mirrors the repository **exactly 1:1** (minus ignored files). Every source file maps to a doc page by a pure function of its path — the real path, real filename, `.md` appended:

```
<repo_rel_path>            →  docs/reference/<repo_rel_path>.md
src/auth/session.py        →  docs/reference/src/auth/session.py.md
src/core/a/config.py       →  docs/reference/src/core/a/config.py.md   (never collides with b/config.py)
every directory            →  docs/reference/<dir>/index.md            (repo root → docs/reference/index.md)
```

**Every source file gets its own page; every directory gets an `index.md` overview** — the functionality that directory provides, its design and connections, and Files / Subdirectories tables with a one-line overview of, and link to, each child. Never invent doc locations outside this rule; the scripts compute them for you.

## Output shape

Diátaxis two-quadrant split, generated from code:

- `docs/reference/` — facts, lookup-oriented, mirrors the repo: file pages + directory indexes, plus `functionality.md` (the capability catalog with the **Capability → Module Map** table) and `glossary.md`.
- `docs/explanation/` — understanding-oriented: `overview.md`, `architecture.md`, and machine-owned wrappers for the interactive graphs (`repo-map.md`, `functionality-map.md`).
- `docs/index.md` (landing page), `docs/llms.txt`, `docs/docs-index.json`, `docs/_static/*.html` (interactive graphs), and `docs/_site/` (the built website) are all machine-generated — never hand-edit them.

Tutorials and how-to guides (the other two Diátaxis quadrants) are deliberately out of scope: they encode user goals that cannot be derived from code. If the user asks for them, create `docs/tutorials/` and `docs/how-to/` and link them from the landing page prose — but the content is theirs to seed.

## Workflow

**FIRST, check for an existing plan.** If `docs/_PLAN.md` exists in the target repo, this is a resume, not a fresh start — jump directly to the **Working loop** below (do not re-run map/scaffold unless `plan.py status` reports commit drift). Trust the plan file over anything the user or you remember about prior progress: checked boxes were validated, unchecked ones were not.

Otherwise follow these steps in order. Steps 1, 2, 2.5, the graphs, the final gate, and the site build are deterministic scripts — run them, don't reimplement them.

### Step 0 — Configure

Copy `scripts/config.yaml` to the target repo root as `.docsgen.yaml` if it doesn't already exist, then adjust: `src_roots` (only used to strip prefixes when resolving import names — it does not limit what gets documented), `ignore` globs, and `site_base_url` (ask the user for the base URL if unknown; leave the placeholder if they don't have one yet). If `.docsgen.yaml` already exists in the repo, use it as-is — it's the repo owner's configuration.

### Step 1 — Map the repository (deterministic)

```bash
python scripts/map_repo.py --repo <repo_root> --config <repo_root>/.docsgen.yaml --out <repo_root>/docs/repo-map.json
```

This walks the tree (respecting ignore globs), classifies files by language, extracts public symbols, resolves the import-dependency graph (stdlib imports are filtered out), and records every directory with its files, subdirectories, and dependency edges. Review the printed directory summary before continuing. If it looks wrong (test folders included, vendored code documented), fix `.docsgen.yaml` and re-run — do not hand-edit `repo-map.json`.

### Step 2 — Scaffold the docs tree (deterministic)

```bash
python scripts/scaffold_docs.py --repo <repo_root> --map <repo_root>/docs/repo-map.json
```

This creates one page per source file and one `index.md` per directory — mirroring the repo — with frontmatter, headings, symbol tables, Files/Subdirectories tables, and cross-links already in place; stubs `reference/functionality.md`, `reference/glossary.md`, `explanation/overview.md`, `explanation/architecture.md`; and regenerates the machine-owned landing page and graph wrappers. Every place needing prose is marked `<!-- TODO:PROSE ... -->` with a hint. Never change frontmatter keys, headings, tables' link cells, or machine lines — only replace the TODO markers with prose.

### Step 2.5 — Create the work plan (deterministic)

```bash
python scripts/plan.py init --repo <repo_root>
```

This writes `docs/_PLAN.md`: **one task per directory**, ordered leaves-first (post-order) so children are documented before their parent's index, then the synthesis tasks FUNCTIONALITY → OVERVIEW → ARCHITECTURE → GLOSSARY → DIAGRAMS, then the final validation gate `V`. **The order is enforced** — `plan.py complete` refuses synthesis tasks while directory tasks remain open, refuses `D` before `F`, and refuses `V` before everything else. The plan is the source of truth for progress across sessions — codebases are usually too large to finish in one conversation, and this file is how a future session knows exactly where to continue. Commit it with the docs.

### Working loop — write prose task by task

Repeat until the session's budget runs out or all tasks are done:

```bash
python scripts/plan.py next --repo <repo_root>      # what to work on
# ... do the writing work for that one directory ...
python scripts/plan.py complete --repo <repo_root> --task <ID>
```

`complete` **validates the pages** (no TODO/STALE markers, no placeholder links, table rows present) and refuses to check the box otherwise — never edit `_PLAN.md` checkboxes by hand, and never claim a task done without running `complete`.

Each **directory task** covers the directory's `index.md` **and every file page directly in it** — `plan.py complete` validates the whole set:

1. Read the directory's actual source files. Read enough to understand *why* it exists, not just what it contains. Read the callers too (the `used_by` list in file frontmatter, `depended_on_by` in the index) — purpose is usually visible from the outside.
2. Write the **file pages first**: the opening paragraph (why this file exists as a separate file), the "What it provides" symbol table (one line per public symbol at *why*-level — never a signature restatement; "creates a session" is worthless, "mints the opaque token and enforces the per-user session cap" is the bar), and Behavior notes (side effects, failure modes, state/concurrency assumptions; write "None notable." only if you verified that by reading the code). The `Internal dependencies:`, `Used by:`, and `Size:` lines are machine-generated — leave them exactly as scaffolded.
3. Then write the **directory `index.md`** *from the file pages*: Purpose; **Functionality provided** (the capabilities this directory contributes, consumer's perspective, with `path::symbol` entry points — link the catalog rather than duplicating it); Design & Invariants; How It Connects; and the one-line overview per row in the Files and Subdirectories tables (each row already links its page — fill only the overview cell). Subdirectory rows can lift the first line of the child index's Purpose — the children are already written, that's why order matters.
4. Keep every heading, frontmatter line, machine line, and table link exactly as scaffolded.

For repos too large to read exhaustively, prioritize: public API files first, largest files second, and skim the rest. Say so honestly in the page ("less-trafficked helpers in `util/` are documented at survey level").

For the **synthesis tasks** (F, O, A, G), write **from the directory pages you already wrote, not from raw code** — this keeps altitude consistent and the pages mutually coherent:

**`F` — functionality.md first.** This page documents the system by *what it provides*, not how it is organized — the page a person or LLM reads to understand immediately why this codebase exists. One subsection per distinct capability following the commented template in the scaffold: what it does (consumer's perspective), why it exists (the requirement that forced it), entry points in `path::symbol` form, and links to implementing directories. Coverage matters here: enumerate capabilities by walking your index pages' Purpose sections and the `public_api` lists — **all functionality the code provides must appear**; a capability absent from this page is invisible to readers. Capabilities deliberately cross directory boundaries ("process a payment" may span `api`, `billing`, and `storage`); that cross-cutting view is the point. **Finish the Capability → Module Map table** — it is machine-parsed to build `docs-index.json`'s capability map, `llms.txt`, and the interactive functionality graph, so every capability needs a row.

**`O` — explanation/overview.md**: what the system is, its five-or-fewer major parts, the two or three key data/control flows, where a newcomer starts reading. It links to the functionality catalog for the capability view — don't duplicate the catalog here.

**`A` — explanation/architecture.md**: cross-cutting decisions and the Mermaid dependency diagram the scaffold generated (verify it renders in the site preview; prune edges below the significance threshold if it's spaghetti). **`G`** — fill reference/glossary.md with domain terms you found yourself needing to explain more than once.

**Diátaxis boundary while writing:** file pages, directory indexes, and the catalog are *reference* — state facts, invariants, and tightly-scoped warnings; keep system-level reasoning out. `explanation/` pages carry the extended *why* — narrative, trade-offs, history — and should not restate reference facts. When an index's Design & Invariants section wants to grow past a paragraph or two of rationale, that's the signal the content belongs in `explanation/` (link to it from the index).

**`D` — diagrams and interactive graphs** (enforced after F, since it consumes the capability table):

1. For each major capability in `reference/functionality.md`, add a Flow: a plain ```` ```mermaid ```` `sequenceDiagram`. Draft it with `python scripts/call_trace.py --repo <repo_root> --entry <file_rel>::<symbol>` using the capability's entry point, then **refine — the draft is never the final artifact**: static tracing misses dynamic dispatch, queues, and HTTP hops, and it doesn't know intent. Prune internal noise, rename the actor to the real one, put *meaning* on each arrow rather than function names, and add the failure path with `alt`. For non-Python entry points the script only lists participants; write the diagram from reading the code.
2. Run `python scripts/build_graphs.py --repo <repo_root>`. This generates `docs/_static/repo-graph.html` (interactive dependency map — directories as containers, files inside them, click-through to doc pages, sized by LOC, colored by language) and `docs/_static/functionality-map.html` (capability ↔ directory bipartite graph parsed from the catalog's table). Both are machine-owned — regenerate, never edit. If the functionality map reports PLACEHOLDER, task F's table isn't parseable yet.
3. `plan.py complete --task D` validates that both HTML files exist, the functionality map is not a placeholder, and at least one sequenceDiagram exists in the catalog.

### Final gate — task `V`

```bash
python scripts/build_index.py --repo <repo_root>
```

This **validates the whole tree** — every mapped source file has a page, every directory has an index, every internal link resolves, no TODO/STALE markers or placeholder URLs remain, graphs exist — and, **only when clean**, stamps `last_synced_commit` into every page's frontmatter (when run inside a git repo) and emits `docs/docs-index.json` and `docs/llms.txt`. Fix every reported error and re-run until clean, then `plan.py complete --task V`. A clean run is the contract downstream tooling relies on.

### Build and preview the website

```bash
python scripts/build_site.py --repo <repo_root>            # writes docs/_site/
python scripts/build_site.py --repo <repo_root> --serve    # + local preview server
```

Stdlib-only static site generator: renders every doc page to HTML with the repo hierarchy as a collapsible file-tree sidebar (original filenames, language-colored dots), breadcrumbs, a filter box, Mermaid rendering, and rewritten `.md → .html` links; copies `llms.txt`, `docs-index.json`, and the interactive graphs in. `docs/_site/` is fully self-contained — host it on any static file server (the only network dependency is the Mermaid/Cytoscape CDN on pages that use them). Spot-check a few pages in the preview: the dependency diagram renders, graph pages load, file-tree navigation matches the repo.

### Ending a session before the plan is finished

When stopping mid-plan: make sure every task you worked on is either `complete`d or still honestly unchecked (a page with remaining TODOs stays unchecked — that is correct, not a failure). Run `plan.py status`, report progress to the user, remind them to commit `/docs` including `_PLAN.md`, and tell them the resume instruction for a new chat: *"Point the repo-docs-init skill at this repo and say 'continue from docs/_PLAN.md'"*.

### Resuming in a fresh session

When resuming: run `plan.py status --repo <repo_root>` first. If it reports commit drift (code changed since the plan was made), re-run `map_repo.py` and `scaffold_docs.py` (both non-destructive), then `plan.py refresh` — it reopens completed tasks whose pages gained new TODO/STALE markers, appends tasks for new directories, retires tasks whose directory was removed from the repo, and reopens F, O, A, D and V as needed (catalog, overview, architecture and graphs must reflect the new directory set). Then enter the working loop. Never assume prior-session context; the plan file and the pages themselves carry all state.

### Final report

Summarize for the user: tasks completed this session, overall plan progress, anything documented at survey level, validation status, and suggested next steps (host `docs/_site/`; point LLM agents at `docs/llms.txt`; wire up the PR sync pipeline).

## Editorial standard

This is the difference between documentation worth maintaining and noise. The reader can already read code — give them only what the code cannot say.

**Document why, not what.** Never enumerate parameters, restate signatures, or narrate implementation ("this function loops over users"). Every sentence should survive this test: *could the reader have learned this in ten seconds of reading the code itself?* If yes, delete it.

**Lead with purpose and responsibility.** The Purpose section states what problem the directory owns and, just as importantly, what it deliberately does *not* handle. Boundaries prevent misuse.

**Surface invariants and constraints.** The things that break if violated: "all crypto goes through `crypto.py` so algorithms rotate in one place", "session tokens are opaque, not JWTs, because revocation must land in under 1s". If a design choice looks odd, hunt for the constraint that forced it (git history and comments often hold the answer) and record it. If you can't find the reason, write "reason not evident from code or history" rather than inventing one — a wrong rationale is worse than none.

**Name the gotchas.** Each directory index should tell a newcomer the two or three things they would get wrong on their first PR into this code.

**Reference code by name, never by line number.** Use `path::symbol` form (`src/auth/session.py::create_session`). Line numbers rot; names are durable.

**Calibrated confidence.** Distinguish what you verified from what you inferred. "Appears to assume single-writer access (no locking found)" is honest; stating it as fact is not.

**Length discipline.** 300–800 words of prose per directory (index plus its file pages, excluding scaffolded structure). A file page's prose is typically 2–5 sentences plus its symbol table lines. If you need much more, the directory probably deserves splitting — flag it rather than sprawling.

**Voice.** Plain, direct, present tense, no marketing. Write for a competent engineer new to this repo, or an LLM agent with no context — the same text serves both.

Read `references/page-example.md` before writing your first page — it shows a completed file page and directory index at the expected quality bar. `references/page-template.md` documents every structural element and which ones are immutable.

## Re-running on an already-documented repo

If `docs/` already exists with pages: this skill regenerates *structure* non-destructively. `scaffold_docs.py` adds pages for new files and directories, adds missing table rows, marks pages whose source files vanished with a `<!-- STALE:REMOVED -->` banner (below the frontmatter — frontmatter stays parseable), and never overwrites existing prose. Your job then is to write prose for the new TODOs, resolve the STALE pages (delete the page and its table row, or rewrite if the file was renamed), run `plan.py refresh`, work the reopened tasks, and re-run `build_index.py` until clean. Incremental *content* sync for code changes is the PR pipeline's job, not this skill's.

## Failure modes to avoid

- Writing docs from file names without reading the code. If you haven't read it, mark the section "not yet reviewed" rather than confabulating.
- Restating code mechanics to fill space. Short honest pages beat long redundant ones.
- Editing scaffolded structure (frontmatter, headings, machine lines, table link cells). The pipeline, the plan validator, and the site build depend on these byte-for-byte.
- Hand-editing `_PLAN.md` checkboxes or claiming a task done without `plan.py complete`. A checked box means "validated", nothing less.
- Working synthesis tasks before the directory tasks are done. The plan enforces this; don't fight it — F/O/A/G are written *from* the directory pages.
- Re-running map/scaffold on resume when the plan shows no drift — it wastes budget and can add noise.
- Documenting test directories, generated code, or vendored dependencies. The default config excludes them; keep it that way unless the user asks.
- Skipping validation. A clean `build_index.py` run (task `V`) is the definition of done — it is also the only thing that emits `llms.txt` and `docs-index.json`.
