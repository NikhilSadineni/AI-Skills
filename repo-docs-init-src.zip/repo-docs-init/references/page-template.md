# Module Page Template — Structural Contract

This file documents every element of a scaffolded module page and whether
Claude may edit it. The PR sync pipeline and the editor shortcut parse these
pages mechanically; the elements marked IMMUTABLE are load-bearing.

## Anatomy

```markdown
---
module: auth                                  # IMMUTABLE (scripts own it)
source_files: [session.py, tokens.py]         # IMMUTABLE (scripts own it)
source_paths: [src/auth/session.py, ...]      # IMMUTABLE (scripts own it)
public_api: [create_session, validate_token]  # IMMUTABLE (scripts own it)
depends_on: [storage, config]                 # IMMUTABLE (scripts own it)
depended_on_by: [api, admin]                  # IMMUTABLE (scripts own it)
last_synced_commit: a3f8c2d                   # IMMUTABLE (build_index stamps it)
last_synced_at: 2026-07-09                    # IMMUTABLE (build_index stamps it)
---

# auth                                        # IMMUTABLE heading

## Purpose                                    # IMMUTABLE heading
<prose>                                       # EDITABLE — your work

## Design & Invariants                        # IMMUTABLE heading
<prose>                                       # EDITABLE — your work

## How It Connects                            # IMMUTABLE heading
<prose>                                       # EDITABLE — your work

## session.py {#sessionpy}                    # IMMUTABLE heading + anchor
<prose>                                       # EDITABLE — your work

**What it provides**                          # IMMUTABLE label
| Symbol | What it does & why it matters |    # table: Symbol column GENERATED
| `create_session` | <one line, why-level> |  #        right column EDITABLE

**Behavior notes**                            # IMMUTABLE label
<prose>                                       # EDITABLE — side effects,
                                              #  failure modes, assumptions

Internal dependencies: `src/auth/crypto.py`   # IMMUTABLE (machine-generated)
Used by: `src/api/handlers.py`                # IMMUTABLE (machine-generated)
Size: 42 lines (python)                       # IMMUTABLE (machine-generated)

[View source](https://dev.azure.com/...)      # IMMUTABLE back-link
```

## Rules

1. **Anchors are forever.** `{#sessionpy}` is the deep-link target for the
   editor shortcut and for cross-page links. Never rename, remove, or add
   anchors by hand — `scaffold_docs.py` owns them.
2. **Frontmatter is generated.** If frontmatter looks wrong (e.g., a file is
   missing from `source_files`), fix `.docsgen.yaml` or the code layout and
   re-run the scripts. Hand-edits get overwritten and desynchronize the index.
3. **Prose goes only where TODO markers were.** Replacing a
   `<!-- TODO:PROSE ... -->` marker with prose is the entire editing surface.
   You may add sub-paragraphs, short lists where genuinely clearer, and
   Mermaid diagrams inside EDITABLE regions.
4. **Cross-references** between module pages use relative links with anchors:
   `[storage](storage.md#redis_clientpy)`. `build_index.py` verifies they
   resolve (error E3 if not).
5. **Code references** in prose use `path::symbol` form, never line numbers:
   `` `auth/session.py::create_session` ``.
6. **Section order** for file sections follows `source_files` order. Do not
   reorder sections.

## Synthesis pages

`OVERVIEW.md` and `ARCHITECTURE.md` have looser structure — their scaffolded
headings should be kept, but you may add sections. The module table in
OVERVIEW.md must keep one row per module with a working relative link; fill
the one-line purpose column. The Mermaid graph in ARCHITECTURE.md is
generated; you may prune visually-noisy edges but note any pruning in prose.
