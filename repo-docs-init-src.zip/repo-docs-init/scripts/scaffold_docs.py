#!/usr/bin/env python3
"""scaffold_docs.py — Phase 1 scaffolding for repo-docs-init (deterministic).

Reads repo-map.json and creates the docs/ tree: one page per module with
frontmatter, anchored per-file sections, and source back-links already in
place. Prose locations are marked with <!-- TODO:PROSE --> for Claude to fill.

Non-destructive on re-run: existing prose is never touched. New files get new
sections; sections whose source files disappeared are marked <!-- STALE:REMOVED -->.

Usage:
    python scaffold_docs.py --repo /path/to/repo [--map /path/to/docs/repo-map.json]
"""
import argparse
import json
import re
from datetime import date
from pathlib import Path

TODO = "<!-- TODO:PROSE {hint} -->"

def slug(filename: str) -> str:
    """Stable anchor for a file section: 'session.py' -> 'sessionpy'."""
    return re.sub(r"[^a-z0-9_]", "", Path(filename).name.lower())

def page_path(mkey: str) -> str:
    return "modules/_root.md" if mkey == "_root" else f"modules/{mkey}.md"

def source_url(base: str, rel: str) -> str:
    # Works for ADO web UI when base is like
    # https://dev.azure.com/org/project/_git/repo — appended as ?path=/...
    if "_git" in base:
        return f"{base}?path=/{rel}"
    return f"{base}/{rel}"

def file_section(rel: str, meta: dict, repo_url: str) -> str:
    name = Path(rel).name
    anchor = slug(name)
    syms = meta.get("public_symbols", [])
    hint = (f"2-5 sentences: what {name} contributes to this module and why it "
            f"exists as a separate file. Do NOT restate signatures.")

    if syms:
        rows = "\n".join(
            f"| `{s}` | {TODO.format(hint='one line, why-level: the job it does and when a caller reaches for it')} |"
            for s in syms[:10])
        overflow = ""
        if len(syms) > 10:
            overflow = ("\nAdditional symbols: "
                        + ", ".join(f"`{s}`" for s in syms[10:]) + "\n")
        symbol_block = (
            "**What it provides**\n\n"
            "| Symbol | What it does & why it matters |\n|---|---|\n"
            f"{rows}\n{overflow}")
    else:
        symbol_block = "Key public symbols: (none detected)\n"

    deps = ", ".join(f"`{d}`" for d in meta.get("internal_deps", [])) or "(none within repo)"
    used = ", ".join(f"`{u}`" for u in meta.get("used_by", [])) or "(none within repo)"
    behavior_hint = ("side effects, failure modes, state/concurrency assumptions, "
                     "and performance characteristics worth knowing. Write "
                     "'None notable.' only if you verified that.")
    return (
        f"## {name} {{#{anchor}}}\n\n"
        f"{TODO.format(hint=hint)}\n\n"
        f"{symbol_block}\n"
        f"**Behavior notes**\n\n"
        f"{TODO.format(hint=behavior_hint)}\n\n"
        f"Internal dependencies: {deps}\n"
        f"Used by: {used}\n"
        f"Size: {meta.get('loc', '?')} lines ({meta.get('language', '?')})\n\n"
        f"[View source]({source_url(repo_url, rel)})\n"
    )

def module_page(mkey: str, m: dict, files: dict, repo_url: str, today: str) -> str:
    fm = [
        "---",
        f"module: {mkey}",
        f"source_files: [{', '.join(Path(f).name for f in m['source_files'])}]",
        f"source_paths: [{', '.join(m['source_files'])}]",
        f"public_api: [{', '.join(m['public_api'][:15])}]",
        f"depends_on: [{', '.join(m['depends_on'])}]",
        f"depended_on_by: [{', '.join(m['depended_on_by'])}]",
        "last_synced_commit: UNSTAMPED",
        f"last_synced_at: {today}",
        "---",
    ]
    body = [
        f"# {mkey}",
        "",
        "## Purpose",
        "",
        TODO.format(hint="2-3 paragraphs: why this module exists, what responsibility it owns, and what it deliberately does NOT handle."),
        "",
        "## Design & Invariants",
        "",
        TODO.format(hint="The decisions and constraints NOT visible in the code: invariants, why odd-looking choices were forced, the 2-3 things a newcomer would get wrong."),
        "",
        "## How It Connects",
        "",
        TODO.format(hint=f"Callers, callees, data flows. depends_on: [{', '.join(m['depends_on']) or 'none'}]; depended_on_by: [{', '.join(m['depended_on_by']) or 'none'}]. Link other module pages with relative links."),
        "",
    ]
    for rel in m["source_files"]:
        body.append(file_section(rel, files.get(rel, {}), repo_url))
    return "\n".join(fm) + "\n\n" + "\n".join(body)

def mermaid_graph(modules: dict) -> str:
    lines = ["```mermaid", "graph TD"]
    for k, m in modules.items():
        node = k.replace("/", "_").replace("-", "_") or "root"
        lines.append(f'    {node}["{k}"]')
    for k, m in modules.items():
        src = k.replace("/", "_").replace("-", "_") or "root"
        for d in m["depends_on"]:
            dst = d.replace("/", "_").replace("-", "_") or "root"
            lines.append(f"    {src} --> {dst}")
    lines.append("```")
    return "\n".join(lines)

OVERVIEW_TMPL = """# {repo} — Overview

{todo_purpose}

For the system described by *what it can do* rather than how it is
structured, see the [Functionality Catalog](FUNCTIONALITY.md).

## Major Components

{todo_components}

| Module | Purpose (one line) |
|---|---|
{module_rows}

## Key Flows

{todo_flows}

## Where To Start Reading

{todo_start}
"""

FUNCTIONALITY_TMPL = """# {repo} — Functionality Catalog

{todo_intro}

<!-- Editorial contract for this page:
Document the system by WHAT IT PROVIDES, not how it is organized. A reader
(human or LLM) who finishes this page should know every job this codebase can
do, why each job exists, and where to enter the code to invoke or change it.
Write this page AFTER all module pages, synthesizing from them. One
subsection per distinct capability, using exactly this shape: -->

## Capabilities

{todo_capabilities}

<!-- Template for each capability (copy per capability):

### <Capability name, verb phrase, e.g. "Create and validate user sessions">

**What it does:** One or two sentences, consumer's perspective.

**Why it exists:** The problem or requirement that forced this capability
into existence. If the reason is not evident from code or history, say so.

**Entry points:** `path/file.py::symbol` (the functions/classes a consumer
or maintainer starts from — path::symbol form, never line numbers).

**Implemented in:** [module](modules/<module>.md) links, main ones first.

-->

## Capability → Module Map

| Capability | Primary modules | Entry point |
|---|---|---|
{todo_map_rows}
"""

ARCH_TMPL = """# {repo} — Architecture

{todo_decisions}

## Component Dependency Graph

{mermaid}

## Cross-Cutting Concerns

{todo_crosscut}
"""

def upsert_module_page(path: Path, new_content: str, m: dict, repo_url: str, files: dict) -> str:
    """Create page, or non-destructively add sections for new files and mark
    sections for removed files. Returns action taken."""
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(new_content, encoding="utf-8")
        return "created"
    text = path.read_text(encoding="utf-8")
    changed = False
    # add sections for files not yet present
    for rel in m["source_files"]:
        anchor = slug(Path(rel).name)
        if f"{{#{anchor}}}" not in text:
            text = text.rstrip() + "\n\n" + file_section(rel, files.get(rel, {}), repo_url)
            changed = True
    # mark sections whose source vanished
    current_anchors = {slug(Path(r).name) for r in m["source_files"]}
    for match in re.finditer(r"^## (\S+) \{#([a-z0-9_]+)\}", text, re.M):
        if match.group(2) not in current_anchors and "STALE:REMOVED" not in text[match.start():match.start()+200]:
            ins = match.end()
            text = text[:ins] + "\n\n<!-- STALE:REMOVED source file no longer exists; delete or fold content into another section -->" + text[ins:]
            changed = True
    if changed:
        path.write_text(text, encoding="utf-8")
        return "updated"
    return "unchanged"

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--map", default=None)
    ap.add_argument("--repo-url", default="", help="Base URL of the repo web UI for source back-links (e.g. https://dev.azure.com/org/proj/_git/repo)")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    map_path = Path(args.map) if args.map else repo / "docs" / "repo-map.json"
    rmap = json.loads(map_path.read_text(encoding="utf-8"))
    docs = repo / "docs"
    repo_url = args.repo_url or f"REPO_URL_PLACEHOLDER"
    today = date.today().isoformat()

    actions = {}
    for mkey, m in rmap["modules"].items():
        p = docs / page_path(mkey)
        content = module_page(mkey, m, rmap["files"], repo_url, today)
        actions[mkey] = upsert_module_page(p, content, m, repo_url, rmap["files"])

    rows = "\n".join(
        f"| [{k}]({page_path(k)}) | {TODO.format(hint='one line')} |"
        for k in rmap["suggested_writing_order"]
    )
    t = lambda hint: TODO.format(hint=hint)
    for name, content in [
        ("FUNCTIONALITY.md", FUNCTIONALITY_TMPL.format(
            repo=rmap["repo_name"],
            todo_intro=t("2-3 sentences: what this system provides to its consumers, written for someone who has never seen the code. Write AFTER module pages."),
            todo_capabilities=t("One ### subsection per distinct capability, following the commented template below. Cover ALL functionality the code provides — a capability absent here is invisible to readers."),
            todo_map_rows=t("| rows: one per capability | [module](modules/x.md) links | `path::symbol` |"))),
        ("OVERVIEW.md", OVERVIEW_TMPL.format(
            repo=rmap["repo_name"],
            todo_purpose=t("3-5 sentences: what this system does and for whom. Write LAST, from the module pages."),
            todo_components=t("Prose naming the <=5 major parts and their relationships."),
            module_rows=rows,
            todo_flows=t("The 2-3 key data/control flows end to end, referencing module pages."),
            todo_start=t("Reading order for a newcomer."))),
        ("ARCHITECTURE.md", ARCH_TMPL.format(
            repo=rmap["repo_name"],
            todo_decisions=t("Cross-cutting decisions and their forcing constraints. Write LAST."),
            mermaid=mermaid_graph(rmap["modules"]),
            todo_crosscut=t("Auth, error handling, logging, config — patterns that span modules."))),
        ("GLOSSARY.md", "# Glossary\n\n" + t("Domain terms you needed to explain more than once while writing module pages. | Term | Meaning | table.") + "\n"),
    ]:
        p = docs / name
        if not p.exists():
            p.write_text(content, encoding="utf-8")
            actions[name] = "created"
        else:
            actions[name] = "unchanged"

    created = sum(1 for a in actions.values() if a == "created")
    updated = sum(1 for a in actions.values() if a == "updated")
    print(f"Scaffold complete: {created} created, {updated} updated, "
          f"{len(actions)-created-updated} unchanged, under {docs}")
    print("\nWrite prose in this order (bottom-up):")
    for k in rmap["suggested_writing_order"]:
        print(f"  docs/{page_path(k)}  [{actions.get(k)}]")
    print("Then OVERVIEW.md and ARCHITECTURE.md last, from the module pages.")
    if repo_url == "REPO_URL_PLACEHOLDER":
        print("\nNOTE: pass --repo-url to fill real source back-links "
              "(placeholders were written; build_index.py will flag them).")

if __name__ == "__main__":
    main()
