#!/usr/bin/env python3
"""call_trace.py — draft a sequence diagram from an entry point (deterministic).

Statically traces calls from a given entry point through the repo's Python
files and prints (a) an indented call tree and (b) a DRAFT Mermaid
sequenceDiagram. The draft is a starting point for the agent, never the final
artifact: static tracing cannot see dynamic dispatch, DI containers, queues,
or HTTP hops, and it doesn't know what each call MEANS. The agent must prune,
name the actor, annotate intent, and add error paths before embedding it in
reference/functionality.md as a plain ```mermaid fenced block.

Non-Python entry points are not traced (prints participants only, from the
module dependency graph) — write those diagrams from reading the code.

Usage:
    python call_trace.py --repo <repo_root> --entry src/auth/session.py::create_session [--depth 4]
"""
import argparse
import ast
import json
import posixpath
import sys
from pathlib import Path, PurePosixPath

def build_symbol_index(repo: Path, files: dict) -> dict:
    """name -> list[(file_rel, qualname)] for every function/method in mapped
    Python files."""
    index: dict[str, list] = {}
    asts: dict[str, ast.AST] = {}
    for rel, meta in files.items():
        if meta.get("language") != "python":
            continue
        try:
            tree = ast.parse((repo / rel).read_text(encoding="utf-8",
                                                    errors="replace"))
        except SyntaxError:
            continue
        asts[rel] = tree
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                index.setdefault(node.name, []).append((rel, node.name))
    return index, asts

def find_function(asts: dict, rel: str, name: str):
    tree = asts.get(rel)
    if not tree:
        return None
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) \
                and node.name == name:
            return node
    return None

def callee_names(fn: ast.AST):
    """Ordered call targets inside a function body: bare names and attribute
    tails (obj.method -> 'method')."""
    out = []
    for node in ast.walk(fn):
        if isinstance(node, ast.Call):
            f = node.func
            if isinstance(f, ast.Name):
                out.append(f.id)
            elif isinstance(f, ast.Attribute):
                out.append(f.attr)
    return out

def trace(repo: Path, asts: dict, index: dict, rel: str, name: str,
          depth: int, seen: set, indent: int, lines: list, hops: list):
    fn = find_function(asts, rel, name)
    if not fn or depth < 0:
        return
    for callee in callee_names(fn):
        targets = index.get(callee, [])
        # prefer same-file resolution, else first repo match; skip stdlib/ext
        target = next((t for t in targets if t[0] == rel), targets[0] if targets else None)
        if not target:
            continue
        t_rel, t_name = target
        key = (rel, name, t_rel, t_name)
        if key in seen:
            continue
        seen.add(key)
        lines.append("  " * indent + f"{t_rel}::{t_name}")
        hops.append((rel, t_rel, t_name))
        trace(repo, asts, index, t_rel, t_name, depth - 1, seen,
              indent + 1, lines, hops)

def participant(rel: str) -> str:
    return PurePosixPath(rel).stem

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--entry", required=True,
                    help="entry point as <file_rel>::<symbol>, e.g. src/auth/session.py::create_session")
    ap.add_argument("--depth", type=int, default=4)
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    rmap = json.loads((repo / "docs" / "repo-map.json").read_text(encoding="utf-8"))
    try:
        rel, name = args.entry.split("::", 1)
    except ValueError:
        sys.exit("ERROR: --entry must be <file_rel>::<symbol>")
    if rmap["files"].get(rel, {}).get("language") != "python":
        print("Entry is not a mapped Python file — static tracing unavailable.")
        d = posixpath.dirname(rel) or "."
        deps = rmap.get("dirs", {}).get(d, {}).get("depends_on", [])
        print("Participants to consider (directory deps):",
              ", ".join(deps) or "n/a")
        return

    index, asts = build_symbol_index(repo, rmap["files"])
    lines, hops = [f"{rel}::{name}"], []
    trace(repo, asts, index, rel, name, args.depth, set(), 1, lines, hops)

    print("=== CALL TREE (static, best-effort) ===")
    print("\n".join(lines))

    print("\n=== DRAFT sequenceDiagram (refine before embedding!) ===")
    print("```mermaid")
    print("sequenceDiagram")
    print(f"    actor User")
    parts = [participant(rel)]
    for _, t_rel, _ in hops:
        p = participant(t_rel)
        if p not in parts:
            parts.append(p)
    for p in parts:
        print(f"    participant {p}")
    print(f"    User->>+{participant(rel)}: {name}(...)")
    for f_rel, t_rel, t_name in hops:
        print(f"    {participant(f_rel)}->>+{participant(t_rel)}: {t_name}(...)")
        print(f"    {participant(t_rel)}-->>-{participant(f_rel)}: ")
    print(f"    {participant(rel)}-->>-User: result")
    print("```")
    print("\nRefinement checklist: prune internal noise; rename 'User' to the "
          "real actor; put MEANING on each arrow (not function names); add the "
          "failure path with `alt`; collapse chatty pairs.")

if __name__ == "__main__":
    main()
