#!/usr/bin/env python3
"""map_repo.py — Phase 0 of repo-docs-init (deterministic, no LLM).

Walks a repository, classifies source files by language, groups them into
modules (directories), extracts public symbols, and builds an import-based
dependency graph. Output: repo-map.json consumed by scaffold_docs.py and
build_index.py.

Usage:
    python map_repo.py --repo /path/to/repo [--config /path/to/.docsgen.yaml]
                       [--out /path/to/repo/docs/repo-map.json]

Stdlib-only by design (ast for Python, regex heuristics for other languages)
so it runs anywhere without installs. Graph quality is best for Python and
good-enough for JS/TS/C#/Java/Go — a weaker graph degrades the "How It
Connects" prose, never the pipeline.
"""
import argparse
import ast
import fnmatch
import json
import re
import sys
from pathlib import Path, PurePosixPath

# ---------------------------------------------------------------- config ---

DEFAULT_CONFIG = {
    "src_roots": ["src", "lib", "app", "."],
    "ignore": [
        ".git/*", "docs/*", "node_modules/*", "dist/*", "build/*", "out/*",
        "bin/*", "obj/*", "target/*", "venv/*", ".venv/*", "__pycache__/*",
        "*.min.js", "*.generated.*", "*.g.cs", "*.pb.go", "*_pb2.py",
        "tests/*", "test/*", "*/tests/*", "*/test/*", "*.spec.*", "*.test.*",
        "*_test.go", "test_*.py", "*_test.py", "vendor/*", ".*/*",
    ],
    "module_depth": 2,          # dirs at this depth under src_root become modules
    "min_module_files": 1,
    "site_base_url": "https://REPLACE-ME.example.com/docs",
}

LANG_BY_EXT = {
    ".py": "python", ".js": "javascript", ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "typescript", ".cs": "csharp",
    ".java": "java", ".go": "go", ".rb": "ruby", ".rs": "rust",
    ".php": "php", ".kt": "kotlin", ".scala": "scala", ".sql": "sql",
    ".sh": "shell", ".ps1": "powershell", ".c": "c", ".h": "c",
    ".cpp": "cpp", ".hpp": "cpp",
}

def load_config(path: Path | None) -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if path and path.exists():
        cfg.update(_parse_simple_yaml(path.read_text(encoding="utf-8")))
    return cfg

def _parse_simple_yaml(text: str) -> dict:
    """Minimal YAML subset parser (scalars + flat string lists) so the skill
    has zero dependencies. Uses PyYAML instead when available."""
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except ImportError:
        pass
    out: dict = {}
    key = None
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        if line.startswith("  - ") and key:
            out.setdefault(key, []).append(line.strip()[2:].strip().strip("'\""))
        elif ":" in line and not line.startswith(" "):
            key, _, val = line.partition(":")
            key, val = key.strip(), val.strip().strip("'\"")
            if val:
                out[key] = int(val) if val.isdigit() else val
                key = None
            else:
                out[key] = []
    return out

# ----------------------------------------------------------------- walk ----

def is_ignored(rel: str, patterns: list[str]) -> bool:
    p = PurePosixPath(rel)
    for pat in patterns:
        if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(p.name, pat):
            return True
        # directory-prefix patterns like "tests/*" should match nested paths
        if pat.endswith("/*") and (rel + "/").startswith(pat[:-1]):
            return True
        if any(fnmatch.fnmatch(part, pat.rstrip("/*")) for part in p.parts[:-1] if pat.endswith("/*")):
            return True
    return False

def find_source_files(repo: Path, cfg: dict) -> list[str]:
    files = []
    for f in sorted(repo.rglob("*")):
        if not f.is_file() or f.suffix.lower() not in LANG_BY_EXT:
            continue
        rel = f.relative_to(repo).as_posix()
        if is_ignored(rel, cfg["ignore"]):
            continue
        files.append(rel)
    return files

def pick_src_root(files: list[str], cfg: dict) -> str:
    for root in cfg["src_roots"]:
        if root == ".":
            return "."
        if any(f.startswith(root.rstrip("/") + "/") for f in files):
            return root.rstrip("/")
    return "."

def module_key(rel: str, src_root: str, depth: int) -> str:
    p = PurePosixPath(rel)
    parts = p.parts
    if src_root != "." and parts and parts[0] == src_root:
        parts = parts[1:]
    dir_parts = parts[:-1]
    if not dir_parts:
        return "_root"
    return "/".join(dir_parts[:depth])

# -------------------------------------------------------------- symbols ----

def python_symbols_and_imports(path: Path) -> tuple[list[str], list[str]]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        return [], []
    syms, imps = [], []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if not node.name.startswith("_"):
                syms.append(node.name)
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imps += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            imps.append("." * node.level + node.module)
    return syms, imps

GENERIC_PATTERNS = {
    "javascript": (
        re.compile(r"export\s+(?:default\s+)?(?:async\s+)?(?:function|class|const|let|var)\s+([A-Za-z_$][\w$]*)"),
        re.compile(r"""(?:import\s.*?from\s+|require\()\s*['"]([^'"]+)['"]"""),
    ),
    "typescript": (
        re.compile(r"export\s+(?:default\s+)?(?:async\s+)?(?:function|class|const|let|interface|type|enum)\s+([A-Za-z_$][\w$]*)"),
        re.compile(r"""(?:import\s.*?from\s+|require\()\s*['"]([^'"]+)['"]"""),
    ),
    "csharp": (
        re.compile(r"public\s+(?:static\s+|sealed\s+|abstract\s+|partial\s+)*(?:class|interface|struct|enum|record)\s+(\w+)"),
        re.compile(r"^\s*using\s+([\w.]+)\s*;", re.M),
    ),
    "java": (
        re.compile(r"public\s+(?:final\s+|abstract\s+)*(?:class|interface|enum|record)\s+(\w+)"),
        re.compile(r"^\s*import\s+([\w.]+)\s*;", re.M),
    ),
    "go": (
        re.compile(r"^func\s+(?:\([^)]+\)\s+)?([A-Z]\w*)|^type\s+([A-Z]\w*)", re.M),
        re.compile(r"""^\s*(?:import\s+)?['"]([\w./-]+)['"]""", re.M),
    ),
}

def generic_symbols_and_imports(path: Path, lang: str) -> tuple[list[str], list[str]]:
    pats = GENERIC_PATTERNS.get(lang)
    if not pats:
        return [], []
    text = path.read_text(encoding="utf-8", errors="replace")
    sym_pat, imp_pat = pats
    syms = [next(g for g in m.groups() if g) for m in sym_pat.finditer(text)]
    imps = imp_pat.findall(text)
    return list(dict.fromkeys(syms)), list(dict.fromkeys(imps))

# ---------------------------------------------------------------- graph ----

def resolve_deps(modules: dict, file_imports: dict, src_root: str, repo_name: str) -> None:
    """Best-effort: an import points at module M if any path-ish or dotted
    form of the import string matches M's key or a file inside M."""
    lookup = {}  # normalized hint -> module key
    for mkey, m in modules.items():
        lookup[mkey.lower()] = mkey
        lookup[mkey.replace("/", ".").lower()] = mkey
        for f in m["source_files"]:
            stem = PurePosixPath(f).stem.lower()
            lookup.setdefault(stem, mkey)
            dotted = PurePosixPath(f).with_suffix("").as_posix()
            if src_root != "." and dotted.startswith(src_root + "/"):
                dotted = dotted[len(src_root) + 1:]
            lookup[dotted.replace("/", ".").lower()] = mkey
            lookup[dotted.lower()] = mkey

    for mkey, m in modules.items():
        deps = set()
        for f in m["source_files"]:
            for imp in file_imports.get(f, []):
                norm = imp.lstrip("./").replace("../", "").lower().rstrip("/")
                for cand in (norm, norm.replace("/", "."), norm.split(".")[0], norm.split("/")[0]):
                    hit = lookup.get(cand)
                    if hit and hit != mkey:
                        deps.add(hit)
                        break
        m["depends_on"] = sorted(deps)

    for mkey, m in modules.items():
        m["depended_on_by"] = sorted(
            k for k, other in modules.items() if mkey in other["depends_on"]
        )

# ----------------------------------------------------------------- main ----

def build_map(repo: Path, cfg: dict) -> dict:
    files = find_source_files(repo, cfg)
    if not files:
        sys.exit("ERROR: no source files found — check src_roots/ignore in config.")
    src_root = pick_src_root(files, cfg)

    modules: dict[str, dict] = {}
    file_meta: dict[str, dict] = {}
    file_imports: dict[str, list[str]] = {}

    for rel in files:
        lang = LANG_BY_EXT[Path(rel).suffix.lower()]
        mkey = module_key(rel, src_root, int(cfg["module_depth"]))
        path = repo / rel
        if lang == "python":
            syms, imps = python_symbols_and_imports(path)
        else:
            syms, imps = generic_symbols_and_imports(path, lang)
        file_meta[rel] = {"language": lang, "public_symbols": syms,
                          "loc": sum(1 for _ in path.open(encoding="utf-8", errors="replace"))}
        file_imports[rel] = imps
        m = modules.setdefault(mkey, {"source_files": [], "languages": set()})
        m["source_files"].append(rel)
        m["languages"].add(lang)

    modules = {k: v for k, v in modules.items()
               if len(v["source_files"]) >= int(cfg["min_module_files"])}
    for m in modules.values():
        m["languages"] = sorted(m["languages"])
        m["public_api"] = sorted({s for f in m["source_files"]
                                  for s in file_meta[f]["public_symbols"]})[:40]

    resolve_deps(modules, file_imports, src_root, repo.name)

    # suggested bottom-up writing order (Kahn's algorithm; cycles appended last)
    order, indeg = [], {k: len(v["depends_on"]) for k, v in modules.items()}
    queue = sorted(k for k, d in indeg.items() if d == 0)
    seen = set()
    while queue:
        k = queue.pop(0)
        order.append(k); seen.add(k)
        for other, m in modules.items():
            if k in m["depends_on"] and other not in seen:
                indeg[other] -= 1
                if indeg[other] == 0:
                    queue.append(other)
        queue.sort()
    order += sorted(set(modules) - seen)  # cyclic remainder

    return {
        "repo_name": repo.name,
        "src_root": src_root,
        "site_base_url": cfg.get("site_base_url", ""),
        "modules": modules,
        "files": file_meta,
        "suggested_writing_order": order,
    }

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--config", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    cfg_path = Path(args.config) if args.config else repo / ".docsgen.yaml"
    cfg = load_config(cfg_path if cfg_path.exists() else None)
    result = build_map(repo, cfg)

    out = Path(args.out) if args.out else repo / "docs" / "repo-map.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"Mapped {len(result['files'])} files into {len(result['modules'])} modules "
          f"(src_root='{result['src_root']}') -> {out}\n")
    print("Module summary (review before scaffolding):")
    for k in result["suggested_writing_order"]:
        m = result["modules"][k]
        deps = ", ".join(m["depends_on"]) or "-"
        print(f"  {k:<30} {len(m['source_files']):>3} files  deps: {deps}")
    print("\nSuggested writing order above is bottom-up (dependencies first).")

if __name__ == "__main__":
    main()
