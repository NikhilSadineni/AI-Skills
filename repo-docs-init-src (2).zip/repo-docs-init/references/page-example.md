# Example: a completed module page at the quality bar

Below is a finished `docs/modules/auth.md` for a fictional service. Notice
what it does — and, in the annotations after it, what it deliberately avoids.

---

```markdown
---
module: auth
source_files: [session.py, tokens.py, crypto.py]
source_paths: [src/auth/session.py, src/auth/tokens.py, src/auth/crypto.py]
public_api: [create_session, validate_token, revoke_session, rotate_keys]
depends_on: [storage, config]
depended_on_by: [api, admin]
last_synced_commit: a3f8c2d
last_synced_at: 2026-07-09
---

# auth

## Purpose

Owns the full lifecycle of user sessions: creation at login, validation on
every request, and revocation on logout or compromise. It is the only module
allowed to mint or invalidate credentials — `api` and `admin` consume its
functions but never touch session storage directly.

It deliberately does **not** handle identity (who the user is) or
authorization (what they may do). Identity comes from the upstream SSO
callback handled in `api`; authorization lives in each consuming service.
Keeping auth purely about session mechanics is what allows the 1-second
revocation guarantee below.

## Design & Invariants

Sessions are **opaque server-side tokens, not JWTs**. The product requirement
is that revoking a session takes effect in under one second; stateless JWTs
can't be recalled once issued, so every validation is a lookup against
`storage`. If you're tempted to "optimize" validation by caching decoded
tokens in the consumer, you will silently break revocation — this has been
attempted and reverted twice (see ADR-0007).

All cryptographic primitives are confined to `crypto.py`. Nothing else in the
repo imports `hashlib` or `cryptography` directly (enforced by lint rule
`no-direct-crypto`). This is what makes key rotation a one-file change.

Things a newcomer gets wrong on their first PR here: (1) `validate_token`
returns a `SessionContext`, not a boolean — callers that truthiness-check the
context accidentally treat an expired-but-present session as valid; (2) tests
must use `tokens.py::test_signer`, because the real signer requires the KMS
emulator; (3) session TTL is configured in `config`, not hardcoded — several
past PRs re-introduced a constant.

## How It Connects

Login flow: `api` receives the SSO callback → `auth/session.py::create_session`
persists via [storage](storage.md#redis_clientpy) → the opaque token returns
to the client as an HttpOnly cookie. Every subsequent request passes through
`api`'s middleware, which calls `validate_token`; `admin` additionally calls
`revoke_session` for the force-logout feature. Key rotation (`rotate_keys`)
is invoked only by the ops runbook, never by application code.

## session.py {#sessionpy}

The lifecycle orchestrator and the module's public face — external callers
should import from here only. `create_session` enforces the per-user
concurrent-session cap (appears to default to 5; the limit lives in
`config`, not here). `revoke_session` is idempotent by design so the
force-logout job can be retried blindly.

Key public symbols: `create_session`, `validate_token`, `revoke_session`

[View source](https://dev.azure.com/contoso/platform/_git/svc?path=/src/auth/session.py)

## tokens.py {#tokenspy}

Token encoding, signing, and expiry math. The token format is versioned
(first byte) so old tokens survive format changes for one release cycle —
if you change the format, bump the version and keep the previous decoder.
Includes `test_signer` for use in tests (no KMS required).

Key public symbols: `encode`, `decode`, `test_signer`

[View source](https://dev.azure.com/contoso/platform/_git/svc?path=/src/auth/tokens.py)

## crypto.py {#cryptopy}

The single chokepoint for cryptographic primitives (see invariant above).
Wraps the KMS client; nothing here is user-facing. `rotate_keys` performs
dual-write during rotation so in-flight tokens signed with the old key stay
valid for one TTL window.

Key public symbols: `sign`, `verify`, `rotate_keys`

[View source](https://dev.azure.com/contoso/platform/_git/svc?path=/src/auth/crypto.py)
```

---

## Why this page passes the bar

- **Every paragraph fails the "10 seconds of code reading" test in the right
  direction** — revocation latency, the reverted caching attempts, the lint
  rule, the versioned token byte: none of it is recoverable from signatures.
- **Boundaries are explicit.** "Does not handle identity or authorization"
  prevents the most likely misuse.
- **Calibrated confidence.** "appears to default to 5" marks an inference;
  verified facts are stated plainly.
- **References are durable.** `path::symbol` and anchors, no line numbers.
- **It is short.** ~550 words of prose. A page twice this length is usually
  restating code.

## Anti-patterns (never write these)

> `create_session(user_id: str, ttl: int) -> Session` — creates a session
> for the given user id with the given ttl and returns a Session object.

Restates the signature. Zero information.

> This module uses Redis for high performance and scalability, following
> industry best practices.

Marketing filler with no verifiable content.

> The validate function on line 42 checks the token.

Line number (rots) + mechanics (visible in code).
