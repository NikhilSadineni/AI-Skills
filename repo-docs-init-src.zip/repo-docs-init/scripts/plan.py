#!/usr/bin/env python3
"""plan.py — resumable work plan for repo-docs-init (deterministic).

Large codebases can't be documented in one session. This script maintains
docs/_PLAN.md: an ordered task list where a task can only be marked done by
passing per-page validation. The plan file — not any session's memory — is
the source of truth, so a fresh session can resume exactly where the last
one stopped.

Subcommands:
    init      Create docs/_PLAN.md from repo-map.json (refuses if it exists;
              use refresh to update an existing plan).
    status    Show progress counts and the next few pending tasks.
    next      Print the single next pending task with work instructions.
    complete  Validate one task's page; mark done only if validation passes.
    refresh   Re-sync plan with reality: reopen done tasks whose pages have
              new TODO/STALE markers (code drifted), append tasks for new
              modules, without touching other statuses.

Usage:
    python plan.py init     --repo <path>
    python plan.py status   --repo <path>
    python plan.py next     --repo <path>
    python plan.py complete --repo <path> --task M03
    python plan.py refresh  --repo <path>
"""
import argparse
import json
import re
import subprocess
import sys
from datetime import date
from pathlib import Path

PLAN_REL = "docs/_PLAN.md"
TASK_RE = re.compile(r"^- \[(?P<st>[ x])\] `(?P<id>[A-Z]\d*|[A-Z])` "
                     r"(?P<page>\S+) — (?P<desc>.*?)(?: — done (?P<meta>.*))?$")

HEADER = """# Documentation Plan — {repo}

generated_from_commit: {commit}
updated: {today}

## How to resume in a fresh session

This file is the source of truth for documentation progress — trust it over
any session memory. To continue:

1. Run `python <skill>/scripts/plan.py status --repo <repo_root>` to see
   what's done and what's next. Do NOT re-run map/scaffold unless `refresh`
   or `status` tells you the code has drifted.
2. Take the next pending task (`plan.py next`), do the work per SKILL.md
   (write prose into the TODO markers of that page only).
3. Mark it done with `plan.py complete --task <ID>` — this validates the
   page and refuses if TODO/STALE markers remain, so a checked box is a
   verified fact, not a claim.
4. Repeat until the session budget runs out. The final task `V` runs the
   full build_index validation and must be completed last.

If the code changed since this plan was generated, run map_repo.py and
scaffold_docs.py again (non-destructive), then `plan.py refresh`.

## Tasks

Statuses: `[ ]` pending · `[x]` done (validated). Work top to bottom —
module order is bottom-up by dependency; synthesis pages come after all
modules because they are written FROM the module pages.

"""

# ------------------------------------------------------------- plan I/O ----

def git_head(repo: Path) -> str:
    try:
        return subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                              cwd=repo, capture_output=True, text=True,
                              check=True).stdout.strip()
    except Exception:
        return "UNSTAMPED"

def load_map(repo: Path) -> dict:
    p = repo / "docs" / "repo-map.json"
    if not p.exists():
        sys.exit("ERROR: docs/repo-map.json not found — run map_repo.py first.")
    return json.loads(p.read_text(encoding="utf-8"))

def module_page(mkey: str) -> str:
    return ("reference/modules/_root.md" if mkey == "_root"
            else f"reference/modules/{mkey}.md")

def build_tasks(rmap: dict) -> list[dict]:
    tasks = []
    for i, mkey in enumerate(rmap["suggested_writing_order"], 1):
        n = len(rmap["modules"][mkey]["source_files"])
        tasks.append({"id": f"M{i:02d}", "page": module_page(mkey),
                      "desc": f"write prose for module `{mkey}` ({n} file section(s))",
                      "module": mkey, "done": False, "meta": ""})
    tasks += [
        {"id": "F", "page": "reference/functionality.md",
         "desc": "capability catalog — every capability: what/why/entry points/modules (write from module pages)",
         "module": None, "done": False, "meta": ""},
        {"id": "O", "page": "explanation/overview.md",
         "desc": "system overview — components, key flows, reading order (write from module pages)",
         "module": None, "done": False, "meta": ""},
        {"id": "A", "page": "explanation/architecture.md",
         "desc": "cross-cutting decisions; verify/prune Mermaid graph",
         "module": None, "done": False, "meta": ""},
        {"id": "G", "page": "reference/glossary.md",
         "desc": "domain terms explained more than once while writing",
         "module": None, "done": False, "meta": ""},
        {"id": "V", "page": "(all)",
         "desc": "final gate: build_index.py exits clean (index + llms.txt + provenance)",
         "module": None, "done": False, "meta": ""},
    ]
    return tasks

def write_plan(repo: Path, rmap: dict, tasks: list[dict], commit: str) -> None:
    lines = [HEADER.format(repo=rmap["repo_name"], commit=commit,
                           today=date.today().isoformat()).rstrip(), ""]
    for t in tasks:
        box = "x" if t["done"] else " "
        meta = f" — done {t['meta']}" if t["done"] and t["meta"] else ""
        lines.append(f"- [{box}] `{t['id']}` {t['page']} — {t['desc']}{meta}")
    (repo / PLAN_REL).write_text("\n".join(lines) + "\n", encoding="utf-8")

def read_plan(repo: Path) -> tuple[str, list[dict]]:
    p = repo / PLAN_REL
    if not p.exists():
        sys.exit(f"ERROR: {PLAN_REL} not found — run `plan.py init` first.")
    text = p.read_text(encoding="utf-8")
    tasks = []
    for line in text.splitlines():
        m = TASK_RE.match(line)
        if m:
            tasks.append({"id": m["id"], "page": m["page"], "desc": m["desc"],
                          "done": m["st"] == "x", "meta": m["meta"] or "",
                          "module": None})
    if not tasks:
        sys.exit(f"ERROR: no parseable tasks in {PLAN_REL}.")
    return text, tasks

# ------------------------------------------------------------ validation ---

def slug(filename: str) -> str:
    return re.sub(r"[^a-z0-9_]", "", Path(filename).name.lower())

def validate_task(repo: Path, task: dict, rmap: dict) -> list[str]:
    """Per-page validation. Empty list = pass."""
    errs = []
    if task["id"] == "V":
        script = Path(__file__).parent / "build_index.py"
        r = subprocess.run([sys.executable, str(script), "--repo", str(repo)],
                           capture_output=True, text=True)
        if r.returncode != 0:
            errs.append("build_index.py failed:\n" + r.stdout.strip())
        return errs

    page = repo / "docs" / task["page"]
    if not page.exists():
        return [f"page docs/{task['page']} does not exist"]
    text = page.read_text(encoding="utf-8")
    for marker in ("TODO:PROSE", "STALE:REMOVED"):
        n = text.count(marker)
        if n:
            errs.append(f"{n} {marker} marker(s) remain in docs/{task['page']}")
    if "REPO_URL_PLACEHOLDER" in text:
        errs.append("source back-links are placeholders (re-run scaffold with --repo-url)")

    # module tasks: every source file must have its anchored section
    mkey = next((k for k in rmap["modules"] if module_page(k) == task["page"]), None)
    if mkey:
        for rel in rmap["modules"][mkey]["source_files"]:
            a = slug(rel)
            if f"{{#{a}}}" not in text and f"({a})=" not in text:
                errs.append(f"missing section for {rel}")
    return errs

# ------------------------------------------------------------ commands -----

def cmd_init(repo: Path) -> None:
    if (repo / PLAN_REL).exists():
        sys.exit(f"ERROR: {PLAN_REL} already exists — use `refresh`, or delete it to restart.")
    rmap = load_map(repo)
    write_plan(repo, rmap, build_tasks(rmap), git_head(repo))
    print(f"Plan created: {PLAN_REL} "
          f"({len(rmap['modules'])} module tasks + 5 synthesis/validation tasks)")

def cmd_status(repo: Path) -> None:
    _, tasks = read_plan(repo)
    done = [t for t in tasks if t["done"]]
    pending = [t for t in tasks if not t["done"]]
    print(f"Progress: {len(done)}/{len(tasks)} tasks done "
          f"({100 * len(done) // len(tasks)}%)")
    rmap_p = repo / "docs" / "repo-map.json"
    if rmap_p.exists():
        plan_commit = re.search(r"generated_from_commit: (\S+)",
                                (repo / PLAN_REL).read_text(encoding="utf-8"))
        head = git_head(repo)
        if plan_commit and plan_commit.group(1) not in ("UNSTAMPED", head):
            print(f"NOTE: repo HEAD ({head}) differs from plan commit "
                  f"({plan_commit.group(1)}). If source code changed, re-run "
                  "map_repo.py + scaffold_docs.py, then `plan.py refresh`.")
    if pending:
        print("\nNext tasks:")
        for t in pending[:5]:
            print(f"  [{t['id']}] {t['page']} — {t['desc']}")
    else:
        print("All tasks complete. Documentation is done and validated.")

def cmd_next(repo: Path) -> None:
    _, tasks = read_plan(repo)
    t = next((t for t in tasks if not t["done"]), None)
    if not t:
        print("All tasks complete.")
        return
    print(f"NEXT TASK [{t['id']}]: {t['desc']}")
    if t["id"] == "V":
        print("Run: python scripts/build_index.py --repo . ; fix errors; then "
              f"plan.py complete --task V")
    else:
        print(f"1. Open docs/{t['page']} and read the source files it covers.\n"
              f"2. Replace every TODO:PROSE marker per SKILL.md's editorial standard\n"
              f"   (and resolve any STALE:REMOVED markers).\n"
              f"3. Run: plan.py complete --task {t['id']}")

def cmd_complete(repo: Path, task_id: str) -> None:
    text, tasks = read_plan(repo)
    t = next((t for t in tasks if t["id"] == task_id), None)
    if not t:
        sys.exit(f"ERROR: no task `{task_id}` in plan.")
    if t["done"]:
        print(f"Task {task_id} is already done.")
        return
    rmap = load_map(repo)
    errs = validate_task(repo, t, rmap)
    if errs:
        print(f"VALIDATION FAILED for [{task_id}] — task stays pending:")
        for e in errs:
            print(f"  - {e}")
        sys.exit(1)
    stamp = f"{date.today().isoformat()} @{git_head(repo)}"
    new_line_old = f"- [ ] `{t['id']}` {t['page']} — {t['desc']}"
    new_line_new = f"- [x] `{t['id']}` {t['page']} — {t['desc']} — done {stamp}"
    text = text.replace(new_line_old, new_line_new, 1)
    text = re.sub(r"^updated: .*$", f"updated: {date.today().isoformat()}",
                  text, count=1, flags=re.M)
    (repo / PLAN_REL).write_text(text, encoding="utf-8")
    remaining = sum(1 for x in tasks if not x["done"]) - 1
    print(f"[{task_id}] validated and marked done. {remaining} task(s) remaining.")

def cmd_refresh(repo: Path) -> None:
    text, tasks = read_plan(repo)
    rmap = load_map(repo)
    reopened, appended = [], []

    # reopen done tasks whose page regressed (new TODO/STALE after code drift)
    for t in tasks:
        if t["done"] and t["id"] != "V":
            if validate_task(repo, t, rmap):
                old = f"- [x] `{t['id']}` {t['page']} — {t['desc']}" + \
                      (f" — done {t['meta']}" if t["meta"] else "")
                new = f"- [ ] `{t['id']}` {t['page']} — {t['desc']} (reopened: page has new markers)"
                if old in text:
                    text = text.replace(old, new, 1)
                    reopened.append(t["id"])
    # if anything reopened, V must reopen too
    if reopened:
        text = re.sub(r"^- \[x\] `V` (.*?)( — done .*)?$", r"- [ ] `V` \1",
                      text, count=1, flags=re.M)

    # append tasks for modules not in the plan
    known_pages = {t["page"] for t in tasks}
    max_m = max((int(t["id"][1:]) for t in tasks if re.fullmatch(r"M\d+", t["id"])),
                default=0)
    new_lines = []
    for mkey in rmap["suggested_writing_order"]:
        pg = module_page(mkey)
        if pg not in known_pages:
            max_m += 1
            n = len(rmap["modules"][mkey]["source_files"])
            new_lines.append(f"- [ ] `M{max_m:02d}` {pg} — write prose for "
                             f"module `{mkey}` ({n} file section(s)) (added by refresh)")
            appended.append(f"M{max_m:02d}")
    if new_lines:
        # insert before the F task line to keep synthesis pages last
        text = re.sub(r"^(- \[.\] `F` )", "\n".join(new_lines) + "\n\\1",
                      text, count=1, flags=re.M)
        # a new module almost certainly means new capabilities: reopen F
        text = re.sub(r"^- \[x\] `F` (.*?)( — done .*)?$",
                      r"- [ ] `F` \1 (reopened: new module(s) added)",
                      text, count=1, flags=re.M)
        # and the final gate must re-run
        text = re.sub(r"^- \[x\] `V` (.*?)( — done .*)?$", r"- [ ] `V` \1",
                      text, count=1, flags=re.M)

    text = re.sub(r"^updated: .*$", f"updated: {date.today().isoformat()}",
                  text, count=1, flags=re.M)
    text = re.sub(r"^generated_from_commit: .*$",
                  f"generated_from_commit: {git_head(repo)}",
                  text, count=1, flags=re.M)
    (repo / PLAN_REL).write_text(text, encoding="utf-8")
    print(f"Refresh: reopened {reopened or 'none'}, appended {appended or 'none'}.")

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["init", "status", "next", "complete", "refresh"])
    ap.add_argument("--repo", required=True)
    ap.add_argument("--task", default=None)
    args = ap.parse_args()
    repo = Path(args.repo).resolve()
    if args.cmd == "init":
        cmd_init(repo)
    elif args.cmd == "status":
        cmd_status(repo)
    elif args.cmd == "next":
        cmd_next(repo)
    elif args.cmd == "complete":
        if not args.task:
            sys.exit("ERROR: complete requires --task <ID>")
        cmd_complete(repo, args.task)
    elif args.cmd == "refresh":
        cmd_refresh(repo)

if __name__ == "__main__":
    main()
