#!/usr/bin/env python3
"""scaffold_docs.py — Phase 1 scaffolding for repo-docs-init (deterministic).

Creates the docs/ tree from repo-map.json. Layout (Sphinx + Diátaxis):

  reference/modules/<module>/index.md   module overview: functionality it
                                        provides + brief per-file overview
                                        table linking to the file pages
  reference/modules/<module>/<slug>.md  ONE PAGE PER SOURCE FILE (the unit
                                        of documentation)
  reference/api/<module>.md             autodoc stubs (Python, generated)
  reference/functionality.md, glossary.md
  explanation/overview.md, architecture.md, repo-map.md, functionality-map.md
  conf.py, index.md, section index.md toctrees

Prose locations carry <!-- TODO:PROSE hint --> markers for the agent.
Non-destructive on re-run: existing prose is never touched; new source files
get new file pages + overview rows; file pages whose source vanished get a
STALE:REMOVED banner. Machine-owned blocks (toctrees, Files table structure)
are regenerated.

Usage:
    python scaffold_docs.py --repo /path/to/repo [--map docs/repo-map.json]
                            [--repo-url https://dev.azure.com/org/proj/_git/repo]
"""
import argparse
import json
import re
from datetime import date
from pathlib import Path

TODO = "<!-- TODO:PROSE {hint} -->"
STALE_BANNER = ("<!-- STALE:REMOVED source file no longer exists; delete this "
                "page (and its row in the module index) or fold content into "
                "another page -->")

def slug(filename: str) -> str:
    """Stable page name for a file: 'session.py' -> 'sessionpy'."""
    return re.sub(r"[^a-z0-9_]", "", Path(filename).name.lower())

def module_dir(mkey: str) -> str:
    return "reference/modules/_root" if mkey == "_root" else f"reference/modules/{mkey}"

def page_path(mkey: str) -> str:
    return f"{module_dir(mkey)}/index.md"

def file_page_path(mkey: str, rel: str) -> str:
    return f"{module_dir(mkey)}/{slug(rel)}.md"

def api_page_path(mkey: str) -> str:
    return ("reference/api/_root.md" if mkey == "_root"
            else f"reference/api/{mkey}.md")

def source_url(base: str, rel: str) -> str:
    if "_git" in base:  # ADO web UI style
        return f"{base}?path=/{rel}"
    return f"{base}/{rel}"

# ------------------------------------------------------------ file pages ---

def file_page(rel: str, mkey: str, meta: dict, repo_url: str, today: str) -> str:
    name = Path(rel).name
    anchor = slug(name)
    syms = meta.get("public_symbols", [])
    fm = [
        "---",
        f"file: {name}",
        f"module: {mkey}",
        f"source_path: {rel}",
        f"public_symbols: [{', '.join(syms[:15])}]",
        f"internal_deps: [{', '.join(meta.get('internal_deps', []))}]",
        f"used_by: [{', '.join(meta.get('used_by', []))}]",
        "last_synced_commit: UNSTAMPED",
        f"last_synced_at: {today}",
        "---",
    ]
    if syms:
        rows = "\n".join(
            f"| `{s}` | {TODO.format(hint='one line, why-level: the job it does and when a caller reaches for it')} |"
            for s in syms[:10])
        overflow = ("\nAdditional symbols: "
                    + ", ".join(f"`{s}`" for s in syms[10:]) + "\n") if len(syms) > 10 else ""
        symbol_block = ("## What it provides\n\n"
                        "| Symbol | What it does & why it matters |\n|---|---|\n"
                        f"{rows}\n{overflow}")
    else:
        symbol_block = "## What it provides\n\nKey public symbols: (none detected)\n"

    deps = ", ".join(f"`{d}`" for d in meta.get("internal_deps", [])) or "(none within repo)"
    used = ", ".join(f"`{u}`" for u in meta.get("used_by", [])) or "(none within repo)"
    body = [
        f"({anchor})=",
        f"# {name}",
        "",
        TODO.format(hint=f"2-5 sentences: what {name} contributes to the `{mkey}` "
                         "module and why it exists as a separate file. Do NOT "
                         "restate signatures."),
        "",
        symbol_block,
        "## Behavior notes",
        "",
        TODO.format(hint="side effects, failure modes, state/concurrency assumptions, "
                         "and performance characteristics worth knowing. Write "
                         "'None notable.' only if you verified that."),
        "",
        f"Internal dependencies: {deps}",
        f"Used by: {used}",
        f"Size: {meta.get('loc', '?')} lines ({meta.get('language', '?')})",
        "",
        f"[View source]({source_url(repo_url, rel)}) · [Module overview](index.md)",
        "",
    ]
    return "\n".join(fm) + "\n\n" + "\n".join(body)

# --------------------------------------------------------- module index ----

FILES_TABLE_HEADER = "| File | Overview |\n|---|---|"

def files_table_rows(m: dict) -> list[str]:
    return [f"| [{Path(rel).name}]({slug(rel)}.md) | "
            f"{TODO.format(hint='one line: what this file is for')} |"
            for rel in m["source_files"]]

def toctree_block(m: dict) -> str:
    entries = "\n".join(slug(rel) for rel in m["source_files"])
    return f"```{{toctree}}\n:hidden:\n\n{entries}\n```"

def module_index(mkey: str, m: dict, today: str) -> str:
    fm = [
        "---",
        f"module: {mkey}",
        f"source_files: [{', '.join(Path(f).name for f in m['source_files'])}]",
        f"source_paths: [{', '.join(m['source_files'])}]",
        f"public_api: [{', '.join(m['public_api'][:15])}]",
        f"depends_on: [{', '.join(m['depends_on'])}]",
        f"depended_on_by: [{', '.join(m['depended_on_by'])}]",
        "last_synced_commit: UNSTAMPED",
        f"last_synced_at: {today}",
        "---",
    ]
    body = [
        f"# {mkey}",
        "",
        "## Purpose",
        "",
        TODO.format(hint="2-3 paragraphs: why this module exists, what responsibility it owns, and what it deliberately does NOT handle."),
        "",
        "## Functionality provided",
        "",
        TODO.format(hint="The capabilities this module contributes, consumer's perspective, "
                         "with entry points in path::symbol form. Link the relevant "
                         "sections of ../../functionality.md rather than duplicating them."),
        "",
        "## Design & Invariants",
        "",
        TODO.format(hint="The decisions and constraints NOT visible in the code: invariants, why odd-looking choices were forced, the 2-3 things a newcomer would get wrong."),
        "",
        "## How It Connects",
        "",
        TODO.format(hint=f"Callers, callees, data flows. depends_on: [{', '.join(m['depends_on']) or 'none'}]; depended_on_by: [{', '.join(m['depended_on_by']) or 'none'}]. Link other module indexes with relative links, e.g. ../storage/index.md"),
        "",
        "## Files",
        "",
        FILES_TABLE_HEADER,
        *files_table_rows(m),
        "",
        toctree_block(m),
        "",
    ]
    return "\n".join(fm) + "\n\n" + "\n".join(body)

# ----------------------------------------------------------- upsert logic --

def upsert_file_pages(docs: Path, mkey: str, m: dict, files: dict,
                      repo_url: str, today: str, actions: dict) -> None:
    mdir = docs / module_dir(mkey)
    mdir.mkdir(parents=True, exist_ok=True)
    current_slugs = set()
    for rel in m["source_files"]:
        current_slugs.add(slug(rel))
        p = docs / file_page_path(mkey, rel)
        if not p.exists():
            p.write_text(file_page(rel, mkey, files.get(rel, {}), repo_url, today),
                         encoding="utf-8")
            actions[file_page_path(mkey, rel)] = "created"
    # stale: file pages whose source vanished
    for p in mdir.glob("*.md"):
        if p.name == "index.md" or p.stem in current_slugs:
            continue
        text = p.read_text(encoding="utf-8")
        if "STALE:REMOVED" not in text:
            p.write_text(STALE_BANNER + "\n" + text, encoding="utf-8")
            actions[f"{module_dir(mkey)}/{p.name}"] = "stale-marked"

def upsert_module_index(docs: Path, mkey: str, m: dict, today: str,
                        actions: dict) -> None:
    p = docs / page_path(mkey)
    if not p.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(module_index(mkey, m, today), encoding="utf-8")
        actions[mkey] = "created"
        return
    text = p.read_text(encoding="utf-8")
    changed = False
    # append rows for files missing from the Files table (prose rows untouched)
    for rel in m["source_files"]:
        link = f"]({slug(rel)}.md)"
        if link not in text:
            row = (f"| [{Path(rel).name}]({slug(rel)}.md) | "
                   f"{TODO.format(hint='one line: what this file is for')} |")
            # insert after the last table row following the header
            if FILES_TABLE_HEADER in text:
                text = text.replace(FILES_TABLE_HEADER,
                                    FILES_TABLE_HEADER + "\n" + row, 1)
            else:
                text = text.rstrip() + "\n\n## Files\n\n" + FILES_TABLE_HEADER + "\n" + row + "\n"
            changed = True
    # regenerate the machine-owned toctree block
    new_toc = toctree_block(m)
    text2 = re.sub(r"```\{toctree\}.*?```", new_toc, text, count=1, flags=re.S)
    if text2 != text:
        text, changed = text2, True
    elif "```{toctree}" not in text:
        text = text.rstrip() + "\n\n" + new_toc + "\n"
        changed = True
    if changed:
        p.write_text(text, encoding="utf-8")
        actions[mkey] = "updated"
    else:
        actions.setdefault(mkey, "unchanged")

# --------------------------------------------------------------- graphs ----

def mermaid_graph(modules: dict) -> str:
    lines = ["```{mermaid}", "graph TD"]
    for k in modules:
        node = k.replace("/", "_").replace("-", "_") or "root"
        lines.append(f'    {node}["{k}"]')
    for k, m in modules.items():
        src = k.replace("/", "_").replace("-", "_") or "root"
        for d in m["depends_on"]:
            dst = d.replace("/", "_").replace("-", "_") or "root"
            lines.append(f"    {src} --> {dst}")
    lines.append("```")
    return "\n".join(lines)

# ------------------------------------------------------------- templates ---

CONF_PY_TMPL = '''# Sphinx configuration — generated by repo-docs-init; edit freely after review.
import os
import sys

sys.path.insert(0, os.path.abspath("../{src_root}"))  # for autodoc imports

project = "{repo}"
extensions = [
    "myst_parser",
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",       # Google/NumPy docstring styles
    "sphinx.ext.viewcode",
    "sphinxcontrib.mermaid",     # pip install sphinxcontrib-mermaid
]
myst_enable_extensions = ["colon_fence", "deflist", "attrs_block", "attrs_inline"]
myst_heading_anchors = 3         # auto anchors for h1-h3 alongside explicit targets

source_suffix = {{".md": "markdown"}}
exclude_patterns = ["_PLAN.md", "repo-map.json", "docs-index.json",
                    "llms.txt", "_build", "Thumbs.db", ".DS_Store"]
html_theme = "furo"              # pip install furo; falls back: use "alabaster"
autodoc_member_order = "bysource"
autodoc_default_options = {{"members": True, "undoc-members": True,
                            "show-inheritance": True}}
'''

ROOT_INDEX_TMPL = """# {repo} documentation

Documentation follows a two-part [Diátaxis](https://diataxis.fr) structure:
**Reference** (facts — mirrors the code) and **Explanation** (understanding —
the why). Machine consumers start at `llms.txt` / `docs-index.json`.

```{{toctree}}
:maxdepth: 2

reference/index
explanation/index
```
"""

REF_INDEX_TMPL = """# Reference

Factual, lookup-oriented documentation whose structure mirrors the code.
Each module has an overview page and one page per source file.

```{{toctree}}
:maxdepth: 2
:caption: Prose reference

functionality
glossary
{module_entries}
```
{api_toctree}"""

API_TOCTREE_TMPL = """
```{{toctree}}
:maxdepth: 1
:caption: API (autodoc)

{api_entries}
```
"""

EXPL_INDEX_TMPL = """# Explanation

Understanding-oriented documentation: what this system is, why it is shaped
this way, and the decisions behind it.

```{{toctree}}
:maxdepth: 2

overview
architecture
repo-map
functionality-map
```
"""

GRAPH_WRAPPER_TMPL = """# {title}

{blurb}

```{{eval-rst}}
.. raw:: html

   <iframe src="../_static/{html}" style="width:100%;height:80vh;border:1px solid #ccc;border-radius:6px;"
           title="{title}"></iframe>
```

Generated by `scripts/build_graphs.py` — re-run it after docs change; do not edit.
"""

def api_stub(mkey: str, m: dict, files: dict) -> str | None:
    py_mods = [files[f]["py_module"] for f in m["source_files"]
               if files.get(f, {}).get("py_module")]
    if not py_mods:
        return None
    blocks = "\n\n".join(
        "```{eval-rst}\n.. automodule:: " + mod +
        "\n   :members:\n   :undoc-members:\n```" for mod in sorted(py_mods))
    return (f"# {mkey} — API\n\n"
            f"Auto-extracted API for the [`{mkey}` module](../modules/{'_root' if mkey == '_root' else mkey}/index.md). "
            f"Prose context lives on the module and file pages; this page is "
            f"signatures and docstrings only.\n\n{blocks}\n")

FUNCTIONALITY_TMPL = """# {repo} — Functionality Catalog

{todo_intro}

<!-- Editorial contract for this page:
Document the system by WHAT IT PROVIDES, not how it is organized. A reader
(human or LLM) who finishes this page should know every job this codebase can
do, why each job exists, and where to enter the code to invoke or change it.
Write this page AFTER all module pages, synthesizing from them. One
subsection per distinct capability, using exactly this shape: -->

## Capabilities

{todo_capabilities}

<!-- Template for each capability (copy per capability):

### <Capability name, verb phrase, e.g. "Create and validate user sessions">

**What it does:** One or two sentences, consumer's perspective.

**Why it exists:** The problem or requirement that forced this capability
into existence. If the reason is not evident from code or history, say so.

**Entry points:** `path/file.py::symbol` (the functions/classes a consumer
or maintainer starts from — path::symbol form, never line numbers).

**Implemented in:** [module](modules/<module>/index.md) links, main ones first (relative to reference/).

**Flow:** a ```{{mermaid}} sequenceDiagram``` showing the capability end to end
(actor -> entry point -> internal calls -> externals). Draft it with
`scripts/call_trace.py --entry <path::symbol>`, then refine: prune noise,
name the actor, annotate what each hop MEANS, add the error path.

-->

## Capability → Module Map

| Capability | Primary modules | Entry point |
|---|---|---|
{todo_map_rows}
"""

OVERVIEW_TMPL = """# {repo} — Overview

{todo_purpose}

For the system described by *what it can do* rather than how it is
structured, see the [Functionality Catalog](../reference/functionality.md).

## Major Components

{todo_components}

| Module | Purpose (one line) |
|---|---|
{module_rows}

## Key Flows

{todo_flows}

## Where To Start Reading

{todo_start}
"""

ARCH_TMPL = """# {repo} — Architecture

{todo_decisions}

## Component Dependency Graph

{mermaid}

## Cross-Cutting Concerns

{todo_crosscut}
"""

# ----------------------------------------------------------------- main ----

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--map", default=None)
    ap.add_argument("--repo-url", default="", help="Base URL of the repo web UI for source back-links (e.g. https://dev.azure.com/org/proj/_git/repo)")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    map_path = Path(args.map) if args.map else repo / "docs" / "repo-map.json"
    rmap = json.loads(map_path.read_text(encoding="utf-8"))
    docs = repo / "docs"
    repo_url = args.repo_url or "REPO_URL_PLACEHOLDER"
    today = date.today().isoformat()

    actions: dict = {}
    for mkey, m in rmap["modules"].items():
        upsert_file_pages(docs, mkey, m, rmap["files"], repo_url, today, actions)
        upsert_module_index(docs, mkey, m, today, actions)

    rows = "\n".join(
        f"| [{k}](../{page_path(k)}) | {TODO.format(hint='one line')} |"
        for k in rmap["suggested_writing_order"])
    t = lambda hint: TODO.format(hint=hint)
    for name, content in [
        ("reference/functionality.md", FUNCTIONALITY_TMPL.format(
            repo=rmap["repo_name"],
            todo_intro=t("2-3 sentences: what this system provides to its consumers, written for someone who has never seen the code. Write AFTER module pages."),
            todo_capabilities=t("One ### subsection per distinct capability, following the commented template below. Cover ALL functionality the code provides — a capability absent here is invisible to readers."),
            todo_map_rows=t("| rows: one per capability | [module](modules/x/index.md) links | `path::symbol` |"))),
        ("explanation/overview.md", OVERVIEW_TMPL.format(
            repo=rmap["repo_name"],
            todo_purpose=t("3-5 sentences: what this system does and for whom. Write LAST, from the module pages."),
            todo_components=t("Prose naming the <=5 major parts and their relationships."),
            module_rows=rows,
            todo_flows=t("The 2-3 key data/control flows end to end, referencing module pages."),
            todo_start=t("Reading order for a newcomer."))),
        ("explanation/architecture.md", ARCH_TMPL.format(
            repo=rmap["repo_name"],
            todo_decisions=t("Cross-cutting decisions and their forcing constraints. Write LAST."),
            mermaid=mermaid_graph(rmap["modules"]),
            todo_crosscut=t("Auth, error handling, logging, config — patterns that span modules."))),
        ("reference/glossary.md", "# Glossary\n\n" + t("Domain terms you needed to explain more than once while writing module pages. | Term | Meaning | table.") + "\n"),
    ]:
        p = docs / name
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            p.write_text(content, encoding="utf-8")
            actions[name] = "created"
        else:
            actions.setdefault(name, "unchanged")

    # ---- Sphinx wiring: conf.py, toctree indexes, autodoc stubs -----------
    api_pages = []
    for mkey, m in rmap["modules"].items():
        stub = api_stub(mkey, m, rmap["files"])
        if stub:
            apath = docs / api_page_path(mkey)
            apath.parent.mkdir(parents=True, exist_ok=True)
            apath.write_text(stub, encoding="utf-8")  # regenerated: no prose inside
            api_pages.append(api_page_path(mkey))
    module_entries = "\n".join(
        f"modules/{'_root' if k == '_root' else k}/index"
        for k in rmap["suggested_writing_order"])
    api_toctree = ""
    if api_pages:
        api_entries = "\n".join(
            p.removeprefix("reference/").removesuffix(".md") for p in sorted(api_pages))
        api_toctree = API_TOCTREE_TMPL.format(api_entries=api_entries)
    for name, content, overwrite in [
        ("conf.py", CONF_PY_TMPL.format(repo=rmap["repo_name"],
                                        src_root=rmap["src_root"]), False),
        ("index.md", ROOT_INDEX_TMPL.format(repo=rmap["repo_name"]), False),
        ("reference/index.md", REF_INDEX_TMPL.format(
            module_entries=module_entries, api_toctree=api_toctree), True),
        ("explanation/index.md", EXPL_INDEX_TMPL, True),
        ("explanation/repo-map.md", GRAPH_WRAPPER_TMPL.format(
            title="Interactive Repository Map",
            blurb="Every module and file as an explorable dependency graph. "
                  "Click a node to open its documentation; use the search box "
                  "to filter; drag to rearrange.",
            html="repo-graph.html"), True),
        ("explanation/functionality-map.md", GRAPH_WRAPPER_TMPL.format(
            title="Interactive Functionality Map",
            blurb="Capabilities on the left, the modules implementing them on "
                  "the right. Click a module to open its documentation.",
            html="functionality-map.html"), True),
    ]:
        p = docs / name
        p.parent.mkdir(parents=True, exist_ok=True)
        if overwrite or not p.exists():
            p.write_text(content, encoding="utf-8")
            actions.setdefault(name, "created")
    if api_pages:
        actions[f"reference/api/ ({len(api_pages)} autodoc stub(s))"] = "created"

    created = sum(1 for a in actions.values() if a == "created")
    updated = sum(1 for a in actions.values() if a in ("updated", "stale-marked"))
    print(f"Scaffold complete: {created} created, {updated} updated/stale-marked, "
          f"{len(actions)-created-updated} unchanged, under {docs}")
    print("\nWrite prose in this order (bottom-up); each module task = its "
          "index.md + all its file pages:")
    for k in rmap["suggested_writing_order"]:
        n = len(rmap["modules"][k]["source_files"])
        print(f"  docs/{page_path(k)} (+ {n} file page(s))  [{actions.get(k)}]")
    print("Then functionality, overview, architecture last, from the module pages.")
    if repo_url == "REPO_URL_PLACEHOLDER":
        print("\nNOTE: pass --repo-url to fill real source back-links "
              "(placeholders were written; build_index.py will flag them).")

if __name__ == "__main__":
    main()
