---
name: repo-docs-init
description: Generate a complete /docs folder for a code repository — a single source of truth both humans and LLMs can read to understand the codebase without opening the code. Produces module pages with YAML frontmatter, a FUNCTIONALITY.md capability catalog, OVERVIEW.md, ARCHITECTURE.md, docs-index.json, and llms.txt, following a deterministic source-path-to-doc-page mapping. Maintains a validated progress plan (docs/_PLAN.md) so large repos span multiple sessions. Use whenever the user asks to document a repository, create initial/baseline documentation, generate a docs site source, onboard a repo into the living-documentation system, or says "document this repo", "create the docs", "generate documentation for this codebase" — even if they only describe wanting an explanation of the codebase saved into the repo. ALSO use when asked to CONTINUE or RESUME documentation ("continue from the plan", "pick up where we left off") or when the repo has a docs/_PLAN.md with pending tasks.
---

# repo-docs-init: Initial Repository Documentation Generator

Generate the initial `/docs` tree for a repository. The output is the single source of truth consumed by three downstream systems, so structure discipline matters as much as prose quality:

1. **Humans** read the pages as a website (ADO Wiki or MkDocs).
2. **LLM agents** navigate via `llms.txt` and `docs-index.json` instead of crawling code.
3. **The PR sync pipeline** uses frontmatter `source_files` and the index to map code diffs to doc edits deterministically. If the mapping rule or anchors are violated, the pipeline breaks silently.

## The one rule everything depends on

Every source file maps to a doc location by a pure function of its path:

```
<src_root>/<module_path>/<file>  →  docs/modules/<module_path>.md#<file-slug>
src/auth/session.py              →  docs/modules/auth.md#sessionpy
```

Docs are written at **module granularity** (one page per module directory), with one anchored `##` section per source file inside the page. Never invent doc locations outside this rule; the scripts compute them for you.

## Workflow

**FIRST, check for an existing plan.** If `docs/_PLAN.md` exists in the target repo, this is a resume, not a fresh start — jump directly to the **Working loop** below (do not re-run map/scaffold unless `plan.py status` reports commit drift). Trust the plan file over anything the user or you remember about prior progress: checked boxes were validated, unchecked ones were not.

Otherwise follow these steps in order. Steps 1, 2, 2.5 and the final gate are deterministic scripts — run them, don't reimplement them.

### Step 0 — Configure

Copy `scripts/config.yaml` to the target repo root as `.docsgen.yaml` if it doesn't already exist, then adjust it: source roots, ignore globs, module depth, and `site_base_url` (ask the user for the base URL if unknown; leave the placeholder if they don't have one yet). If `.docsgen.yaml` already exists in the repo, use it as-is — it's the repo owner's configuration.

### Step 1 — Map the repository (deterministic)

```bash
python scripts/map_repo.py --repo <repo_root> --config <repo_root>/.docsgen.yaml --out <repo_root>/docs/repo-map.json
```

This walks the tree (respecting ignore globs), classifies files by language, groups them into modules, extracts public symbols, and builds the import-dependency graph. Review the printed module summary before continuing. If the module grouping looks wrong (e.g., one giant module, or test folders included), fix `.docsgen.yaml` and re-run — do not hand-edit `repo-map.json`.

### Step 2 — Scaffold the docs tree (deterministic)

```bash
python scripts/scaffold_docs.py --repo <repo_root> --map <repo_root>/docs/repo-map.json
```

This creates `docs/modules/*.md` with correct frontmatter, headings, anchors, and source back-links already in place, plus stub `FUNCTIONALITY.md`, `OVERVIEW.md`, `ARCHITECTURE.md`, and `GLOSSARY.md`. Every place needing prose is marked `<!-- TODO:PROSE ... -->` with a hint. Never change frontmatter keys, heading anchors, or the file-section structure — only replace the TODO markers with prose.

### Step 2.5 — Create the work plan (deterministic)

```bash
python scripts/plan.py init --repo <repo_root>
```

This writes `docs/_PLAN.md`: an ordered task list (module pages bottom-up, then FUNCTIONALITY → OVERVIEW → ARCHITECTURE → GLOSSARY, then the final validation gate `V`). The plan is the **source of truth for progress across sessions** — codebases are usually too large to finish in one conversation, and this file is how a future session knows exactly where to continue. Commit it with the docs; it lives in the repo, not in anyone's memory.

### Working loop — write prose task by task

Repeat until the session's budget runs out or all tasks are done:

```bash
python scripts/plan.py next --repo <repo_root>      # what to work on
# ... do the writing work for that one page ...
python scripts/plan.py complete --repo <repo_root> --task <ID>
```

`complete` **validates the page** (no TODO/STALE markers, all file anchors present, no placeholder links) and refuses to check the box otherwise — never edit `_PLAN.md` checkboxes by hand, and never claim a task done without running `complete`. Work strictly in plan order: it's bottom-up by dependency, and the synthesis pages come after all modules because they are written *from* the module pages.

For each **module page task**:

1. Read the module's actual source files. Read enough to understand *why* the module exists, not just what it contains. Read the callers too (the `depended_on_by` list in frontmatter) — purpose is usually visible from the outside.
2. Replace each `<!-- TODO:PROSE -->` marker following the **editorial standard** below. File sections have three prose surfaces, each with its own job:
   - **The opening paragraph**: why this file exists as a separate file and what it contributes to the module.
   - **The symbol table**: one line per public symbol at *why*-level — the job it does and when a caller reaches for it. Never a signature restatement; "creates a session" is worthless, "mints the opaque token and enforces the per-user session cap" is the bar.
   - **Behavior notes**: side effects, failure modes, state/concurrency assumptions, performance characteristics worth knowing. Write "None notable." only if you verified that by reading the code — it is a claim, not a filler.
   The `Internal dependencies:`, `Used by:`, and `Size:` lines are machine-generated — leave them exactly as scaffolded.
3. Keep every anchor, heading, frontmatter line, and back-link exactly as scaffolded.

For repos too large to read exhaustively, prioritize: public API files first, largest files second, and skim the rest. Say so honestly in the page ("less-trafficked helpers in `util/` are documented at survey level").

For the **synthesis page tasks** (F, O, A, G), write **from the module pages you already wrote, not from raw code** — this keeps altitude consistent and the pages mutually coherent:

**`F` — FUNCTIONALITY.md first.** This page documents the system by *what it provides*, not how it is organized — the page a person or LLM reads to understand immediately why this codebase exists. One subsection per distinct capability following the commented template in the scaffold: what it does (consumer's perspective), why it exists (the requirement that forced it), entry points in `path::symbol` form, and links to implementing modules. Coverage matters here: enumerate capabilities by walking your module pages' Purpose sections and the `public_api` lists — **all functionality the code provides must appear**; a capability absent from this page is invisible to readers. Capabilities deliberately cross module boundaries ("process a payment" may span `api`, `billing`, and `storage`); that cross-cutting view is the point. Finish the Capability → Module map table.

**`O` — OVERVIEW.md**: what the system is, its five-or-fewer major parts, the two or three key data/control flows, where a newcomer starts reading. It links to FUNCTIONALITY.md for the capability view — don't duplicate the catalog here.

**`A` — ARCHITECTURE.md**: cross-cutting decisions and the Mermaid dependency diagram the scaffold generated (verify it renders; prune edges below the significance threshold if it's spaghetti). **`G`** — fill GLOSSARY.md with domain terms you found yourself needing to explain more than once.

### Final gate — task `V`

```bash
python scripts/build_index.py --repo <repo_root>
```

This emits `docs/docs-index.json` and `docs/llms.txt`, stamps `last_synced_commit` into every page's frontmatter (when run inside a git repo), and **validates** the whole tree: every source file has a section anchor, every internal link resolves, no TODO markers remain. Fix every reported error, re-run until clean, then `plan.py complete --task V`. A clean build is the contract downstream tooling relies on.

### Ending a session before the plan is finished

When stopping mid-plan: make sure every task you worked on is either `complete`d or still honestly unchecked (a page with remaining TODOs stays unchecked — that is correct, not a failure). Run `plan.py status`, report progress to the user, remind them to commit `/docs` including `_PLAN.md`, and tell them the resume instruction for a new chat: *"Point the repo-docs-init skill at this repo and say 'continue from docs/_PLAN.md'"*.

### Resuming in a fresh session

When resuming: run `plan.py status --repo <repo_root>` first. If it reports commit drift (code changed since the plan was made), re-run `map_repo.py` and `scaffold_docs.py` (both non-destructive), then `plan.py refresh` — it reopens completed tasks whose pages gained new TODO/STALE markers and appends tasks for new modules. Then enter the working loop. Never assume prior-session context; the plan file and the pages themselves carry all state.

### Final report

Summarize for the user: tasks completed this session, overall plan progress, anything documented at survey level, validation status, and suggested next steps (publish `/docs` as ADO Wiki; wire up the PR sync pipeline).

## Editorial standard

This is the difference between documentation worth maintaining and noise. The reader can already read code — give them only what the code cannot say.

**Document why, not what.** Never enumerate parameters, restate signatures, or narrate implementation ("this function loops over users"). Every sentence should survive this test: *could the reader have learned this in ten seconds of reading the code itself?* If yes, delete it.

**Lead with purpose and responsibility.** The Purpose section states what problem the module owns and, just as importantly, what it deliberately does *not* handle. Boundaries prevent misuse.

**Surface invariants and constraints.** The things that break if violated: "all crypto goes through `crypto.py` so algorithms rotate in one place", "session tokens are opaque, not JWTs, because revocation must land in under 1s". If a design choice looks odd, hunt for the constraint that forced it (git history and comments often hold the answer) and record it. If you can't find the reason, write "reason not evident from code or history" rather than inventing one — a wrong rationale is worse than none.

**Name the gotchas.** Each module page should tell a newcomer the two or three things they would get wrong on their first PR into this module.

**Reference code by name, never by line number.** Use `path::symbol` form (`auth/session.py::create_session`). Line numbers rot; names are durable.

**Calibrated confidence.** Distinguish what you verified from what you inferred. "Appears to assume single-writer access (no locking found)" is honest; stating it as fact is not.

**Length discipline.** 300–800 words of prose per module page (excluding scaffolded structure). A file section is typically 2–5 sentences plus its key entry points. If you need more, the module probably deserves splitting — flag it rather than sprawling.

**Voice.** Plain, direct, present tense, no marketing. Write for a competent engineer new to this repo, or an LLM agent with no context — the same text serves both.

Read `references/page-example.md` before writing your first page — it shows a completed module page at the expected quality bar. `references/page-template.md` documents every structural element and which ones are immutable.

## Re-running on an already-documented repo

If `docs/` already exists with pages: this skill regenerates *structure* non-destructively. `scaffold_docs.py` adds sections for new files and new modules, marks sections whose source files vanished with `<!-- STALE:REMOVED -->`, and never overwrites existing prose. Your job then is to write prose for the new TODOs, resolve the STALE markers (delete or rewrite), and re-run Step 5. Incremental *content* sync for code changes is the PR pipeline's job, not this skill's.

## Failure modes to avoid

- Writing docs from file names without reading the code. If you haven't read it, mark the section "not yet reviewed" rather than confabulating.
- Restating code mechanics to fill space. Short honest pages beat long redundant ones.
- Editing scaffolded structure (anchors, frontmatter, back-links). The pipeline and editor shortcut depend on these byte-for-byte.
- Hand-editing `_PLAN.md` checkboxes or claiming a task done without `plan.py complete`. A checked box means "validated", nothing less.
- Re-running map/scaffold on resume when the plan shows no drift — it wastes budget and can add noise.
- Documenting test directories, generated code, or vendored dependencies. The default config excludes them; keep it that way unless the user asks.
- Skipping validation. A `build_index.py` run with zero errors (task `V`) is the definition of done.
