# Page Templates — Structural Contract

Two page types exist per module. The PR-sync pipeline, plan validation, and
graph tooling parse them mechanically; elements marked IMMUTABLE are
load-bearing.

## 1. File page (`reference/modules/<module>/<slug>.md`) — one per source file

```markdown
---
file: session.py                              # IMMUTABLE (scripts own all
module: auth                                  #  frontmatter except the two
source_path: src/auth/session.py              #  sync-stamp lines, which
public_symbols: [create_session, ...]         #  build_index.py stamps)
internal_deps: [src/auth/crypto.py]
used_by: [src/api/handlers.py]
last_synced_commit: a3f8c2d
last_synced_at: 2026-07-10
---

(sessionpy)=                                  # IMMUTABLE MyST anchor target
# session.py                                  # IMMUTABLE heading

<prose>                                       # EDITABLE — why this file exists

## What it provides                           # IMMUTABLE heading
| Symbol | What it does & why it matters |    # table: Symbol column GENERATED
| `create_session` | <one line, why-level> |  #        right column EDITABLE

## Behavior notes                             # IMMUTABLE heading
<prose>                                       # EDITABLE

Internal dependencies: `src/auth/crypto.py`   # IMMUTABLE (machine-generated)
Used by: `src/api/handlers.py`                # IMMUTABLE (machine-generated)
Size: 42 lines (python)                       # IMMUTABLE (machine-generated)

[View source](…) · [Module overview](index.md)  # IMMUTABLE links
```

## 2. Module index (`reference/modules/<module>/index.md`)

```markdown
---  …module frontmatter (all IMMUTABLE except sync stamps)…  ---

# auth                                        # IMMUTABLE heading
## Purpose                                    # IMMUTABLE heading + EDITABLE prose
## Functionality provided                     # IMMUTABLE heading + EDITABLE prose
## Design & Invariants                        # IMMUTABLE heading + EDITABLE prose
## How It Connects                            # IMMUTABLE heading + EDITABLE prose

## Files                                      # IMMUTABLE heading
| File | Overview |                           # table structure + File links
| [session.py](sessionpy.md) | <one line> |   #  GENERATED; Overview cell EDITABLE

```{toctree} … ```                            # MACHINE-OWNED, regenerated
```

## Rules

1. **File-page names are forever.** `<slug>.md` (lowercased filename,
   `[a-z0-9_]` only) is the deep-link target for editor shortcuts, the index,
   and graphs. Scripts own creation and naming.
2. **Frontmatter is generated.** Wrong frontmatter → fix `.docsgen.yaml` or
   the code layout and re-run scripts; never hand-edit.
3. **Prose goes only where TODO markers were** (plus the editable table cells).
4. **Cross-references**: file page → sibling file page `other.md`; file page →
   another module `../storage/index.md` or `../storage/redis_clientpy.md`;
   validated by build_index.py (E3).
5. **Code references** in prose use `path::symbol`, never line numbers.
6. **Never edit** the toctree blocks, Files-table links, `reference/api/*`,
   or `_static/*.html` — machine-owned, regenerated.
