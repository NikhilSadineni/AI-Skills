#!/usr/bin/env python3
"""build_site.py — render docs/ into a self-contained static website.

Stdlib only: no Sphinx, no npm, no pip installs. Converts every Markdown
page under docs/ into HTML in docs/_site/ with:

  - a sidebar: top pages (Overview, Functionality, Architecture) plus one
    collapsible section per module listing its file pages, with a filter box
  - breadcrumbs, heading anchors, tables, fenced code
  - relative *.md links rewritten to *.html
  - Mermaid diagrams: the diagram SOURCE is always shown as a readable code
    block; if the page is viewed online, a small script upgrades it to a
    rendered diagram via CDN. Nothing on the site breaks offline.
  - llms.txt and docs-index.json copied through

The site works from a plain file server AND from file:// (all links are
relative).

Usage:
    python build_site.py --repo /path/to/repo            # build docs/_site
    python build_site.py --repo /path/to/repo --serve    # build + preview
"""
import argparse
import html
import json
import re
import shutil
from pathlib import Path

SKIP_NAMES = {"_PLAN.md"}
SKIP_DIRS = {"_site", "_drafts", "node_modules"}

LANG_COLORS = {"python": "#3572A5", "typescript": "#3178c6",
               "javascript": "#f1e05a", "csharp": "#178600", "java": "#b07219",
               "go": "#00ADD8", "rust": "#dea584", "ruby": "#701516",
               "shell": "#89e051", "sql": "#e38c00", "c": "#555555",
               "cpp": "#f34b7d", "php": "#4F5D95", "kotlin": "#A97BFF",
               "scala": "#c22d40", "powershell": "#012456"}

# ============================================================ markdown ======

def esc(s: str) -> str:
    return html.escape(s, quote=False)


def slugify(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-") or "section"


def split_frontmatter(text: str) -> tuple[dict, str]:
    m = re.match(r"^---\n(.*?)\n---\n", text, flags=re.S)
    if not m:
        return {}, text
    meta = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            meta[k.strip()] = v.strip()
    return meta, text[m.end():]


def rewrite_href(href: str) -> str:
    if re.match(r"^(https?://|mailto:|#)", href):
        return href
    base, _, frag = href.partition("#")
    if base.endswith(".md"):
        base = base[:-3] + ".html"
    return base + ("#" + frag if frag else "")


def render_inline(s: str) -> str:
    codes: list[str] = []

    def stash(m):
        codes.append(m.group(1))
        return f"\x00{len(codes) - 1}\x00"

    s = re.sub(r"`([^`]+)`", stash, s)
    s = esc(s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)\s]+)\)",
               lambda m: f'<img src="{rewrite_href(m.group(2))}" alt="{m.group(1)}">', s)
    s = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)",
               lambda m: f'<a href="{rewrite_href(m.group(2))}">{render_inline_nested(m.group(1), codes)}</a>', s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"(?<![\w*])\*([^*\n]+)\*(?![\w*])", r"<em>\1</em>", s)
    s = re.sub(r"\x00(\d+)\x00",
               lambda m: f"<code>{esc(codes[int(m.group(1))])}</code>", s)
    return s


def render_inline_nested(s: str, codes: list[str]) -> str:
    return re.sub(r"\x00(\d+)\x00",
                  lambda m: f"<code>{esc(codes[int(m.group(1))])}</code>", s)


def render_markdown(text: str) -> tuple[str, str, bool]:
    """-> (body_html, title, has_mermaid)"""
    blocks: list[str] = []
    has_mermaid = False

    def stash_fence(m):
        nonlocal has_mermaid
        lang, code = m.group(1).strip().lower(), m.group(2)
        if lang == "mermaid":
            has_mermaid = True
            blocks.append(
                '<div class="mermaid-wrap">'
                f'<pre class="mermaid">{esc(code)}</pre>'
                '<div class="mermaid-note">Diagram source — renders as a '
                'graphic when viewed online.</div></div>')
        else:
            cls = f' class="language-{lang}"' if lang else ""
            blocks.append(f"<pre><code{cls}>{esc(code)}</code></pre>")
        return f"\x01{len(blocks) - 1}\x01"

    text = re.sub(r"```([^\n]*)\n(.*?)```", stash_fence, text, flags=re.S)
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)

    lines = text.split("\n")
    out: list[str] = []
    title = ""
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        fence = re.fullmatch(r"\x01(\d+)\x01", stripped)
        if fence:
            out.append(blocks[int(fence.group(1))])
            i += 1
            continue

        m = re.match(r"^(#{1,6})\s+(.+)$", line)
        if m:
            level = len(m.group(1))
            raw = m.group(2).strip()
            if level == 1 and not title:
                title = raw
            out.append(f'<h{level} id="{slugify(raw)}">{render_inline(raw)}</h{level}>')
            i += 1
            continue

        if re.fullmatch(r"(-{3,}|\*{3,})", stripped):
            out.append("<hr>")
            i += 1
            continue

        if stripped.startswith("|") and i + 1 < len(lines) \
                and re.match(r"^\s*\|[\s:|-]+\|\s*$", lines[i + 1]):
            header = [c.strip() for c in stripped.strip("|").split("|")]
            i += 2
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            thead = "".join(f"<th>{render_inline(c)}</th>" for c in header)
            tbody = "".join(
                "<tr>" + "".join(f"<td>{render_inline(c)}</td>" for c in r) + "</tr>"
                for r in rows)
            out.append(f"<table><thead><tr>{thead}</tr></thead>"
                       f"<tbody>{tbody}</tbody></table>")
            continue

        if stripped.startswith(">"):
            quote = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote.append(lines[i].strip()[1:].strip())
                i += 1
            out.append(f"<blockquote><p>{render_inline(' '.join(quote))}</p></blockquote>")
            continue

        lm = re.match(r"^(\s*)([-*+]|\d+\.)\s+(.*)$", line)
        if lm:
            items = []
            while i < len(lines):
                m2 = re.match(r"^(\s*)([-*+]|\d+\.)\s+(.*)$", lines[i])
                if not m2:
                    break
                items.append((len(m2.group(1)) // 2,
                              m2.group(2)[0].isdigit(), m2.group(3)))
                i += 1
            out.append(render_list(items))
            continue

        para = []
        while i < len(lines) and lines[i].strip() \
                and not re.match(r"^(#{1,6}\s|\||>|\s*([-*+]|\d+\.)\s|\x01)",
                                 lines[i].strip()):
            para.append(lines[i].strip())
            i += 1
        if para:
            out.append(f"<p>{render_inline(' '.join(para))}</p>")
        else:
            i += 1

    return "\n".join(out), title, has_mermaid


def render_list(items: list[tuple[int, bool, str]]) -> str:
    out, stack = [], []

    def open_tag(ordered):
        tag = "ol" if ordered else "ul"
        stack.append(tag)
        out.append(f"<{tag}>")

    def close_tag():
        out.append(f"</{stack.pop()}>")

    prev = -1
    for level, ordered, text in items:
        level = min(level, prev + 1) if prev >= 0 else 0
        while len(stack) > level + 1:
            close_tag()
        while len(stack) < level + 1:
            open_tag(ordered)
        out.append(f"<li>{render_inline(text)}</li>")
        prev = level
    while stack:
        close_tag()
    return "".join(out)

# ================================================================ layout ====

CSS = """
:root{--bg:#ffffff;--fg:#1c1e21;--muted:#5f6368;--line:#e3e5e8;
--side:#f7f8fa;--accent:#1a5fb4;--code:#f4f5f7;--current:#e8f0fe}
*{box-sizing:border-box}
body{margin:0;font:16px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI",
Roboto,Helvetica,Arial,sans-serif;color:var(--fg);background:var(--bg)}
a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}
.layout{display:flex;min-height:100vh}
nav{width:290px;flex:none;background:var(--side);border-right:1px solid var(--line);
padding:16px 10px 40px;position:sticky;top:0;height:100vh;overflow-y:auto;font-size:14px}
nav .brand{font-weight:700;font-size:15px;padding:2px 8px 10px;display:block}
nav input{width:100%;padding:6px 8px;margin:0 0 10px;border:1px solid var(--line);
border-radius:6px;font-size:13px;background:#fff}
nav .group{font-size:11px;font-weight:700;letter-spacing:.06em;color:var(--muted);
text-transform:uppercase;margin:14px 8px 4px}
nav ul{list-style:none;margin:0;padding:0}
nav li a{display:block;padding:3px 8px;border-radius:6px;color:var(--fg);
overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
nav li a:hover{background:#eceef1;text-decoration:none}
nav a.current{background:var(--current);color:var(--accent);font-weight:600}
nav details{margin:1px 0}
nav summary{cursor:pointer;padding:3px 8px;border-radius:6px;font-weight:600;
list-style:none;display:flex;align-items:center;gap:6px}
nav summary::before{content:"\\25B8";font-size:10px;color:var(--muted);
transition:transform .12s}
nav details[open]>summary::before{transform:rotate(90deg)}
nav summary:hover{background:#eceef1}
nav summary a{display:inline;padding:0}
nav details ul{padding-left:18px}
nav .dot{display:inline-block;width:8px;height:8px;border-radius:50%;
margin-right:6px;vertical-align:baseline}
main{flex:1;min-width:0;padding:28px 44px 80px;max-width:900px}
.crumbs{font-size:13px;color:var(--muted);margin-bottom:18px}
.crumbs .sep{margin:0 6px;color:var(--line)}
h1{font-size:28px;margin:.2em 0 .6em;line-height:1.25}
h2{font-size:20px;margin:1.6em 0 .5em;padding-bottom:.25em;
border-bottom:1px solid var(--line)}
h3{font-size:16px;margin:1.4em 0 .4em}
code{background:var(--code);padding:.15em .4em;border-radius:4px;
font:13px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
pre{background:var(--code);padding:14px 16px;border-radius:8px;overflow-x:auto}
pre code{background:none;padding:0}
table{border-collapse:collapse;width:100%;margin:1em 0;font-size:14.5px}
th,td{border:1px solid var(--line);padding:7px 10px;text-align:left;
vertical-align:top}
th{background:var(--side)}
blockquote{margin:1em 0;padding:.3em 1em;border-left:3px solid var(--line);
color:var(--muted)}
hr{border:none;border-top:1px solid var(--line);margin:1.6em 0}
.meta{margin:0 0 18px;font-size:12.5px;color:var(--muted)}
.meta summary{cursor:pointer}
.meta table{font-size:12.5px;margin:.4em 0}
.mermaid-wrap{margin:1em 0}
.mermaid-wrap pre.mermaid{background:var(--code);border-radius:8px;
padding:14px 16px;font:13px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,
monospace;overflow-x:auto}
.mermaid-wrap.rendered pre.mermaid{background:none}
.mermaid-note{font-size:12px;color:var(--muted);margin-top:2px}
.mermaid-wrap.rendered .mermaid-note{display:none}
@media(max-width:860px){nav{display:none}main{padding:20px 18px}}
"""

FILTER_JS = """
var box=document.getElementById('filter');
if(box)box.addEventListener('input',function(){
  var q=this.value.trim().toLowerCase();
  document.querySelectorAll('nav li,nav details').forEach(function(el){el.style.display='';});
  if(!q)return;
  document.querySelectorAll('nav li').forEach(function(li){
    if(li.querySelector('details'))return;
    li.style.display=li.textContent.toLowerCase().indexOf(q)>=0?'':'none';
  });
  document.querySelectorAll('nav details').forEach(function(d){
    var any=false;
    d.querySelectorAll('li').forEach(function(li){if(li.style.display!=='none')any=true;});
    d.style.display=any?'':'none';if(any)d.open=true;
  });
});
"""

# Mermaid: the source is always visible as text; if the CDN is reachable the
# script upgrades each block to a rendered diagram. Failure = still readable.
MERMAID_JS = """
(function(){
  var blocks=document.querySelectorAll('.mermaid-wrap');
  if(!blocks.length)return;
  var s=document.createElement('script');
  s.src='https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js';
  s.onload=function(){
    try{
      mermaid.initialize({startOnLoad:false,theme:'neutral'});
      mermaid.run({querySelector:'.mermaid-wrap pre.mermaid'}).then(function(){
        blocks.forEach(function(b){b.classList.add('rendered');});
      }).catch(function(){});
    }catch(e){}
  };
  s.onerror=function(){};
  document.head.appendChild(s);
})();
"""

PAGE_TMPL = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title} · {repo}</title>
<style>{css}</style>
</head>
<body>
<div class="layout">
<nav>
<a class="brand" href="{root}index.html">{repo}</a>
<input id="filter" type="search" placeholder="Filter pages…">
{nav}
</nav>
<main>
<div class="crumbs">{crumbs}</div>
{meta_block}
{body}
</main>
</div>
<script>{filter_js}</script>
{mermaid_js}
</body>
</html>
"""

# ------------------------------------------------------------- nav tree ----

def build_nav_html(docs: Path, rmap: dict, current: str, root: str) -> str:
    def href(page_rel: str) -> str:
        return root + page_rel[:-3] + ".html"

    def link(label: str, page_rel: str, extra: str = "") -> str:
        cur = ' class="current"' if page_rel == current else ' class=""'
        return (f'<li><a{cur.replace("class=", "class=").rstrip()} '
                f'href="{href(page_rel)}">{extra}{esc(label)}</a></li>')

    out = ['<ul>']
    for label, rel in [("Home", "index.md"), ("Overview", "overview.md"),
                       ("Functionality", "functionality.md"),
                       ("Architecture", "architecture.md")]:
        if (docs / rel).exists():
            cur = ' current' if rel == current else ''
            out.append(f'<li><a class="pg{cur}" href="{href(rel)}">{esc(label)}</a></li>')
    out.append('</ul><div class="group">Modules</div><ul>')

    modules = rmap.get("modules", {})
    for m in rmap.get("module_order", sorted(modules)):
        info = modules[m]
        idx_rel = "files/index.md" if m == "." else f"files/{m}/index.md"
        label = "(root)" if m == "." else m
        inner, has_current = [], (idx_rel == current)
        for frel in info["files"]:
            page_rel = f"files/{frel}.md"
            lang = rmap["files"].get(frel, {}).get("language", "")
            color = LANG_COLORS.get(lang, "#9aa0a6")
            cur = ' current' if page_rel == current else ''
            name = frel if m == "." else frel[len(m) + 1:]
            inner.append(f'<li><a class="pg{cur}" href="{href(page_rel)}">'
                         f'<span class="dot" style="background:{color}"></span>'
                         f'{esc(name)}</a></li>')
            has_current |= page_rel == current
        icur = ' current' if idx_rel == current else ''
        out.append(f'<li><details{" open" if has_current else ""}>'
                   f'<summary><a class="pg{icur}" href="{href(idx_rel)}">'
                   f'{esc(label)}</a></summary>'
                   f'<ul>{"".join(inner)}</ul></details></li>')
    out.append("</ul>")
    return "".join(out)


def breadcrumbs(rel: str, root: str, docs: Path) -> str:
    parts = rel.split("/")
    crumbs = [f'<a href="{root}index.html">docs</a>']
    for i, part in enumerate(parts[:-1]):
        prefix = "/".join(parts[: i + 1])
        if (docs / prefix / "index.md").exists():
            crumbs.append(f'<a href="{root}{prefix}/index.html">{esc(part)}</a>')
        else:
            crumbs.append(esc(part))
    leaf = parts[-1][:-3] if parts[-1].endswith(".md") else parts[-1]
    if leaf != "index" or len(parts) == 1:
        crumbs.append(esc(leaf))
    return '<span class="sep">/</span>'.join(crumbs)


META_KEYS = ("source_path", "module", "language", "public_symbols",
             "depends_on", "depended_on_by", "internal_deps", "used_by",
             "loc", "last_synced_commit", "last_synced_at")


def meta_block(meta: dict) -> str:
    rows = [(k, meta[k]) for k in META_KEYS if meta.get(k)]
    if not rows:
        return ""
    body = "".join(f"<tr><td>{esc(k)}</td><td>{esc(v)}</td></tr>"
                   for k, v in rows)
    return (f'<details class="meta"><summary>metadata</summary>'
            f"<table>{body}</table></details>")

# ----------------------------------------------------------------- build ---

def build(repo: Path) -> Path:
    docs = repo / "docs"
    site = docs / "_site"
    if site.exists():
        shutil.rmtree(site)
    site.mkdir(parents=True)

    rmap_p = docs / "repo-map.json"
    rmap = json.loads(rmap_p.read_text(encoding="utf-8")) if rmap_p.exists() \
        else {"repo_name": repo.name, "modules": {}, "module_order": [],
              "files": {}}
    repo_name = rmap.get("repo_name", repo.name)

    pages = []
    for p in sorted(docs.rglob("*.md")):
        rel = p.relative_to(docs).as_posix()
        if p.name in SKIP_NAMES or any(part in SKIP_DIRS
                                       for part in p.relative_to(docs).parts):
            continue
        pages.append((p, rel))

    for p, rel in pages:
        meta, body_md = split_frontmatter(p.read_text(encoding="utf-8"))
        body, title, has_mermaid = render_markdown(body_md)
        depth = rel.count("/")
        root = "../" * depth
        out = site / (rel[:-3] + ".html")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(PAGE_TMPL.format(
            title=esc(title or Path(rel).stem), repo=esc(repo_name),
            css=CSS, root=root,
            nav=build_nav_html(docs, rmap, rel, root),
            crumbs=breadcrumbs(rel, root, docs),
            meta_block=meta_block(meta),
            body=body,
            filter_js=FILTER_JS,
            mermaid_js=f"<script>{MERMAID_JS}</script>" if has_mermaid else ""),
            encoding="utf-8")

    for extra in ("llms.txt", "docs-index.json"):
        src = docs / extra
        if src.exists():
            shutil.copy2(src, site / extra)

    print(f"Site built: {len(pages)} page(s) -> {site}")
    print("Self-contained — host on any static server or open "
          "index.html directly.")
    return site


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--serve", action="store_true")
    ap.add_argument("--port", type=int, default=8000)
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    site = build(repo)

    if args.serve:
        import functools
        from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
        handler = functools.partial(SimpleHTTPRequestHandler, directory=str(site))
        with ThreadingHTTPServer(("127.0.0.1", args.port), handler) as srv:
            print(f"Serving docs at http://127.0.0.1:{args.port} (Ctrl-C to stop)")
            try:
                srv.serve_forever()
            except KeyboardInterrupt:
                pass


if __name__ == "__main__":
    main()
